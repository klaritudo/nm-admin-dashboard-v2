// 시스템로그 컬럼 정의
export const systemLogsColumns = [
  {
    id: 'checkbox',
    type: 'checkbox',
    width: 50,
    sortable: false,
    pinnable: true
  },
  {
    id: 'number',
    type: 'number',
    header: 'No.',
    width: 70,
    align: 'center',
    pinnable: true
  },
  {
    id: 'datetime',
    header: '일시',
    type: 'default',
    width: 180,
    sortable: true,
    pinnable: true
  },
  {
    id: 'level',
    header: '로그레벨',
    type: 'chip',
    width: 100,
    align: 'center',
    sortable: true,
    pinnable: true,
    chipProps: (value) => {
      const levelColors = {
        'INFO': { color: 'info', variant: 'filled' },
        'WARNING': { color: 'warning', variant: 'filled' },
        'ERROR': { color: 'error', variant: 'filled' },
        'CRITICAL': { color: 'error', variant: 'filled', sx: { fontWeight: 'bold' } }
      };
      
      const props = levelColors[value] || { color: 'default', variant: 'filled' };
      return {
        ...props,
        size: 'small'
      };
    }
  },
  {
    id: 'category',
    header: '카테고리',
    type: 'chip',
    width: 120,
    align: 'center',
    sortable: true,
    chipProps: (value) => {
      const categoryColors = {
        '시스템': 'primary',
        '보안': 'error',
        '데이터베이스': 'secondary',
        'API': 'info',
        '결제': 'success',
        '게임': 'warning',
        '성능': 'default'
      };
      
      return {
        color: categoryColors[value] || 'default',
        variant: 'outlined',
        size: 'small'
      };
    }
  },
  {
    id: 'source',
    header: '소스',
    type: 'default',
    width: 150,
    sortable: true
  },
  {
    id: 'ip',
    header: 'IP',
    type: 'default',
    width: 140,
    sortable: true
  },
  {
    id: 'user',
    header: '사용자',
    type: 'default',
    width: 120,
    sortable: true
  },
  {
    id: 'action',
    header: '액션',
    type: 'default',
    width: 200,
    sortable: true
  },
  {
    id: 'status',
    header: '상태',
    type: 'chip',
    width: 80,
    align: 'center',
    sortable: true,
    chipProps: (value) => {
      const statusColors = {
        '처리중': { color: 'warning', variant: 'filled' },
        '완료': { color: 'success', variant: 'filled' },
        '실패': { color: 'error', variant: 'filled' },
        '대기': { color: 'default', variant: 'filled' }
      };
      
      const props = statusColors[value] || { color: 'default', variant: 'filled' };
      return {
        ...props,
        size: 'small'
      };
    }
  },
  {
    id: 'content',
    header: '내용',
    type: 'default',
    width: 400,
    sortable: false
  },
  {
    id: 'details',
    header: '상세내용',
    type: 'default',
    width: 500,
    sortable: false
  }
];