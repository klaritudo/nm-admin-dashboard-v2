// 회원변경로그 데이터 생성
import { memberChangesColumns } from './memberChangesColumns';

// 랜덤 데이터 생성을 위한 헬퍼 함수
const getRandomElement = (array) => array[Math.floor(Math.random() * array.length)];

const adminIds = ['admin001', 'admin002', 'manager01', 'manager02', 'supervisor1'];
const memberIds = ['user1234', 'player001', 'member999', 'test_user', 'demo_account', 'vip_player1', 'gold_member', 'silver123'];

const changeReasons = {
  '닉네임': [
    '사용자 요청',
    '부적절한 닉네임',
    '중복 닉네임 해결',
    '특수문자 제거',
    '길이 제한 조정'
  ],
  '비밀번호': [
    '비밀번호 분실',
    '보안 강화',
    '정기 변경',
    '해킹 시도 감지',
    '임시 비밀번호 발급'
  ],
  '은행정보': [
    '계좌 변경 요청',
    '은행 통합/폐업',
    '명의 확인 완료',
    '계좌번호 오류 수정',
    '예금주명 변경'
  ],
  '전화번호': [
    '번호 변경',
    '인증 완료',
    '오류 수정',
    '국제번호 형식 변경',
    '통신사 변경'
  ],
  '이메일': [
    '이메일 변경 요청',
    '도메인 변경',
    '오타 수정',
    '인증 완료',
    '수신거부 설정'
  ],
  '레벨': [
    '승급 조건 달성',
    'VIP 등급 조정',
    '활동 실적 반영',
    '이벤트 보상',
    '관리자 조정'
  ],
  '상태': [
    '이용제한 해제',
    '휴면계정 활성화',
    '정지 처분',
    '자진 탈퇴',
    '강제 탈퇴'
  ],
  '보유금': [
    '충전 처리',
    '환전 처리',
    '보정 작업',
    '이벤트 지급',
    '오류 수정'
  ],
  '게임머니': [
    '게임 전환',
    '보너스 지급',
    '회수 처리',
    '보정 작업',
    '시스템 오류 수정'
  ]
};

const oldNewValues = {
  '닉네임': [
    { old: 'player123', new: 'GoldPlayer' },
    { old: 'test_user', new: 'ProGamer' },
    { old: '!!!BadName!!!', new: 'CleanName' },
    { old: 'duplicate_01', new: 'UniqueUser' },
    { old: 'veryverylongnickname123456', new: 'ShortNick' }
  ],
  '비밀번호': [
    { old: '********', new: '********' },
    { old: '약한 비밀번호', new: '강력한 비밀번호' },
    { old: '이전 비밀번호', new: '새 비밀번호' },
    { old: '임시 비밀번호', new: '신규 비밀번호' },
    { old: '만료된 비밀번호', new: '갱신된 비밀번호' }
  ],
  '은행정보': [
    { old: '국민은행 123-456-789012', new: '신한은행 987-654-321098' },
    { old: '우리은행 111-222-333444', new: '하나은행 555-666-777888' },
    { old: '농협 999-888-777666', new: '카카오뱅크 3333-01-1234567' },
    { old: '기업은행 222-333-444555', new: '토스뱅크 1000-01-999999' },
    { old: 'KB국민 444-555-666777', new: 'NH농협 123-45-67890' }
  ],
  '전화번호': [
    { old: '010-1234-5678', new: '010-9876-5432' },
    { old: '010-1111-2222', new: '010-3333-4444' },
    { old: '010-5555-6666', new: '010-7777-8888' },
    { old: '02-123-4567', new: '010-1234-5678' },
    { old: '+82-10-1234-5678', new: '010-1234-5678' }
  ],
  '이메일': [
    { old: 'user@old-domain.com', new: 'user@new-domain.com' },
    { old: 'test@gmail.com', new: 'test@naver.com' },
    { old: 'player@hotmail.com', new: 'player@gmail.com' },
    { old: 'member@yahoo.com', new: 'member@daum.net' },
    { old: 'vip@company.com', new: 'vip@personal.com' }
  ],
  '레벨': [
    { old: 'Bronze', new: 'Silver' },
    { old: 'Silver', new: 'Gold' },
    { old: 'Gold', new: 'Platinum' },
    { old: 'Platinum', new: 'Diamond' },
    { old: 'Regular', new: 'VIP' }
  ],
  '상태': [
    { old: '정상', new: '정지' },
    { old: '정지', new: '정상' },
    { old: '휴면', new: '정상' },
    { old: '정상', new: '탈퇴' },
    { old: '제한', new: '정상' }
  ],
  '보유금': [
    { old: '1,000,000', new: '2,000,000' },
    { old: '500,000', new: '0' },
    { old: '100,000', new: '150,000' },
    { old: '2,500,000', new: '2,000,000' },
    { old: '0', new: '1,000,000' }
  ],
  '게임머니': [
    { old: '50,000', new: '100,000' },
    { old: '200,000', new: '150,000' },
    { old: '0', new: '50,000' },
    { old: '1,000,000', new: '1,500,000' },
    { old: '300,000', new: '0' }
  ]
};

// IP 생성 함수
const generateIP = () => {
  return `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`;
};

// 날짜 생성 함수 (최근 30일)
const generateDate = (index) => {
  const now = new Date();
  const hoursAgo = index * 2; // 2시간 간격
  const date = new Date(now.getTime() - hoursAgo * 60 * 60 * 1000);
  
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
};

// 회원변경로그 데이터 생성 함수
export const generateMemberChangesData = () => {
  const memberChanges = [];
  const changeItems = Object.keys(changeReasons);
  
  for (let i = 0; i < 120; i++) {
    const changeItem = getRandomElement(changeItems);
    const targetMember = getRandomElement(memberIds);
    const isSystemChange = Math.random() > 0.8;
    const isUserChange = Math.random() > 0.9;
    
    let changedBy = '';
    if (isSystemChange) {
      changedBy = '시스템';
    } else if (isUserChange) {
      changedBy = '본인';
    } else {
      changedBy = getRandomElement(adminIds);
    }
    
    const reason = getRandomElement(changeReasons[changeItem]);
    const { old: oldValue, new: newValue } = getRandomElement(oldNewValues[changeItem]);
    
    let content = '';
    if (changeItem === '보유금' || changeItem === '게임머니') {
      const oldNum = parseInt(oldValue.replace(/,/g, ''));
      const newNum = parseInt(newValue.replace(/,/g, ''));
      const diff = newNum - oldNum;
      const diffStr = diff > 0 ? `+${diff.toLocaleString()}` : diff.toLocaleString();
      content = `${targetMember}님의 ${changeItem}이(가) ${oldValue}원에서 ${newValue}원으로 변경되었습니다. (${diffStr}원)`;
    } else if (changeItem === '비밀번호') {
      content = `${targetMember}님의 비밀번호가 변경되었습니다. ${reason}`;
    } else {
      content = `${targetMember}님의 ${changeItem}이(가) "${oldValue}"에서 "${newValue}"(으)로 변경되었습니다.`;
    }
    
    memberChanges.push({
      id: 120 - i, // 최신 변경사항이 위로 오도록
      changeDate: generateDate(i),
      changedBy: changedBy,
      targetMember: targetMember,
      changeItem: changeItem,
      oldValue: oldValue,
      newValue: newValue,
      ip: changedBy === '시스템' ? '127.0.0.1' : generateIP(),
      reason: reason,
      content: content
    });
  }
  
  return memberChanges;
};

export { memberChangesColumns };