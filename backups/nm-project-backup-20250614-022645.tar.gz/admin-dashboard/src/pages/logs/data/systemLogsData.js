// 시스템로그 데이터 생성
import { systemLogsColumns } from './systemLogsColumns';

// 랜덤 데이터 생성을 위한 헬퍼 함수
const getRandomElement = (array) => array[Math.floor(Math.random() * array.length)];

// 로그 템플릿
const logTemplates = {
  '시스템': {
    'INFO': [
      { action: '서버 시작', content: '애플리케이션 서버가 정상적으로 시작되었습니다.', details: 'Server version: 2.5.1, Port: 8080, Environment: production' },
      { action: '캐시 갱신', content: '메모리 캐시가 성공적으로 갱신되었습니다.', details: 'Cache size: 512MB, Items: 15420, Hit ratio: 87.3%' },
      { action: '백업 완료', content: '데이터베이스 백업이 완료되었습니다.', details: 'Backup size: 2.3GB, Duration: 45s, Type: incremental' },
      { action: '설정 변경', content: '시스템 설정이 변경되었습니다.', details: 'Config: max_connections changed from 100 to 200' },
      { action: '모듈 로드', content: '확장 모듈이 로드되었습니다.', details: 'Module: payment_gateway_v3, Status: active' }
    ],
    'WARNING': [
      { action: '메모리 경고', content: '메모리 사용량이 80%를 초과했습니다.', details: 'Current: 12.8GB/16GB, Processes: 145, Swap: 2.1GB' },
      { action: '디스크 공간', content: '디스크 공간이 부족합니다.', details: 'Disk: /data, Used: 85%, Free: 150GB' },
      { action: '느린 쿼리', content: '느린 쿼리가 감지되었습니다.', details: 'Query time: 5.2s, Table: user_transactions' },
      { action: '연결 제한', content: '최대 연결 수에 근접했습니다.', details: 'Connections: 95/100, Active: 82' }
    ],
    'ERROR': [
      { action: '서비스 오류', content: '외부 서비스 연결에 실패했습니다.', details: 'Service: payment_api, Error: Connection timeout after 30s' },
      { action: '파일 오류', content: '로그 파일 쓰기에 실패했습니다.', details: 'File: /var/log/app.log, Error: Permission denied' },
      { action: '모듈 오류', content: '모듈 초기화에 실패했습니다.', details: 'Module: analytics_v2, Error: Invalid configuration' }
    ],
    'CRITICAL': [
      { action: '서버 다운', content: '주 데이터베이스 서버가 응답하지 않습니다.', details: 'Server: db-master-01, Last ping: 300s ago, Failover initiated' },
      { action: '데이터 손실', content: '데이터 무결성 오류가 감지되었습니다.', details: 'Table: financial_records, Affected rows: 15, Backup restore required' }
    ]
  },
  '보안': {
    'INFO': [
      { action: '로그인 성공', content: '관리자 로그인이 감지되었습니다.', details: 'Admin: admin001, 2FA: enabled, Session: created' },
      { action: '권한 변경', content: '사용자 권한이 변경되었습니다.', details: 'User: manager02, Role: operator -> admin' },
      { action: '보안 업데이트', content: '보안 패치가 적용되었습니다.', details: 'Patch: CVE-2024-1234, Status: applied successfully' }
    ],
    'WARNING': [
      { action: '로그인 실패', content: '반복적인 로그인 실패가 감지되었습니다.', details: 'IP: 192.168.1.100, Attempts: 5, User: unknown' },
      { action: '비정상 접근', content: '비정상적인 API 호출 패턴이 감지되었습니다.', details: 'IP: 10.0.0.55, Requests: 1000/min, Pattern: sequential' },
      { action: 'IP 차단', content: '의심스러운 IP가 자동 차단되었습니다.', details: 'IP: 45.67.89.123, Reason: port scanning, Duration: 24h' }
    ],
    'ERROR': [
      { action: '인증 오류', content: 'SSL 인증서 검증에 실패했습니다.', details: 'Domain: api.example.com, Error: certificate expired' },
      { action: '권한 오류', content: '권한 검증 시스템 오류가 발생했습니다.', details: 'Service: auth_service, Error: database connection lost' }
    ],
    'CRITICAL': [
      { action: '해킹 시도', content: 'SQL 인젝션 공격이 감지되었습니다.', details: 'IP: 123.45.67.89, Target: /api/users, Payload: DROP TABLE users' },
      { action: '데이터 유출', content: '대량의 데이터 다운로드가 감지되었습니다.', details: 'User: compromised_account, Downloaded: 50000 records, Action: account locked' }
    ]
  },
  '데이터베이스': {
    'INFO': [
      { action: '백업 시작', content: '일일 백업이 시작되었습니다.', details: 'Type: full backup, Estimated time: 60 minutes' },
      { action: '인덱스 생성', content: '새로운 인덱스가 생성되었습니다.', details: 'Table: user_logs, Index: idx_created_at, Time: 2.3s' },
      { action: '통계 갱신', content: '테이블 통계가 갱신되었습니다.', details: 'Tables updated: 15, Optimization: completed' }
    ],
    'WARNING': [
      { action: '잠금 대기', content: '장시간 트랜잭션 잠금이 감지되었습니다.', details: 'Transaction ID: 12345, Lock time: 30s, Waiting: 5 queries' },
      { action: '복제 지연', content: '슬레이브 복제 지연이 발생했습니다.', details: 'Slave: db-slave-02, Lag: 120s, Status: catching up' }
    ],
    'ERROR': [
      { action: '쿼리 실패', content: '쿼리 실행에 실패했습니다.', details: 'Query: UPDATE users SET..., Error: deadlock detected' },
      { action: '연결 실패', content: '데이터베이스 연결 풀이 고갈되었습니다.', details: 'Pool size: 50, Active: 50, Waiting: 15' }
    ]
  },
  'API': {
    'INFO': [
      { action: 'API 호출', content: '외부 API 호출이 성공했습니다.', details: 'Endpoint: /payment/process, Response time: 250ms, Status: 200' },
      { action: '캐시 적중', content: 'API 응답이 캐시에서 제공되었습니다.', details: 'Endpoint: /users/profile, Cache hit rate: 92%' }
    ],
    'WARNING': [
      { action: '속도 제한', content: 'API 속도 제한에 도달했습니다.', details: 'Client: mobile_app_v2, Limit: 1000/hour, Current: 980' },
      { action: '응답 지연', content: 'API 응답 시간이 느립니다.', details: 'Endpoint: /reports/generate, Time: 8.5s, Threshold: 5s' }
    ],
    'ERROR': [
      { action: 'API 오류', content: 'API 요청 처리 중 오류가 발생했습니다.', details: 'Endpoint: /transactions/create, Error: invalid parameters' }
    ]
  },
  '결제': {
    'INFO': [
      { action: '결제 성공', content: '결제가 성공적으로 처리되었습니다.', details: 'Transaction ID: TXN123456, Amount: 50000원, Method: card' },
      { action: '환불 처리', content: '환불이 정상적으로 처리되었습니다.', details: 'Original TXN: TXN123455, Refund: 10000원, Reason: customer request' }
    ],
    'WARNING': [
      { action: '결제 지연', content: '결제 처리가 지연되고 있습니다.', details: 'Gateway: payment_provider_A, Delay: 5s, Queue: 25' }
    ],
    'ERROR': [
      { action: '결제 실패', content: '결제 처리에 실패했습니다.', details: 'Error: card declined, Code: 51, Amount: 100000원' }
    ],
    'CRITICAL': [
      { action: '결제 시스템', content: '결제 게이트웨이 연결이 끊어졌습니다.', details: 'Gateway: main_provider, Status: unreachable, Failover: activated' }
    ]
  },
  '게임': {
    'INFO': [
      { action: '게임 시작', content: '새로운 게임 세션이 시작되었습니다.', details: 'Game: slot_machine_01, User: player123, Session: GS789012' },
      { action: '잭팟 당첨', content: '잭팟이 터졌습니다!', details: 'Game: mega_slots, User: lucky777, Amount: 5000000원' }
    ],
    'WARNING': [
      { action: '비정상 패턴', content: '비정상적인 게임 패턴이 감지되었습니다.', details: 'User: suspect001, Pattern: rapid betting, Risk score: 85' }
    ],
    'ERROR': [
      { action: '게임 오류', content: '게임 로직 오류가 발생했습니다.', details: 'Game: casino_roulette, Error: invalid bet placement' }
    ]
  },
  '성능': {
    'INFO': [
      { action: '성능 측정', content: '시스템 성능이 정상 범위입니다.', details: 'CPU: 45%, Memory: 62%, Response time: 120ms' }
    ],
    'WARNING': [
      { action: 'CPU 사용률', content: 'CPU 사용률이 높습니다.', details: 'Current: 85%, Processes: node(45%), mysql(25%), redis(15%)' },
      { action: '응답 시간', content: '평균 응답 시간이 증가했습니다.', details: 'Average: 500ms, P95: 1200ms, P99: 2500ms' }
    ]
  }
};

// IP 생성 함수
const generateIP = () => {
  const isLocal = Math.random() > 0.7;
  if (isLocal) {
    return ['127.0.0.1', '192.168.1.100', '10.0.0.50', '172.16.0.10'][Math.floor(Math.random() * 4)];
  }
  return `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`;
};

// 소스 생성 함수
const generateSource = (category) => {
  const sources = {
    '시스템': ['app-server-01', 'app-server-02', 'web-server', 'cache-server', 'queue-worker'],
    '보안': ['auth-service', 'firewall', 'ids-system', 'security-monitor', 'access-control'],
    '데이터베이스': ['db-master', 'db-slave-01', 'db-slave-02', 'db-backup', 'db-monitor'],
    'API': ['api-gateway', 'api-server-01', 'api-server-02', 'load-balancer', 'cdn-edge'],
    '결제': ['payment-service', 'payment-gateway', 'transaction-processor', 'billing-system'],
    '게임': ['game-server-01', 'game-server-02', 'game-engine', 'rng-service', 'game-monitor'],
    '성능': ['monitoring-agent', 'metrics-collector', 'performance-analyzer', 'apm-service']
  };
  
  return getRandomElement(sources[category] || ['unknown-source']);
};

// 사용자 생성 함수
const generateUser = (level, category) => {
  if (level === 'INFO' && category === '보안') {
    return getRandomElement(['admin001', 'manager01', 'supervisor1']);
  }
  if (category === '게임' || category === '결제') {
    return getRandomElement(['player001', 'user1234', 'member999', 'vip_player1']);
  }
  if (Math.random() > 0.5) {
    return 'system';
  }
  return getRandomElement(['admin001', 'system', 'scheduler', 'monitor', '-']);
};

// 날짜 생성 함수 (최근 7일)
const generateDate = (index) => {
  const now = new Date();
  const minutesAgo = index * 3; // 3분 간격
  const date = new Date(now.getTime() - minutesAgo * 60 * 1000);
  
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
};

// 상태 결정 함수
const determineStatus = (level) => {
  if (level === 'ERROR' || level === 'CRITICAL') {
    return Math.random() > 0.3 ? '실패' : '처리중';
  }
  if (level === 'WARNING') {
    return Math.random() > 0.5 ? '완료' : '처리중';
  }
  return Math.random() > 0.1 ? '완료' : '처리중';
};

// 시스템로그 데이터 생성 함수
export const generateSystemLogsData = () => {
  const systemLogs = [];
  const categories = Object.keys(logTemplates);
  const levels = ['INFO', 'WARNING', 'ERROR', 'CRITICAL'];
  
  // 레벨별 가중치
  const levelWeights = {
    'INFO': 60,
    'WARNING': 25,
    'ERROR': 12,
    'CRITICAL': 3
  };
  
  for (let i = 0; i < 200; i++) {
    const category = getRandomElement(categories);
    
    // 가중치를 적용한 레벨 선택
    let level;
    const rand = Math.random() * 100;
    let cumulative = 0;
    for (const [lvl, weight] of Object.entries(levelWeights)) {
      cumulative += weight;
      if (rand < cumulative) {
        level = lvl;
        break;
      }
    }
    
    const categoryLogs = logTemplates[category][level];
    if (!categoryLogs || categoryLogs.length === 0) {
      continue;
    }
    
    const logTemplate = getRandomElement(categoryLogs);
    
    systemLogs.push({
      id: 200 - i, // 최신 로그가 위로 오도록
      datetime: generateDate(i),
      level: level,
      category: category,
      source: generateSource(category),
      ip: generateIP(),
      user: generateUser(level, category),
      action: logTemplate.action,
      status: determineStatus(level),
      content: logTemplate.content,
      details: logTemplate.details
    });
  }
  
  return systemLogs;
};

export { systemLogsColumns };