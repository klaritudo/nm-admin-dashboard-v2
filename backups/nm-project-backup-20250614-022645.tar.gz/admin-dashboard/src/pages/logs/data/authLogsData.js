// 접속로그 데이터 생성
import { authLogsColumns } from './authLogsColumns';

// 랜덤 데이터 생성을 위한 헬퍼 함수
const getRandomElement = (array) => array[Math.floor(Math.random() * array.length)];

const userIds = [
  'admin001', 'admin002', 'manager01', 'manager02', 'supervisor1',
  'agent001', 'agent002', 'agent003', 'agent004', 'agent005',
  'user1234', 'player001', 'member999', 'test_user', 'demo_account',
  'vip_player1', 'gold_member', 'silver123', 'bronze_user', 'diamond_vip'
];

const devices = [
  'Windows 10 - Chrome 120.0',
  'Windows 11 - Edge 119.0',
  'macOS 14.0 - Safari 17.1',
  'iPhone 15 - Safari Mobile',
  'Android 14 - Chrome Mobile',
  'iPad Pro - Safari Mobile',
  'Ubuntu 22.04 - Firefox 120.0',
  'Windows 10 - Firefox 119.0',
  'Android 13 - Samsung Browser',
  'macOS 13.0 - Chrome 119.0'
];

const locations = [
  '서울특별시 강남구',
  '서울특별시 서초구',
  '경기도 성남시',
  '부산광역시 해운대구',
  '대구광역시 중구',
  '인천광역시 연수구',
  '대전광역시 유성구',
  '광주광역시 서구',
  '울산광역시 남구',
  '경기도 수원시',
  '경기도 고양시',
  '충청북도 청주시',
  '충청남도 천안시',
  '전라북도 전주시',
  '전라남도 여수시',
  '경상북도 포항시',
  '경상남도 창원시',
  '제주특별자치도 제주시',
  '강원도 춘천시',
  '세종특별자치시'
];

const loginMessages = [
  '정상적으로 로그인되었습니다.',
  '2단계 인증을 통과하여 로그인되었습니다.',
  'IP 변경 감지 - 추가 인증 후 로그인되었습니다.',
  '새로운 기기에서 로그인되었습니다.',
  '자동 로그인으로 접속되었습니다.'
];

const logoutMessages = [
  '사용자가 정상적으로 로그아웃했습니다.',
  '세션 만료로 자동 로그아웃되었습니다.',
  '다른 기기에서 로그인하여 로그아웃되었습니다.',
  '비활성 시간 초과로 로그아웃되었습니다.',
  '관리자에 의해 강제 로그아웃되었습니다.'
];

const failureMessages = [
  '잘못된 비밀번호입니다. (시도: 1/5)',
  '잘못된 비밀번호입니다. (시도: 2/5)',
  '잘못된 비밀번호입니다. (시도: 3/5)',
  '존재하지 않는 계정입니다.',
  '계정이 비활성화되어 있습니다.',
  '접속이 차단된 IP입니다.',
  '2단계 인증 실패',
  '비밀번호 5회 오류로 계정이 잠겼습니다.',
  '유효하지 않은 토큰입니다.',
  '세션이 만료되었습니다.'
];

// IP 생성 함수
const generateIP = () => {
  return `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`;
};

// 날짜 생성 함수 (최근 30일)
const generateDate = (index) => {
  const now = new Date();
  const minutesAgo = index * 5; // 5분 간격
  const date = new Date(now.getTime() - minutesAgo * 60 * 1000);
  
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');
  
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
};

// 접속로그 데이터 생성 함수
export const generateAuthLogsData = () => {
  const authLogs = [];
  
  for (let i = 0; i < 150; i++) {
    const type = getRandomElement(['로그인', '로그아웃']);
    const userId = getRandomElement(userIds);
    const userType = userId.startsWith('admin') || userId.startsWith('manager') || userId.startsWith('supervisor') 
      ? '에이전트' 
      : '회원';
    const status = Math.random() > 0.85 ? '실패' : '성공'; // 15% 실패율
    
    let content = '';
    if (type === '로그인') {
      content = status === '성공' ? getRandomElement(loginMessages) : getRandomElement(failureMessages);
    } else {
      content = getRandomElement(logoutMessages);
    }
    
    authLogs.push({
      id: 150 - i, // 최신 로그가 위로 오도록
      datetime: generateDate(i),
      type: type,
      userId: userId,
      userType: userType,
      ip: generateIP(),
      device: getRandomElement(devices),
      location: getRandomElement(locations),
      status: type === '로그아웃' ? '성공' : status, // 로그아웃은 항상 성공
      content: content
    });
  }
  
  return authLogs;
};

export { authLogsColumns };