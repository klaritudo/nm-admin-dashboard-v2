// 접속로그 컬럼 정의
export const authLogsColumns = [
  {
    id: 'checkbox',
    type: 'checkbox',
    width: 50,
    sortable: false,
    pinnable: true
  },
  {
    id: 'number',
    type: 'number',
    header: 'No.',
    width: 70,
    align: 'center',
    pinnable: true
  },
  {
    id: 'datetime',
    header: '일시',
    type: 'default',
    width: 180,
    sortable: true,
    pinnable: true
  },
  {
    id: 'type',
    header: '유형',
    type: 'chip',
    width: 100,
    align: 'center',
    sortable: true,
    pinnable: true,
    chipProps: (value) => {
      if (value === '로그인') {
        return {
          color: 'success',
          variant: 'filled',
          size: 'small'
        };
      } else if (value === '로그아웃') {
        return {
          color: 'warning',
          variant: 'filled',
          size: 'small'
        };
      }
      return {
        color: 'default',
        variant: 'filled',
        size: 'small'
      };
    }
  },
  {
    id: 'userId',
    header: '사용자ID',
    type: 'default',
    width: 120,
    sortable: true
  },
  {
    id: 'userType',
    header: '사용자유형',
    type: 'chip',
    width: 120,
    align: 'center',
    sortable: true,
    chipProps: (value) => {
      if (value === '에이전트') {
        return {
          color: 'primary',
          variant: 'outlined',
          size: 'small'
        };
      } else if (value === '회원') {
        return {
          color: 'secondary',
          variant: 'outlined',
          size: 'small'
        };
      }
      return {
        color: 'default',
        variant: 'outlined',
        size: 'small'
      };
    }
  },
  {
    id: 'ip',
    header: 'IP',
    type: 'default',
    width: 140,
    sortable: true
  },
  {
    id: 'device',
    header: '기기',
    type: 'default',
    width: 150,
    sortable: true
  },
  {
    id: 'location',
    header: '위치',
    type: 'default',
    width: 180,
    sortable: true
  },
  {
    id: 'status',
    header: '상태',
    type: 'chip',
    width: 80,
    align: 'center',
    sortable: true,
    chipProps: (value) => {
      if (value === '성공') {
        return {
          color: 'success',
          variant: 'filled',
          size: 'small'
        };
      } else if (value === '실패') {
        return {
          color: 'error',
          variant: 'filled',
          size: 'small'
        };
      }
      return {
        color: 'default',
        variant: 'filled',
        size: 'small'
      };
    }
  },
  {
    id: 'content',
    header: '내용',
    type: 'default',
    width: 300,
    sortable: false
  }
];