// 회원변경로그 컬럼 정의
export const memberChangesColumns = [
  {
    id: 'checkbox',
    type: 'checkbox',
    width: 50,
    sortable: false,
    pinnable: true
  },
  {
    id: 'number',
    type: 'number',
    header: 'No.',
    width: 70,
    align: 'center',
    pinnable: true
  },
  {
    id: 'changeDate',
    header: '변경일시',
    type: 'default',
    width: 180,
    sortable: true,
    pinnable: true
  },
  {
    id: 'changedBy',
    header: '변경자',
    type: 'default',
    width: 120,
    sortable: true,
    pinnable: true
  },
  {
    id: 'targetMember',
    header: '대상회원',
    type: 'default',
    width: 120,
    sortable: true,
    pinnable: true
  },
  {
    id: 'changeItem',
    header: '변경항목',
    type: 'chip',
    width: 100,
    align: 'center',
    sortable: true,
    chipProps: (value) => {
      const chipColors = {
        '닉네임': 'primary',
        '비밀번호': 'secondary',
        '은행정보': 'info',
        '전화번호': 'default',
        '이메일': 'default',
        '레벨': 'warning',
        '상태': 'error',
        '보유금': 'success',
        '게임머니': 'success'
      };
      
      return {
        color: chipColors[value] || 'default',
        variant: 'outlined',
        size: 'small'
      };
    }
  },
  {
    id: 'oldValue',
    header: '이전값',
    type: 'default',
    width: 200,
    sortable: false
  },
  {
    id: 'newValue',
    header: '새값',
    type: 'default',
    width: 200,
    sortable: false
  },
  {
    id: 'ip',
    header: 'IP',
    type: 'default',
    width: 140,
    sortable: true
  },
  {
    id: 'reason',
    header: '변경사유',
    type: 'default',
    width: 200,
    sortable: false
  },
  {
    id: 'content',
    header: '내용',
    type: 'default',
    width: 300,
    sortable: false
  }
];