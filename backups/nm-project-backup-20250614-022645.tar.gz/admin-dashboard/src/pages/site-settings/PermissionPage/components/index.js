export { default as PermissionDialog } from './PermissionDialog';

// 삭제 확인 다이얼로그는 기존 것을 재사용
export { DeleteConfirmDialog } from '../../components';