import React from 'react';
import { Box, Card, CardContent, Typography, CircularProgress } from '@mui/material';
import TrendIndicator from './TrendIndicator';
import '../styles/stats-card.css';

/**
 * 통계 카드 아이템 컴포넌트
 * @param {string} title - 카드 제목
 * @param {number} value - 현재 값
 * @param {number} previousValue - 이전 값
 * @param {string} suffix - 값 뒤에 붙는 접미사 (예: %, 원, 달러 등)
 * @param {boolean} loading - 로딩 상태
 * @param {React.ComponentType} icon - 표시할 아이콘 컴포넌트
 * @returns {JSX.Element} 통계 카드 컴포넌트
 */
const StatsCardItem = ({ title, value, previousValue, suffix, loading, icon: Icon }) => {
  return (
    <Card className="stats-card-root">
      <CardContent className="stats-card-content">
        <Box className="stats-card-header">
          <Typography className="stats-card-title">
            {title}
          </Typography>
          {Icon && <Icon color="action" fontSize="small" />}
        </Box>
        
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '60px' }}>
            <CircularProgress size={24} />
          </Box>
        ) : (
          <>
            <Typography className="stats-card-value">
              {value.toLocaleString()}{suffix || ''}
            </Typography>
            
            {previousValue !== undefined && (
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <TrendIndicator value={value} previousValue={previousValue} />
                <Typography variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                  이전 기간 대비
                </Typography>
              </Box>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default StatsCardItem; 