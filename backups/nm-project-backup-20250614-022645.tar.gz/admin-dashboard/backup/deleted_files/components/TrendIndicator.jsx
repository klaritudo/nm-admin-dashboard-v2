import React from 'react';
import { Box } from '@mui/material';
import '../styles/stats-card.css';

/**
 * 값의 변화 추세를 시각적으로 표시하는 컴포넌트
 * @param {number} value - 현재 값
 * @param {number} previousValue - 이전 값
 * @returns {JSX.Element} 트렌드 표시 컴포넌트
 */
const TrendIndicator = ({ value, previousValue }) => {
  const isUp = value > previousValue;
  const percentChange = previousValue === 0 
    ? 0 
    : Math.abs(Math.round((value - previousValue) / previousValue * 100));
  
  return (
    <Box className={`stats-card-trend ${isUp ? 'stats-card-trend-up' : 'stats-card-trend-down'}`}>
      {isUp ? '↑' : '↓'} {percentChange}%
    </Box>
  );
};

export default TrendIndicator; 