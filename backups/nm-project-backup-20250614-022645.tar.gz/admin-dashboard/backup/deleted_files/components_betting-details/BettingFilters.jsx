import React from 'react';
import { 
  Box, 
  TextField, 
  MenuItem, 
  Button, 
  IconButton, 
  Tooltip, 
  Typography,
  ToggleButtonGroup,
  ToggleButton,
  FormControl,
  InputLabel,
  Select,
  Popover,
  Checkbox,
  FormControlLabel,
  Paper
} from '@mui/material';
import { 
  FilterList, 
  Search, 
  Clear, 
  Download, 
  Print,
  CalendarMonth
} from '@mui/icons-material';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider, DatePicker } from '@mui/x-date-pickers';
import { format } from 'date-fns';
import { ko } from 'date-fns/locale';

const BettingFilters = ({ 
  filters, 
  handleFilterChange, 
  handleColumnMenuOpen, 
  handleOpenExcelDialog,
  handlePrint,
  gameOptions
}) => {
  const [gameFilterAnchorEl, setGameFilterAnchorEl] = React.useState(null);
  const gameFilterOpen = Boolean(gameFilterAnchorEl);

  const handleGameFilterClick = (event) => {
    setGameFilterAnchorEl(event.currentTarget);
  };

  const handleGameFilterClose = () => {
    setGameFilterAnchorEl(null);
  };

  const handleGameFilterChange = (event) => {
    const { value, checked } = event.target;
    const currentGames = filters.games || [];
    
    const newGames = checked
      ? [...currentGames, value]
      : currentGames.filter(game => game !== value);
    
    handleFilterChange({
      target: {
        name: 'games',
        value: newGames
      }
    });
  };

  const handleDateChange = (date) => {
    handleFilterChange({
      target: {
        name: 'date',
        value: date
      }
    });
  };

  const handleQuickDateSelect = (hours) => {
    const now = new Date();
    const date = new Date();
    
    if (hours === 24) {
      // 당일 (오늘 00시 ~ 내일 00시)
      date.setHours(0, 0, 0, 0);
    } else {
      // 12시간 또는 24시간 전
      date.setHours(now.getHours() - hours);
    }
    
    handleFilterChange({
      target: {
        name: 'date',
        value: date
      }
    });
  };

  return (
    <Box sx={{ mb: 3 }}>
      {/* 필터 상단 행 */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2, flexWrap: 'wrap' }}>
        {/* 게임 유형 필터 */}
        <ToggleButtonGroup
          value={filters.gameType}
          exclusive
          onChange={(e, newValue) => {
            if (newValue !== null) {
              handleFilterChange({
                target: {
                  name: 'gameType',
                  value: newValue
                }
              });
            }
          }}
          size="small"
          aria-label="게임 유형"
        >
          <ToggleButton value="all" aria-label="전체">
            전체
          </ToggleButton>
          <ToggleButton value="slot" aria-label="슬롯">
            슬롯
          </ToggleButton>
          <ToggleButton value="casino" aria-label="카지노">
            카지노
          </ToggleButton>
        </ToggleButtonGroup>

        {/* 게임별 필터 */}
        <Button 
          variant="outlined" 
          size="small" 
          startIcon={<FilterList />}
          onClick={handleGameFilterClick}
          sx={{ height: '32px' }}
        >
          게임별 필터 ({filters.games?.length || 0})
        </Button>
        <Popover
          open={gameFilterOpen}
          anchorEl={gameFilterAnchorEl}
          onClose={handleGameFilterClose}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'left',
          }}
          transformOrigin={{
            vertical: 'top',
            horizontal: 'left',
          }}
        >
          <Paper sx={{ p: 2, maxHeight: '300px', overflow: 'auto', width: '250px' }}>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>게임 선택</Typography>
            {gameOptions.map((game) => (
              <FormControlLabel
                key={game.value}
                control={
                  <Checkbox
                    checked={filters.games?.includes(game.value) || false}
                    onChange={handleGameFilterChange}
                    value={game.value}
                    size="small"
                  />
                }
                label={game.label}
              />
            ))}
          </Paper>
        </Popover>

        {/* 공베팅 필터 */}
        <FormControl size="small" sx={{ minWidth: 150 }}>
          <InputLabel id="shared-betting-label">공베팅</InputLabel>
          <Select
            labelId="shared-betting-label"
            id="shared-betting"
            value={filters.sharedBetting || ''}
            label="공베팅"
            name="sharedBetting"
            onChange={handleFilterChange}
          >
            <MenuItem value="">전체</MenuItem>
            <MenuItem value="manual">수동공베팅</MenuItem>
            <MenuItem value="auto">자동공베팅</MenuItem>
          </Select>
        </FormControl>

        {/* API 필터 */}
        <FormControl size="small" sx={{ minWidth: 150 }}>
          <InputLabel id="api-type-label">API</InputLabel>
          <Select
            labelId="api-type-label"
            id="api-type"
            value={filters.apiType || ''}
            label="API"
            name="apiType"
            onChange={handleFilterChange}
          >
            <MenuItem value="">전체</MenuItem>
            <MenuItem value="official">정품</MenuItem>
            <MenuItem value="parsing">파싱</MenuItem>
          </Select>
        </FormControl>

        {/* 검색 필드 */}
        <TextField
          name="search"
          placeholder="아이디, 게임명, TransID 검색"
          variant="outlined"
          size="small"
          value={filters.search || ''}
          onChange={handleFilterChange}
          onKeyPress={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              console.log('엔터 키로 검색 실행:', filters.search);
            }
          }}
          InputProps={{
            startAdornment: <Search fontSize="small" sx={{ mr: 1, color: 'action.active' }} />,
            endAdornment: filters.search ? (
              <IconButton 
                size="small" 
                onClick={() => handleFilterChange({
                  target: {
                    name: 'search',
                    value: ''
                  }
                })}
              >
                <Clear fontSize="small" />
              </IconButton>
            ) : null,
            sx: { height: '32px' }
          }}
          sx={{ minWidth: '250px' }}
        />

        {/* 우측 버튼 그룹 */}
        <Box sx={{ display: 'flex', gap: 1, ml: 'auto' }}>
          {/* 표시 옵션 */}
          <Tooltip title="표시 옵션">
            <IconButton 
              size="small" 
              onClick={(e) => handleColumnMenuOpen(e)}
              sx={{ border: '1px solid #e0e0e0' }}
            >
              <FilterList fontSize="small" />
            </IconButton>
          </Tooltip>
          
          {/* 엑셀 다운로드 */}
          <Tooltip title="엑셀 다운로드">
            <IconButton 
              size="small" 
              onClick={handleOpenExcelDialog}
              sx={{ border: '1px solid #e0e0e0' }}
            >
              <Download fontSize="small" />
            </IconButton>
          </Tooltip>
          
          {/* 프린트 */}
          <Tooltip title="프린트">
            <IconButton 
              size="small" 
              onClick={handlePrint}
              sx={{ border: '1px solid #e0e0e0' }}
            >
              <Print fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>
      </Box>

      {/* 날짜 필터 행 */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
        <LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={ko}>
          <DatePicker
            label="날짜 선택"
            value={filters.date || null}
            onChange={handleDateChange}
            format="yyyy-MM-dd"
            slots={{
              textField: TextField
            }}
            slotProps={{
              textField: {
                size: "small",
                sx: { width: '200px' },
                InputProps: {
                  startAdornment: <CalendarMonth fontSize="small" sx={{ mr: 1, color: 'action.active' }} />
                }
              }
            }}
          />
        </LocalizationProvider>

        {/* 빠른 날짜 선택 버튼 */}
        <ToggleButtonGroup
          value={filters.quickDate || ''}
          exclusive
          onChange={(e, newValue) => {
            if (newValue !== null) {
              handleFilterChange({
                target: {
                  name: 'quickDate',
                  value: newValue
                }
              });
              
              if (newValue === 'day') {
                handleQuickDateSelect(24);
              } else if (newValue === 'half') {
                handleQuickDateSelect(12);
              } else if (newValue === 'full') {
                handleQuickDateSelect(24);
              }
            }
          }}
          size="small"
          aria-label="빠른 날짜 선택"
        >
          <ToggleButton value="day" aria-label="당일">
            당일
          </ToggleButton>
          <ToggleButton value="half" aria-label="12시간">
            12시간
          </ToggleButton>
          <ToggleButton value="full" aria-label="24시간">
            24시간
          </ToggleButton>
        </ToggleButtonGroup>

        {/* 현재 필터 표시 */}
        {(filters.search || filters.gameType !== 'all' || filters.games?.length > 0 || 
          filters.sharedBetting || filters.apiType || filters.date) && (
          <Box sx={{ ml: 'auto', display: 'flex', alignItems: 'center' }}>
            <Button 
              size="small" 
              color="error" 
              startIcon={<Clear />}
              onClick={() => {
                // 모든 필터 초기화
                handleFilterChange({
                  target: {
                    name: 'reset',
                    value: true
                  }
                });
              }}
            >
              필터 초기화
            </Button>
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default BettingFilters; 