import React from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Box,
  Grid,
  Divider,
  Chip,
  IconButton,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow
} from '@mui/material';
import { Close } from '@mui/icons-material';
import { formatDate, getGameTypeStyle, getApiTypeStyle, getSharedBettingStyle } from './bettingTableUtils';
import { formatCurrency } from '../member-management/memberUtils.jsx';

const BettingDetailDialog = ({ open, betting, onClose }) => {
  if (!betting) return null;
  
  const gameTypeStyle = getGameTypeStyle(betting.gameType);
  
  return (
    <Dialog 
      open={open} 
      onClose={onClose}
      maxWidth="md"
      fullWidth
    >
      <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', pb: 1 }}>
        <Typography variant="h6" component="div">
          베팅 상세 정보
        </Typography>
        <IconButton onClick={onClose} size="small">
          <Close />
        </IconButton>
      </DialogTitle>
      
      <Divider />
      
      <DialogContent sx={{ p: 3 }}>
        {/* 기본 정보 섹션 */}
        <Box sx={{ mb: 3 }}>
          <Typography variant="subtitle1" fontWeight="bold" sx={{ mb: 2 }}>
            기본 정보
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography variant="body2" color="text.secondary">아이디:</Typography>
                  <Typography variant="body2" fontWeight="bold">{betting.userId}</Typography>
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography variant="body2" color="text.secondary">닉네임:</Typography>
                  <Typography variant="body2">{betting.nickname}</Typography>
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography variant="body2" color="text.secondary">게임 유형:</Typography>
                  <Chip 
                    label={betting.gameType === 'slot' ? '슬롯' : '카지노'} 
                    size="small"
                    sx={{
                      backgroundColor: gameTypeStyle.backgroundColor,
                      color: gameTypeStyle.color,
                      border: `1px solid ${gameTypeStyle.borderColor}`,
                      fontWeight: 'bold',
                      fontSize: '0.75rem'
                    }}
                  />
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography variant="body2" color="text.secondary">게임사:</Typography>
                  <Typography variant="body2">{betting.provider}</Typography>
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography variant="body2" color="text.secondary">게임명:</Typography>
                  <Typography variant="body2">{betting.gameName}</Typography>
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography variant="body2" color="text.secondary">게임 ID:</Typography>
                  <Typography variant="body2" fontFamily="monospace">{betting.gameId}</Typography>
                </Box>
              </Box>
            </Grid>
            
            <Grid item xs={12} sm={6}>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography variant="body2" color="text.secondary">일자:</Typography>
                  <Typography variant="body2">{formatDate(betting.date)}</Typography>
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography variant="body2" color="text.secondary">베팅금액:</Typography>
                  <Typography variant="body2" fontWeight="bold">{formatCurrency(betting.betAmount)}</Typography>
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography variant="body2" color="text.secondary">당첨금액:</Typography>
                  <Typography 
                    variant="body2" 
                    fontWeight="bold"
                    color={(betting.winAmount || 0) > betting.betAmount ? 'success.main' : 'error.main'}
                  >
                    {formatCurrency(betting.winAmount)}
                  </Typography>
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography variant="body2" color="text.secondary">손익:</Typography>
                  <Typography 
                    variant="body2" 
                    fontWeight="bold"
                    color={(betting.winAmount - betting.betAmount) >= 0 ? 'success.main' : 'error.main'}
                  >
                    {formatCurrency(betting.winAmount - betting.betAmount)}
                  </Typography>
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                  <Typography variant="body2" color="text.secondary">발란스:</Typography>
                  <Typography variant="body2">{formatCurrency(betting.balance)}</Typography>
                </Box>
                
                {betting.apiType && (
                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography variant="body2" color="text.secondary">API 유형:</Typography>
                    <Chip 
                      label={betting.apiType === 'official' ? '정품' : '파싱'} 
                      size="small"
                      sx={{
                        backgroundColor: getApiTypeStyle(betting.apiType).backgroundColor,
                        color: getApiTypeStyle(betting.apiType).color,
                        border: `1px solid ${getApiTypeStyle(betting.apiType).borderColor}`,
                        fontWeight: 'bold',
                        fontSize: '0.75rem'
                      }}
                    />
                  </Box>
                )}
                
                {betting.sharedBetting && (
                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                    <Typography variant="body2" color="text.secondary">공베팅 유형:</Typography>
                    <Chip 
                      label={betting.sharedBetting === 'manual' ? '수동공베팅' : '자동공베팅'} 
                      size="small"
                      sx={{
                        backgroundColor: getSharedBettingStyle(betting.sharedBetting).backgroundColor,
                        color: getSharedBettingStyle(betting.sharedBetting).color,
                        border: `1px solid ${getSharedBettingStyle(betting.sharedBetting).borderColor}`,
                        fontWeight: 'bold',
                        fontSize: '0.75rem'
                      }}
                    />
                  </Box>
                )}
              </Box>
            </Grid>
          </Grid>
        </Box>
        
        <Divider sx={{ my: 3 }} />
        
        {/* 트랜잭션 정보 섹션 */}
        <Box sx={{ mb: 3 }}>
          <Typography variant="subtitle1" fontWeight="bold" sx={{ mb: 2 }}>
            트랜잭션 정보
          </Typography>
          
          <TableContainer component={Paper} variant="outlined">
            <Table size="small">
              <TableHead>
                <TableRow sx={{ backgroundColor: '#f5f5f5' }}>
                  <TableCell sx={{ fontWeight: 'bold' }}>구분</TableCell>
                  <TableCell sx={{ fontWeight: 'bold' }}>값</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow>
                  <TableCell>TransID</TableCell>
                  <TableCell sx={{ fontFamily: 'monospace' }}>{betting.transId}</TableCell>
                </TableRow>
                {betting.linkTransId && (
                  <TableRow>
                    <TableCell>LinkTransID</TableCell>
                    <TableCell sx={{ fontFamily: 'monospace' }}>{betting.linkTransId}</TableCell>
                  </TableRow>
                )}
                {/* 추가 트랜잭션 정보가 있다면 여기에 추가 */}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
        
        {/* 게임 결과 섹션 - 실제 데이터에 따라 조정 필요 */}
        <Box>
          <Typography variant="subtitle1" fontWeight="bold" sx={{ mb: 2 }}>
            게임 결과
          </Typography>
          
          <Paper variant="outlined" sx={{ p: 2, backgroundColor: '#f9f9f9' }}>
            {betting.gameType === 'slot' ? (
              <Box>
                <Typography variant="body2" sx={{ mb: 1 }}>
                  <strong>심볼 조합:</strong> {betting.gameResult?.symbols || '정보 없음'}
                </Typography>
                <Typography variant="body2" sx={{ mb: 1 }}>
                  <strong>페이라인:</strong> {betting.gameResult?.paylines || '정보 없음'}
                </Typography>
                <Typography variant="body2">
                  <strong>특수 기능:</strong> {betting.gameResult?.features || '정보 없음'}
                </Typography>
              </Box>
            ) : (
              <Box>
                <Typography variant="body2" sx={{ mb: 1 }}>
                  <strong>게임 결과:</strong> {betting.gameResult?.outcome || '정보 없음'}
                </Typography>
                <Typography variant="body2">
                  <strong>카드/숫자:</strong> {betting.gameResult?.cards || '정보 없음'}
                </Typography>
              </Box>
            )}
          </Paper>
        </Box>
      </DialogContent>
      
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose} variant="outlined">
          닫기
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default BettingDetailDialog; 