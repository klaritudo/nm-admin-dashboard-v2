import React from 'react';
import { 
  Box, 
  Typography, 
  Chip, 
  Tooltip,
  Link
} from '@mui/material';
import { formatCurrency } from '../member-management/memberUtils.jsx';

// 날짜 포맷 함수
export const formatDate = (dateString) => {
  if (!dateString) return '-';
  
  const date = new Date(dateString);
  return date.toLocaleString('ko-KR', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  });
};

// 게임 유형에 따른 스타일 가져오기
export const getGameTypeStyle = (gameType) => {
  switch (gameType) {
    case 'slot':
      return {
        backgroundColor: '#e3f2fd',
        color: '#1565c0',
        borderColor: '#90caf9'
      };
    case 'casino':
      return {
        backgroundColor: '#fce4ec',
        color: '#c2185b',
        borderColor: '#f48fb1'
      };
    default:
      return {
        backgroundColor: '#f5f5f5',
        color: '#616161',
        borderColor: '#e0e0e0'
      };
  }
};

// API 유형에 따른 스타일 가져오기
export const getApiTypeStyle = (apiType) => {
  switch (apiType) {
    case 'official':
      return {
        backgroundColor: '#e8f5e9',
        color: '#2e7d32',
        borderColor: '#a5d6a7'
      };
    case 'parsing':
      return {
        backgroundColor: '#fff3e0',
        color: '#e65100',
        borderColor: '#ffcc80'
      };
    default:
      return {
        backgroundColor: '#f5f5f5',
        color: '#616161',
        borderColor: '#e0e0e0'
      };
  }
};

// 공베팅 유형에 따른 스타일 가져오기
export const getSharedBettingStyle = (sharedBettingType) => {
  switch (sharedBettingType) {
    case 'manual':
      return {
        backgroundColor: '#e8eaf6',
        color: '#3949ab',
        borderColor: '#9fa8da'
      };
    case 'auto':
      return {
        backgroundColor: '#f3e5f5',
        color: '#7b1fa2',
        borderColor: '#ce93d8'
      };
    default:
      return {
        backgroundColor: '#f5f5f5',
        color: '#616161',
        borderColor: '#e0e0e0'
      };
  }
};

// 셀 내용 렌더링
export const renderBettingCellContent = (betting, columnId, depth = 0, handleOpenBettingDetailDialog) => {
  switch (columnId) {
    case 'date':
      return (
        <Typography variant="body2">
          {formatDate(betting.date)}
        </Typography>
      );
      
    case 'userId':
      return (
        <Box sx={{ display: 'flex', flexDirection: 'column' }}>
          <Typography 
            variant="body2" 
            sx={{ 
              fontWeight: 'bold', 
              cursor: 'pointer',
              '&:hover': { textDecoration: 'underline' }
            }}
            onClick={(e) => {
              e.stopPropagation();
              handleOpenBettingDetailDialog(betting);
            }}
          >
            {betting.userId}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            {betting.nickname}
          </Typography>
        </Box>
      );
      
    case 'gameType':
      const gameTypeStyle = getGameTypeStyle(betting.gameType);
      return (
        <Box sx={{ width: '100%', display: 'flex', justifyContent: 'center' }}>
          <Chip 
            label={betting.gameType === 'slot' ? '슬롯' : '카지노'} 
            size="small"
            sx={{
              backgroundColor: gameTypeStyle.backgroundColor,
              color: gameTypeStyle.color,
              border: `1px solid ${gameTypeStyle.borderColor}`,
              fontWeight: 'bold',
              fontSize: '0.75rem',
              minWidth: '70px'
            }}
          />
        </Box>
      );
      
    case 'betAmount':
      return (
        <Typography variant="body2" sx={{ fontWeight: 500 }}>
          {formatCurrency(betting.betAmount)}
        </Typography>
      );
      
    case 'winAmount':
      return (
        <Typography 
          variant="body2" 
          sx={{ 
            fontWeight: 500, 
            color: (betting.winAmount || 0) > betting.betAmount ? 'success.main' : 'error.main' 
          }}
        >
          {formatCurrency(betting.winAmount)}
        </Typography>
      );
      
    case 'balance':
      return (
        <Typography variant="body2">
          {formatCurrency(betting.balance)}
        </Typography>
      );
      
    case 'provider':
      return (
        <Typography variant="body2">
          {betting.provider}
        </Typography>
      );
      
    case 'gameName':
      return (
        <Tooltip title={betting.gameName} arrow>
          <Typography 
            variant="body2" 
            sx={{ 
              maxWidth: '150px',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap'
            }}
          >
            {betting.gameName}
          </Typography>
        </Tooltip>
      );
      
    case 'gameId':
      return (
        <Typography variant="body2" sx={{ fontFamily: 'monospace' }}>
          {betting.gameId}
        </Typography>
      );
      
    case 'transId':
      return (
        <Tooltip title={betting.transId} arrow>
          <Typography 
            variant="body2" 
            sx={{ 
              maxWidth: '120px',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
              fontFamily: 'monospace',
              fontSize: '0.75rem'
            }}
          >
            {betting.transId}
          </Typography>
        </Tooltip>
      );
      
    case 'linkTransId':
      return (
        <Tooltip title={betting.linkTransId} arrow>
          <Typography 
            variant="body2" 
            sx={{ 
              maxWidth: '120px',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
              fontFamily: 'monospace',
              fontSize: '0.75rem'
            }}
          >
            {betting.linkTransId || '-'}
          </Typography>
        </Tooltip>
      );
      
    case 'note':
      return (
        <Link
          component="button"
          variant="body2"
          onClick={(e) => {
            e.stopPropagation();
            handleOpenBettingDetailDialog(betting);
          }}
          underline="hover"
        >
          상세정보
        </Link>
      );
      
    case 'apiType':
      if (!betting.apiType) return null;
      
      const apiTypeStyle = getApiTypeStyle(betting.apiType);
      return (
        <Chip 
          label={betting.apiType === 'official' ? '정품' : '파싱'} 
          size="small"
          sx={{
            backgroundColor: apiTypeStyle.backgroundColor,
            color: apiTypeStyle.color,
            border: `1px solid ${apiTypeStyle.borderColor}`,
            fontWeight: 'bold',
            fontSize: '0.75rem'
          }}
        />
      );
      
    case 'sharedBetting':
      if (!betting.sharedBetting) return null;
      
      const sharedBettingStyle = getSharedBettingStyle(betting.sharedBetting);
      return (
        <Chip 
          label={betting.sharedBetting === 'manual' ? '수동공베팅' : '자동공베팅'} 
          size="small"
          sx={{
            backgroundColor: sharedBettingStyle.backgroundColor,
            color: sharedBettingStyle.color,
            border: `1px solid ${sharedBettingStyle.borderColor}`,
            fontWeight: 'bold',
            fontSize: '0.75rem'
          }}
        />
      );
      
    default:
      return betting[columnId] || '-';
  }
};

// 기본 열 정의
export const defaultColumns = [
  { id: 'date', label: '일자', width: '150px' },
  { id: 'userId', label: '아이디(닉네임)', width: '150px' },
  { id: 'gameType', label: '게임유형', width: '120px' },
  { id: 'betAmount', label: '베팅', width: '120px' },
  { id: 'winAmount', label: '당첨', width: '120px' },
  { id: 'balance', label: '발란스', width: '120px' },
  { id: 'provider', label: '게임사', width: '120px' },
  { id: 'gameName', label: '게임명', width: '150px' },
  { id: 'gameId', label: '게임ID', width: '120px' },
  { id: 'transId', label: 'TransID', width: '150px' },
  { id: 'linkTransId', label: 'LinkTransID', width: '150px' },
  { id: 'note', label: '비고', width: '100px' },
  { id: 'apiType', label: 'API', width: '80px' },
  { id: 'sharedBetting', label: '공베팅', width: '100px' }
];

// 샘플 게임 옵션
export const sampleGameOptions = [
  { value: 'pragmatic', label: 'Pragmatic Play' },
  { value: 'evolution', label: 'Evolution Gaming' },
  { value: 'netent', label: 'NetEnt' },
  { value: 'microgaming', label: 'Microgaming' },
  { value: 'playngo', label: 'Play\'n GO' },
  { value: 'redtiger', label: 'Red Tiger' },
  { value: 'booongo', label: 'Booongo' },
  { value: 'habanero', label: 'Habanero' },
  { value: 'pgsoft', label: 'PG Soft' },
  { value: 'cq9', label: 'CQ9 Gaming' }
];

// 샘플 베팅 데이터
export const sampleBettingData = Array(50).fill().map((_, index) => {
  const isSlot = Math.random() > 0.4;
  const betAmount = Math.floor(Math.random() * 1000000) + 10000;
  const isWin = Math.random() > 0.6;
  const winAmount = isWin 
    ? Math.floor(betAmount * (Math.random() * 3 + 1)) 
    : Math.floor(betAmount * Math.random());
  
  const gameProviders = [
    'Pragmatic Play', 'Evolution Gaming', 'NetEnt', 'Microgaming', 
    'Play\'n GO', 'Red Tiger', 'Booongo', 'Habanero', 'PG Soft', 'CQ9 Gaming'
  ];
  
  const slotGames = [
    'Sweet Bonanza', 'Gates of Olympus', 'Wolf Gold', 'The Dog House', 
    'Big Bass Bonanza', 'Fruit Party', 'Buffalo King', 'Great Rhino', 
    'Release the Kraken', 'Wild West Gold'
  ];
  
  const casinoGames = [
    'Blackjack', 'Roulette', 'Baccarat', 'Lightning Roulette', 
    'Crazy Time', 'Dream Catcher', 'Monopoly Live', 'Mega Ball', 
    'Sic Bo', 'Dragon Tiger'
  ];
  
  const provider = gameProviders[Math.floor(Math.random() * gameProviders.length)];
  const gameName = isSlot 
    ? slotGames[Math.floor(Math.random() * slotGames.length)]
    : casinoGames[Math.floor(Math.random() * casinoGames.length)];
  
  const date = new Date();
  date.setHours(date.getHours() - Math.floor(Math.random() * 24));
  date.setMinutes(date.getMinutes() - Math.floor(Math.random() * 60));
  
  const apiType = Math.random() > 0.7 ? (Math.random() > 0.5 ? 'official' : 'parsing') : null;
  const sharedBetting = Math.random() > 0.8 ? (Math.random() > 0.5 ? 'manual' : 'auto') : null;
  
  return {
    id: `bet-${index + 1}`,
    date: date.toISOString(),
    userId: `user${Math.floor(Math.random() * 1000) + 1}`,
    nickname: `닉네임${Math.floor(Math.random() * 1000) + 1}`,
    gameType: isSlot ? 'slot' : 'casino',
    betAmount,
    winAmount,
    balance: Math.floor(Math.random() * 10000000) + 1000000,
    provider,
    gameName,
    gameId: `GAME${Math.floor(Math.random() * 100000) + 1}`,
    transId: `TX${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`,
    linkTransId: Math.random() > 0.7 ? `LTX${Math.random().toString(36).substring(2, 15)}` : null,
    apiType,
    sharedBetting
  };
}); 