import React from 'react';
import { Box, Typography, Paper } from '@mui/material';

/**
 * 베팅내역 - 슬롯/카지노 페이지
 * 메뉴 구조만 유지하고 내부 기능은 제거됨
 */
const BettingDetailsPage = () => {
  return (
    <Box sx={{ p: 3 }}>
      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="h5" gutterBottom>
          베팅내역 - 슬롯/카지노
        </Typography>
        <Typography variant="body1">
          이 기능은 현재 사용할 수 없습니다.
        </Typography>
      </Paper>
    </Box>
  );
};

export { BettingDetailsPage }; 