import React from 'react';
import { 
  Box, 
  Pagination, 
  FormControl, 
  InputLabel, 
  Select, 
  MenuItem, 
  Typography 
} from '@mui/material';

const BettingPagination = ({ 
  totalItems, 
  rowsPerPage, 
  page, 
  handleChangePage, 
  handleChangeRowsPerPage 
}) => {
  // 페이지 수 계산
  const pageCount = Math.ceil(totalItems / rowsPerPage);
  
  // 현재 표시 중인 항목 범위 계산
  const startItem = totalItems === 0 ? 0 : (page * rowsPerPage) + 1;
  const endItem = Math.min((page + 1) * rowsPerPage, totalItems);
  
  return (
    <Box sx={{ 
      display: 'flex', 
      alignItems: 'center', 
      justifyContent: 'space-between',
      mt: 2,
      flexWrap: 'wrap',
      gap: 2
    }}>
      {/* 페이지당 행 수 선택 */}
      <FormControl size="small" sx={{ minWidth: 120 }}>
        <InputLabel id="rows-per-page-label">페이지당 행</InputLabel>
        <Select
          labelId="rows-per-page-label"
          id="rows-per-page"
          value={rowsPerPage}
          label="페이지당 행"
          onChange={handleChangeRowsPerPage}
        >
          <MenuItem value={10}>10개</MenuItem>
          <MenuItem value={20}>20개</MenuItem>
          <MenuItem value={50}>50개</MenuItem>
          <MenuItem value={100}>100개</MenuItem>
        </Select>
      </FormControl>
      
      {/* 페이지 정보 */}
      <Typography variant="body2" color="text.secondary">
        {totalItems > 0 
          ? `${startItem}-${endItem} / 총 ${totalItems}개`
          : '데이터 없음'}
      </Typography>
      
      {/* 페이지네이션 컨트롤 */}
      <Pagination 
        count={pageCount} 
        page={page + 1} 
        onChange={(event, newPage) => handleChangePage(newPage - 1)}
        color="primary"
        showFirstButton
        showLastButton
        size="small"
      />
    </Box>
  );
};

export default BettingPagination; 