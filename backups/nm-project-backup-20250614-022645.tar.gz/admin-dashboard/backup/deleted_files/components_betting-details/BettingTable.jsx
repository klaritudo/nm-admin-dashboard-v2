import React from 'react';
import { 
  DndContext, 
  closestCenter, 
  KeyboardSensor, 
  PointerSensor, 
  useSensor, 
  useSensors,
  DragOverlay
} from '@dnd-kit/core';
import { 
  SortableContext, 
  horizontalListSortingStrategy,
  sortableKeyboardCoordinates,
  useSortable
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { 
  Box, 
  Table, 
  TableBody, 
  TableCell as MuiTableCell, 
  TableContainer, 
  TableHead, 
  TableRow as MuiTableRow, 
  Paper, 
  Typography, 
  IconButton,
  Tooltip
} from '@mui/material';
import { 
  MoreVert, 
  DragIndicator,
  ExpandMore,
  ChevronRight
} from '@mui/icons-material';
import SortableColumnHeader from '../member-management/SortableColumnHeader';
import { renderBettingCellContent } from './bettingTableUtils';

// 테이블 셀 스타일 가져오기 함수
const getCellStyle = (betting, columnId, isSearchMode = false) => {
  // 기본 셀 스타일
  const baseStyle = {
    borderBottom: '1px solid #e0e0e0',
    textAlign: 'center',
    verticalAlign: 'middle',
    padding: '8px 16px',
    fontSize: '0.875rem'
  };
  
  // 게임유형 컬럼인 경우 추가 스타일
  if (columnId === 'gameType') {
    baseStyle.minWidth = '120px';
    baseStyle.width = '120px';
  }
  
  // 검색 모드인 경우 추가 스타일
  if (isSearchMode) {
    return {
      ...baseStyle,
      outline: '2px solid #4caf50'
    };
  }
  
  return baseStyle;
};

// 테이블 셀 컴포넌트
const TableCell = ({ betting, columnId, children, customKey, isSearchMode = false }) => {
  return (
    <MuiTableCell 
      key={customKey || `${betting.id}-${columnId}`}
      style={getCellStyle(betting, columnId, isSearchMode)}
    >
      {children}
    </MuiTableCell>
  );
};

// 액션 셀 컴포넌트
const ActionCell = ({ betting, handleActionMenuOpen, customKey, isSearchMode = false }) => {
  return (
    <MuiTableCell 
      key={customKey || `${betting.id}-actions`}
      style={getCellStyle(betting, 'actions', isSearchMode)}
      align="center"
    >
      <IconButton 
        size="small" 
        onClick={(e) => {
          e.stopPropagation();
          handleActionMenuOpen(e, betting);
        }}
      >
        <MoreVert fontSize="small" />
      </IconButton>
    </MuiTableCell>
  );
};

// No 셀 컴포넌트
const NoCell = ({ betting, rowNumber, customKey, isSearchMode = false }) => {
  return (
    <MuiTableCell 
      key={customKey || `${betting.id}-no`}
      style={getCellStyle(betting, 'no', isSearchMode)}
      align="center"
    >
      <Typography variant="body2">{rowNumber}</Typography>
    </MuiTableCell>
  );
};

// 테이블 행 컴포넌트
const TableRow = ({ betting, columns, renderedRows, children, customKey, isSearchMode = false }) => {
  return (
    <MuiTableRow 
      key={customKey || betting.id}
      hover
      style={{ cursor: 'pointer' }}
    >
      {children}
    </MuiTableRow>
  );
};

// 베팅 테이블 컴포넌트
const BettingTable = ({ 
  columns, 
  paginatedBettings, 
  sortConfig, 
  handleSort, 
  handleDragEnd, 
  handleActionMenuOpen, 
  expandedRows, 
  toggleRowExpanded, 
  isRowExpanded, 
  filters, 
  rowsPerPage,
  handleOpenBettingDetailDialog,
  totalBettingAmount,
  totalWinningAmount,
  totalCount
}) => {
  // 센서 설정
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  return (
    <Box sx={{ width: '100%', overflow: 'hidden' }}>
      {/* 통계 정보 표시 */}
      <Box sx={{ 
        display: 'flex', 
        gap: 3, 
        mb: 2, 
        p: 1, 
        bgcolor: '#f5f5f5', 
        borderRadius: 1,
        alignItems: 'center'
      }}>
        <Typography variant="body1" fontWeight="bold">
          검색갯수: {totalCount}개
        </Typography>
        <Typography variant="body1" fontWeight="bold">
          베팅금액: {totalBettingAmount.toLocaleString()}원
        </Typography>
        <Typography variant="body1" fontWeight="bold">
          당첨금액: {totalWinningAmount.toLocaleString()}원
        </Typography>
      </Box>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragEnd={handleDragEnd}
      >
        <TableContainer 
          component={Paper} 
          sx={{ 
            maxHeight: 'calc(100vh - 300px)',
            '&::-webkit-scrollbar': {
              width: '8px',
              height: '8px',
            },
            '&::-webkit-scrollbar-track': {
              backgroundColor: '#f1f1f1',
            },
            '&::-webkit-scrollbar-thumb': {
              backgroundColor: '#888',
              borderRadius: '4px',
            },
            '&::-webkit-scrollbar-thumb:hover': {
              backgroundColor: '#555',
            },
          }}
        >
          <Table stickyHeader size="small" sx={{ tableLayout: 'fixed' }}>
            <TableHead>
              <MuiTableRow>
                {/* 번호 열 */}
                <MuiTableCell 
                  style={{ 
                    width: '50px', 
                    textAlign: 'center',
                    fontWeight: 'bold',
                    backgroundColor: '#f5f5f5',
                    position: 'sticky',
                    top: 0,
                    zIndex: 2
                  }}
                >
                  No
                </MuiTableCell>
                
                {/* 정렬 가능한 열 헤더 */}
                <SortableContext
                  items={columns.map(col => col.id)}
                  strategy={horizontalListSortingStrategy}
                >
                  {columns.map((column) => (
                    <MuiTableCell 
                      key={column.id}
                      style={{ 
                        width: column.width || '120px', 
                        minWidth: column.width || '120px',
                        textAlign: 'center',
                        fontWeight: 'bold',
                        backgroundColor: '#f5f5f5',
                        position: 'sticky',
                        top: 0,
                        zIndex: 2,
                        padding: '12px 8px',
                        height: 'auto',
                        minHeight: '60px'
                      }}
                      onClick={() => handleSort(column.id)}
                    >
                      <Box sx={{ 
                        display: 'flex', 
                        alignItems: 'center', 
                        justifyContent: 'center',
                        flexDirection: 'row'
                      }}>
                        <Typography variant="subtitle2">
                          {column.label}
                        </Typography>
                        {sortConfig.key === column.id && (
                          <Box component="span" sx={{ ml: 0.5 }}>
                            {sortConfig.direction === 'asc' ? '▲' : '▼'}
                          </Box>
                        )}
                      </Box>
                    </MuiTableCell>
                  ))}
                </SortableContext>
                
                {/* 액션 열 */}
                <MuiTableCell 
                  style={{ 
                    width: '50px', 
                    textAlign: 'center',
                    fontWeight: 'bold',
                    backgroundColor: '#f5f5f5',
                    position: 'sticky',
                    top: 0,
                    zIndex: 2
                  }}
                >
                  액션
                </MuiTableCell>
              </MuiTableRow>
            </TableHead>
            
            <TableBody>
              {paginatedBettings.length > 0 ? (
                paginatedBettings.map((betting, index) => (
                  <TableRow
                    key={betting.id}
                    betting={betting}
                    columns={columns}
                    onClick={() => handleOpenBettingDetailDialog(betting)}
                  >
                    <NoCell 
                      betting={betting} 
                      rowNumber={(filters.page * rowsPerPage) + index + 1} 
                    />
                    
                    {columns.map(column => (
                      <TableCell
                        key={`${betting.id}-${column.id}`}
                        betting={betting}
                        columnId={column.id}
                      >
                        {renderBettingCellContent(
                          betting, 
                          column.id, 
                          0, 
                          handleOpenBettingDetailDialog, 
                          toggleRowExpanded, 
                          isRowExpanded
                        )}
                      </TableCell>
                    ))}
                    
                    <ActionCell 
                      betting={betting} 
                      handleActionMenuOpen={handleActionMenuOpen} 
                    />
                  </TableRow>
                ))
              ) : (
                <MuiTableRow>
                  <MuiTableCell colSpan={columns.length + 2} align="center" sx={{ py: 3 }}>
                    <Typography variant="body1">
                      검색 결과가 없습니다.
                    </Typography>
                  </MuiTableCell>
                </MuiTableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </DndContext>
    </Box>
  );
};

export default BettingTable; 