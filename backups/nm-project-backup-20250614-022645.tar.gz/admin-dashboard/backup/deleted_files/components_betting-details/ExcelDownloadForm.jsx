import React, { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  Box,
  FormControl,
  FormControlLabel,
  Checkbox,
  Grid,
  TextField,
  IconButton,
  Divider
} from '@mui/material';
import { Close, Download } from '@mui/icons-material';
import { defaultColumns } from './bettingTableUtils';

const ExcelDownloadForm = ({ open, onClose, filteredBettings }) => {
  const [selectedColumns, setSelectedColumns] = useState(
    defaultColumns.reduce((acc, col) => {
      acc[col.id] = true;
      return acc;
    }, {})
  );
  
  const [fileName, setFileName] = useState('베팅내역');
  
  const handleColumnChange = (columnId) => {
    setSelectedColumns(prev => ({
      ...prev,
      [columnId]: !prev[columnId]
    }));
  };
  
  const handleSelectAll = () => {
    const allSelected = defaultColumns.every(col => selectedColumns[col.id]);
    
    if (allSelected) {
      // 모두 선택 해제
      const newSelectedColumns = {};
      defaultColumns.forEach(col => {
        newSelectedColumns[col.id] = false;
      });
      setSelectedColumns(newSelectedColumns);
    } else {
      // 모두 선택
      const newSelectedColumns = {};
      defaultColumns.forEach(col => {
        newSelectedColumns[col.id] = true;
      });
      setSelectedColumns(newSelectedColumns);
    }
  };
  
  const handleDownload = () => {
    // 실제 다운로드 로직 구현
    console.log('엑셀 다운로드:', {
      fileName,
      selectedColumns,
      dataCount: filteredBettings.length
    });
    
    // 다운로드 후 닫기
    onClose();
  };
  
  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h6">엑셀 다운로드</Typography>
        <IconButton onClick={onClose} size="small">
          <Close />
        </IconButton>
      </DialogTitle>
      
      <Divider />
      
      <DialogContent>
        <Box sx={{ mb: 3 }}>
          <Typography variant="subtitle1" gutterBottom>
            파일 설정
          </Typography>
          
          <TextField
            label="파일명"
            value={fileName}
            onChange={(e) => setFileName(e.target.value)}
            fullWidth
            margin="normal"
            size="small"
            helperText="확장자(.xlsx)는 자동으로 추가됩니다."
          />
        </Box>
        
        <Box>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="subtitle1">
              다운로드할 열 선택
            </Typography>
            
            <Button 
              size="small" 
              onClick={handleSelectAll}
              variant="outlined"
            >
              {defaultColumns.every(col => selectedColumns[col.id]) ? '모두 해제' : '모두 선택'}
            </Button>
          </Box>
          
          <Grid container spacing={1}>
            {defaultColumns.map((column) => (
              <Grid item xs={6} sm={4} md={3} key={column.id}>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={selectedColumns[column.id] || false}
                      onChange={() => handleColumnChange(column.id)}
                      size="small"
                    />
                  }
                  label={column.label}
                />
              </Grid>
            ))}
          </Grid>
        </Box>
        
        <Box sx={{ mt: 3, p: 2, bgcolor: '#f5f5f5', borderRadius: 1 }}>
          <Typography variant="body2">
            총 <strong>{filteredBettings.length}개</strong>의 데이터가 다운로드됩니다.
          </Typography>
        </Box>
      </DialogContent>
      
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose} variant="outlined">
          취소
        </Button>
        <Button 
          onClick={handleDownload} 
          variant="contained" 
          startIcon={<Download />}
          disabled={!Object.values(selectedColumns).some(Boolean)}
        >
          다운로드
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ExcelDownloadForm; 