import React from 'react';
import { Card, CardContent, CardHeader, Typography, Box, Divider, useTheme } from '@mui/material';
import PropTypes from 'prop-types';

/**
 * 정보를 표시하는 카드 컴포넌트
 * @param {string} title - 카드 타이틀
 * @param {string} subtitle - 카드 서브타이틀 (선택적)
 * @param {React.ReactNode} icon - 카드 아이콘 (선택적)
 * @param {React.ReactNode} action - 카드 액션 (선택적)
 * @param {React.ReactNode} actionIcon - 추가 액션 아이콘 (선택적)
 * @param {React.ReactNode} footer - 카드 푸터 (선택적)
 * @param {React.ReactNode} children - 카드 내용
 * @param {object} sx - 추가 스타일
 * @param {object} headerProps - 카드 헤더에 전달될 추가 props (선택적)
 */
const InfoCard = ({ 
  title, 
  subtitle, 
  icon, 
  action, 
  actionIcon, 
  footer, 
  children, 
  sx, 
  headerProps = {} 
}) => {
  const theme = useTheme();

  return (
    <Card
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        boxShadow: theme.shadows[1],
        borderRadius: 2,
        overflow: 'hidden',
        ...sx,
      }}
    >
      <CardHeader
        title={
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            {icon && (
              <Box sx={{ mr: 1.5, display: 'flex', alignItems: 'center' }}>
                {icon}
              </Box>
            )}
            <Typography variant="h6">{title}</Typography>
            {actionIcon && (
              <Box sx={{ ml: 1, display: 'flex', alignItems: 'center' }}>
                {actionIcon}
              </Box>
            )}
          </Box>
        }
        subheader={subtitle && <Typography variant="body2" color="text.secondary">{subtitle}</Typography>}
        action={action}
        sx={{ py: 2 }}
        {...headerProps}
      />
      
      <Divider />
      
      <CardContent sx={{ flexGrow: 1, pt: 2 }}>
        {children}
      </CardContent>
      
      {footer && (
        <>
          <Divider />
          <Box sx={{ p: 2 }}>
            {footer}
          </Box>
        </>
      )}
    </Card>
  );
};

InfoCard.propTypes = {
  title: PropTypes.string.isRequired,
  subtitle: PropTypes.string,
  icon: PropTypes.node,
  action: PropTypes.node,
  actionIcon: PropTypes.node,
  footer: PropTypes.node,
  children: PropTypes.node.isRequired,
  sx: PropTypes.object,
  headerProps: PropTypes.object,
};

InfoCard.defaultProps = {
  subtitle: '',
  icon: null,
  action: null,
  actionIcon: null,
  footer: null,
  sx: {},
  headerProps: {},
};

export default InfoCard; 