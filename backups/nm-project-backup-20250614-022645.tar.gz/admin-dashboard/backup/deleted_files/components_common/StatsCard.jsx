import React from 'react';
import { Card, CardContent, Typography, Box, useTheme, IconButton, Tooltip } from '@mui/material';
import PropTypes from 'prop-types';
import { Info as InfoIcon } from '@mui/icons-material';

/**
 * 통계 정보를 표시하는 카드 컴포넌트
 * @param {string} title - 카드 제목
 * @param {string|number} value - 표시할 값
 * @param {React.ReactNode} icon - 카드에 표시할 아이콘
 * @param {string} color - 아이콘 배경 색상
 * @param {React.ReactNode} trend - 추세 표시 (선택적)
 * @param {object} sx - 추가 스타일
 * @param {object} headerProps - 헤더에 적용할 추가 props (드래그 핸들 등)
 * @param {string} description - 카드 설명 (선택사항, 느낌표 아이콘 툴팁에 표시)
 */
const StatsCard = ({ title, value, icon, color, trend, sx, headerProps, description }) => {
  const theme = useTheme();

  // 기본 설명 텍스트
  const defaultDescription = `${title} 통계 카드입니다. 이 카드는 관련 데이터의 주요 지표를 보여줍니다.`;

  return (
    <Card
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        boxShadow: theme.shadows[1],
        borderRadius: 2,
        overflow: 'hidden',
        position: 'relative',
        ...sx
      }}
    >
      <CardContent sx={{ flex: '1 0 auto', p: 3 }}>
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
          {...headerProps}
        >
          <Box>
            <Typography variant="subtitle2" color="text.secondary" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
              {title}
              <Tooltip 
                title={description || defaultDescription}
                arrow
                placement="top"
              >
                <IconButton size="small" sx={{ ml: 0.5, color: '#5E6278', padding: '2px' }}>
                  <InfoIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Typography>
            <Typography variant="h4" sx={{ fontWeight: 600 }}>
              {value}
            </Typography>
            {trend && (
              <Box sx={{ mt: 1 }}>
                {trend}
              </Box>
            )}
          </Box>
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              bgcolor: `${color}15`,
              color: color,
              width: 56,
              height: 56,
              borderRadius: '50%',
            }}
          >
            {icon}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
};

StatsCard.propTypes = {
  title: PropTypes.string.isRequired,
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  icon: PropTypes.node.isRequired,
  color: PropTypes.string.isRequired,
  trend: PropTypes.node,
  sx: PropTypes.object,
  headerProps: PropTypes.object,
  description: PropTypes.string,
};

StatsCard.defaultProps = {
  trend: null,
  sx: {},
  headerProps: {},
  description: null,
};

export default StatsCard; 