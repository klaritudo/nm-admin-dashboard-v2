import React, { useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '@mui/material/styles';
import { Box, Typography, useMediaQuery } from '@mui/material';

/**
 * LineChart 컴포넌트
 * 
 * 선 그래프를 표시하는 컴포넌트입니다. 현재는 Canvas API를 사용하여 간단한 그래프를 그립니다.
 * 실제 프로젝트에서는 Chart.js, Recharts, Nivo 등의 라이브러리로 대체하는 것을 권장합니다.
 * 
 * @param {Object} props
 * @param {Array} props.data - 차트에 표시할 데이터 배열
 * @param {Array} props.labels - X축 라벨 배열
 * @param {Array} props.datasets - 데이터셋 배열 (각 데이터셋은 label, data, color를 포함)
 * @param {string} props.title - 차트 제목
 * @param {Object} props.sx - 추가 스타일
 */
const LineChart = ({ data, labels, datasets, title, sx }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  
  // 캔버스 크기 조정 함수
  const resizeCanvas = () => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    
    if (!canvas || !container) return;
    
    // 디바이스 픽셀 비율 가져오기
    const pixelRatio = window.devicePixelRatio || 1;
    
    // 컨테이너 크기에 맞게 캔버스 크기 조정
    const { width, height } = container.getBoundingClientRect();
    
    // 디스플레이 및 캔버스 크기 설정
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    canvas.width = width * pixelRatio;
    canvas.height = height * pixelRatio;
    
    // 크기가 변경되면 차트 다시 그리기
    drawChart(canvas, width * pixelRatio, height * pixelRatio, pixelRatio);
  };
  
  // 차트 그리기 함수
  const drawChart = (canvas, width, height, pixelRatio = 1) => {
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // 픽셀 비율 적용
    ctx.scale(pixelRatio, pixelRatio);
    
    // 캔버스 초기화
    ctx.clearRect(0, 0, width, height);
    
    // 실제 그리기 너비와 높이 계산 (픽셀 비율로 나누기)
    const drawWidth = width / pixelRatio;
    const drawHeight = height / pixelRatio;
    
    // 그리드 그리기
    ctx.beginPath();
    ctx.strokeStyle = theme.palette.divider;
    ctx.lineWidth = 0.5;
    
    // 수평 그리드 라인
    const gridCount = 5;
    for (let i = 0; i <= gridCount; i++) {
      const y = drawHeight * 0.8 - (i * (drawHeight * 0.7) / gridCount) + drawHeight * 0.1;
      ctx.moveTo(drawWidth * 0.1, y);
      ctx.lineTo(drawWidth * 0.9, y);
    }
    
    // 수직 그리드 라인 (labels 기반)
    if (labels && labels.length > 0) {
      const step = (drawWidth * 0.8) / (labels.length - 1);
      for (let i = 0; i < labels.length; i++) {
        const x = drawWidth * 0.1 + i * step;
        ctx.moveTo(x, drawHeight * 0.1);
        ctx.lineTo(x, drawHeight * 0.9);
      }
    }
    ctx.stroke();
    
    // 라벨 그리기
    if (labels && labels.length > 0) {
      // 모바일에서는 글꼴 크기 줄이기
      const fontSize = isMobile ? 9 : 11;
      ctx.font = `${fontSize}px 'Noto Sans KR', sans-serif`;
      ctx.fillStyle = theme.palette.text.secondary;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      
      const step = (drawWidth * 0.8) / (labels.length - 1);
      
      // 라벨 간격 계산
      const labelCount = labels.length;
      const skipFactor = labelCount > 7 && isMobile ? 2 : 1; // 모바일에서는 라벨 간격 조정
      
      for (let i = 0; i < labels.length; i++) {
        // 모바일에서는 일부 라벨만 표시
        if (isMobile && i % skipFactor !== 0 && i !== labels.length - 1) continue;
        
        const x = drawWidth * 0.1 + i * step;
        ctx.fillText(labels[i], x, drawHeight * 0.95);
      }
    }
    
    // 데이터셋 그리기
    if (datasets && datasets.length > 0) {
      // 모든 데이터셋의 최대값 찾기
      let maxValue = 0;
      datasets.forEach(dataset => {
        if (!dataset.data || dataset.data.length === 0) return;
        const datasetMax = Math.max(...dataset.data);
        if (datasetMax > maxValue) maxValue = datasetMax;
      });
      
      // 여유 공간 10% 추가
      maxValue *= 1.1;
      
      datasets.forEach((dataset, index) => {
        const { data, color } = dataset;
        if (!data || data.length === 0) return;
        
        // 데이터 정규화
        const normalizedData = data.map(value => 1 - (value / maxValue));
        
        // 선 그리기
        ctx.beginPath();
        ctx.strokeStyle = color || theme.palette.primary.main;
        ctx.lineWidth = 2;
        
        const step = (drawWidth * 0.8) / (data.length - 1);
        for (let i = 0; i < data.length; i++) {
          const x = drawWidth * 0.1 + i * step;
          const y = drawHeight * 0.1 + normalizedData[i] * (drawHeight * 0.8);
          
          if (i === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
        
        // 포인트 그리기
        ctx.fillStyle = color || theme.palette.primary.main;
        
        // 숫자 형식화 함수
        const formatNumber = (num) => {
          if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
          } else if (num >= 1000) {
            return (num / 1000).toFixed(0) + 'K';
          }
          return num.toString();
        };
        
        // 값 줄바꿈 방지를 위한 텍스트 위치 최적화
        let prevTextX = -100; // 이전 텍스트 X 위치 초기화
        const minTextSpace = isMobile ? 40 : 65; // 텍스트 간 최소 간격
        
        for (let i = 0; i < data.length; i++) {
          const x = drawWidth * 0.1 + i * step;
          const y = drawHeight * 0.1 + normalizedData[i] * (drawHeight * 0.8);
          
          // 포인트 그리기
          ctx.beginPath();
          ctx.arc(x, y, isMobile ? 3 : 4, 0, Math.PI * 2);
          ctx.fill();
          
          // 값 표시 위치 및 간격 조정
          const skipFactor = isMobile ? 2 : 1;
          if ((i % skipFactor === 0 || i === data.length - 1) && 
              (x - prevTextX > minTextSpace || i === 0 || i === data.length - 1)) {
            ctx.fillStyle = theme.palette.text.primary;
            ctx.font = `bold ${isMobile ? 9 : 11}px 'Noto Sans KR', sans-serif`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';
            
            // 숫자 포맷팅 적용
            const formattedValue = formatNumber(data[i]);
            ctx.fillText(formattedValue, x, y - (isMobile ? 8 : 10));
            
            prevTextX = x; // 이전 텍스트 위치 업데이트
            ctx.fillStyle = color || theme.palette.primary.main;
          }
        }
      });
    }
    
    // 레전드 그리기
    if (datasets && datasets.length > 0) {
      ctx.font = `${isMobile ? 9 : 11}px 'Noto Sans KR', sans-serif`;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      
      let legendY = drawHeight * 0.05;
      
      // 모바일에서 레전드 배치 조정
      const legendItemWidth = isMobile ? 80 : 100;
      let legendX = drawWidth * 0.1;
      
      datasets.forEach((dataset, index) => {
        const { label, color } = dataset;
        if (!label) return;
        
        // 레전드가 화면을 벗어나면 다음 줄로
        if (legendX + legendItemWidth > drawWidth * 0.9) {
          legendX = drawWidth * 0.1;
          legendY += 20;
        }
        
        ctx.fillStyle = color || theme.palette.primary.main;
        ctx.fillRect(legendX, legendY, 16, 4);
        
        ctx.fillStyle = theme.palette.text.primary;
        ctx.fillText(label, legendX + 20, legendY + 2);
        
        legendX += legendItemWidth;
      });
    }
  };
  
  // 화면 크기 변경 감지 및 첫 렌더링 시 캔버스 크기 조정
  useEffect(() => {
    // 초기 크기 설정
    const timerId = setTimeout(resizeCanvas, 100); // 약간의 지연을 주어 컴포넌트가 마운트된 후 실행
    
    // 윈도우 resize 이벤트 리스너 추가
    const handleResize = () => {
      clearTimeout(timerId);
      setTimeout(resizeCanvas, 100); // debounce 적용
    };
    
    window.addEventListener('resize', handleResize);
    
    // clean-up
    return () => {
      window.removeEventListener('resize', handleResize);
      clearTimeout(timerId);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  
  // 데이터나 라벨이 변경되면 차트 다시 그리기
  useEffect(() => {
    if (canvasRef.current && containerRef.current) {
      const timerId = setTimeout(() => {
        resizeCanvas();
      }, 100);
      
      return () => clearTimeout(timerId);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, labels, datasets, isMobile, theme]);
  
  return (
    <Box sx={{ position: 'relative', width: '100%', height: '100%', ...sx }}>
      {title && (
        <Typography 
          variant="subtitle1" 
          gutterBottom 
          fontWeight={500}
          sx={{ mb: 1 }}
        >
          {title}
        </Typography>
      )}
      <Box 
        ref={containerRef}
        sx={{ 
          width: '100%', 
          height: 'calc(100% - 30px)',
          position: 'relative'
        }}
      >
        <canvas 
          ref={canvasRef}
          style={{ 
            width: '100%', 
            height: '100%',
            display: 'block'
          }} 
        />
      </Box>
    </Box>
  );
};

LineChart.propTypes = {
  data: PropTypes.array,
  labels: PropTypes.array,
  datasets: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string,
      data: PropTypes.array,
      color: PropTypes.string,
    })
  ),
  title: PropTypes.string,
  sx: PropTypes.object,
};

LineChart.defaultProps = {
  data: [],
  labels: [],
  datasets: [],
  sx: {},
};

export default LineChart;
