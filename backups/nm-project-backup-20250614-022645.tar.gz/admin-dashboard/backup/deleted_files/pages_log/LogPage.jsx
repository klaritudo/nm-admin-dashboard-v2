import React, { useCallback } from 'react';
import { Box, Typography, Paper } from '@mui/material';

// 로그 테이블 컬럼 정의
const logColumnDefs = [
  { field: 'rowNum', headerName: 'No.', width: 70, sortable: true, filter: true },
  { field: 'id', headerName: '로그 ID', width: 120, sortable: true, filter: true },
  { field: 'timestamp', headerName: '발생시간', width: 180, sortable: true, filter: true },
  { 
    field: 'level', 
    headerName: '레벨', 
    width: 100, 
    sortable: true, 
    filter: true,
    cellRenderer: (params) => {
      const level = params.value;
      let color = 'inherit';
      
      if (level === 'ERROR') color = 'error.main';
      else if (level === 'WARNING') color = 'warning.main';
      else if (level === 'INFO') color = 'info.main';
      else if (level === 'DEBUG') color = 'success.light';
      
      return <Typography color={color}>{level}</Typography>;
    }
  },
  { field: 'source', headerName: '소스', width: 150, sortable: true, filter: true },
  { field: 'message', headerName: '메시지', flex: 1, sortable: true, filter: true },
  { field: 'user', headerName: '사용자', width: 120, sortable: true, filter: true }
];

// 샘플 로그 데이터 생성 함수
const getLogData = (count = 100) => {
  const levels = ['ERROR', 'WARNING', 'INFO', 'DEBUG'];
  const sources = ['SERVER', 'CLIENT', 'DATABASE', 'API', 'AUTH', 'SYSTEM'];
  const users = ['admin', 'user', 'guest', 'system', null];
  
  return Array.from({ length: count }, (_, i) => {
    const now = new Date();
    now.setHours(now.getHours() - Math.floor(Math.random() * 24 * 7)); // 최근 1주일 내 랜덤 시간
    
    const level = levels[Math.floor(Math.random() * levels.length)];
    const source = sources[Math.floor(Math.random() * sources.length)];
    const user = users[Math.floor(Math.random() * users.length)];
    
    let message = '';
    if (level === 'ERROR') {
      message = `오류가 발생했습니다: ${Math.random().toString(36).substring(2, 8)}`;
    } else if (level === 'WARNING') {
      message = `주의가 필요합니다: ${Math.random().toString(36).substring(2, 8)}`;
    } else if (level === 'INFO') {
      message = `정보: ${Math.random().toString(36).substring(2, 8)}`;
    } else {
      message = `디버그 정보: ${Math.random().toString(36).substring(2, 8)}`;
    }
    
    return {
      id: `LOG-${10000 + i}`,
      timestamp: now.toISOString(),
      level,
      source,
      message,
      user,
      type: source, // 필터링을 위해 source를 type으로도 사용
      status: level, // 필터링을 위해 level을 status로도 사용
      date: now.toISOString() // 날짜 필터링을 위해 date 필드 추가
    };
  });
};

// 로그 행 클릭 처리
const handleLogRowClick = (params) => {
  console.log('로그 상세 정보:', params.data);
  // 로그 상세 정보 표시 로직 (모달 등)
};

// 로그 페이지 컴포넌트
const LogPage = () => {
  // 필터 변경 시 처리
  const handleFilterChange = useCallback((filters) => {
    console.log('적용된 필터:', filters);
    // 필터 변경 시 서버에 요청하거나 다른 작업 수행
  }, []);
  
  // 데이터 로드 완료 시 처리
  const handleDataLoaded = useCallback((data) => {
    console.log(`${data.length}개의 로그 데이터 로드됨`);
    // 데이터 로드 완료 후 추가 작업
  }, []);
  
  return (
    <Paper sx={{ p: 3, m: 2 }}>
      <Typography variant="h5" gutterBottom>시스템 로그</Typography>
      <Box sx={{ p: 4, textAlign: 'center', bgcolor: '#f5f5f5', borderRadius: 2 }}>
        <Typography variant="h6">BaseTable 컴포넌트가 삭제되었습니다.</Typography>
        <Typography variant="body1" color="text.secondary" sx={{ mt: 2 }}>
          해당 컴포넌트는 사용할 수 없습니다.
        </Typography>
      </Box>
    </Paper>
  );
};

export default LogPage; 