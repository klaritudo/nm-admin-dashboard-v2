// 당일정산 페이지
import React from 'react';
import { Box, Typography, Paper } from '@mui/material';

const TodaySettlementPage = () => {
  return (
    <Box sx={{ p: 3 }}>
      <Paper elevation={0} sx={{ p: 3, borderRadius: '8px' }}>
        <Typography variant="h5" fontWeight={600} gutterBottom>
          당일정산
        </Typography>
        <Typography variant="body1">
          당일정산 페이지입니다. 테이블 컴포넌트가 제거되었습니다.
        </Typography>
      </Paper>
    </Box>
  );
};

export default TodaySettlementPage; 