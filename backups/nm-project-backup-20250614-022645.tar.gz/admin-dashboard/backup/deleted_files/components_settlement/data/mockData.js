// 당일정산 목업 데이터
export const getSettlementMockData = () => {
  // 계층적 구조를 가진 회원 유형
  // 배열의 순서가 계층 구조를 고려하지 않는 문제 해결
  const hierarchicalMembers = [
    { id: 1, type: '1차 에이전트', level: 0, parentId: null }, // 최상위

    { id: 2, type: '2차 에이전트', level: 1, parentId: 1 },    // 1차의 자식
    { id: 3, type: '2차 에이전트', level: 1, parentId: 1 },    // 1차의 자식

    { id: 4, type: '3차 에이전트', level: 2, parentId: 2 },    // 2차의 자식
    { id: 5, type: '3차 에이전트', level: 2, parentId: 2 },    // 2차의 자식
    { id: 6, type: '3차 에이전트', level: 2, parentId: 3 },    // 2차의 자식

    { id: 7, type: '일반회원', level: 3, parentId: 4 },       // 3차의 자식
    { id: 8, type: '일반회원', level: 3, parentId: 5 },       // 3차의 자식
    { id: 9, type: '일반회원', level: 3, parentId: 5 },       // 3차의 자식
    { id: 10, type: '일반회원', level: 3, parentId: 6 }       // 3차의 자식
  ];
  
  return Array.from({ length: 100 }, (_, index) => {
    // 회원 정보 결정 (인덱스에 따라 순환)
    const memberIndex = index % hierarchicalMembers.length;
    const member = hierarchicalMembers[memberIndex];
    
    // 베팅 금액과 당첨 금액 생성
    const slotBet = Math.floor(Math.random() * 10000000) + 100000;
    const slotWin = Math.floor(slotBet * (0.7 + Math.random() * 0.6)); // 70%~130% 당첨률
    const slotBetWinDiff = slotBet - slotWin;
    
    const casinoBet = Math.floor(Math.random() * 20000000) + 200000;
    const casinoWin = Math.floor(casinoBet * (0.7 + Math.random() * 0.6)); // 70%~130% 당첨률
    const casinoBetWinDiff = casinoBet - casinoWin;
    
    // 롤링 관련 데이터 생성
    const slotRollingPercent = Math.floor(Math.random() * 5) + 1; // 1%~5%
    const slotRollingAmount = Math.floor(slotBet * (slotRollingPercent / 100));
    const slotRollingTotal = Math.floor(slotRollingAmount * (0.8 + Math.random() * 0.4)); // 80%~120%
    
    const casinoRollingPercent = Math.floor(Math.random() * 5) + 1; // 1%~5%
    const casinoRollingAmount = Math.floor(casinoBet * (casinoRollingPercent / 100));
    const casinoRollingTotal = Math.floor(casinoRollingAmount * (0.8 + Math.random() * 0.4)); // 80%~120%
    
    // 입출금 관련 데이터 생성
    const deposit = Math.floor(Math.random() * 5000000) + 100000;
    const withdrawal = Math.floor(Math.random() * 4000000) + 50000;
    const depositWithdrawalDiff = deposit - withdrawal;
    
    // 순이익 및 루징 계산
    const slotNetProfit = slotBetWinDiff - slotRollingTotal;
    const casinoNetProfit = casinoBetWinDiff - casinoRollingTotal;
    
    const slotLosing = slotNetProfit < 0 ? Math.abs(slotNetProfit) * 0.1 : 0; // 손실의 10%
    const casinoLosing = casinoNetProfit < 0 ? Math.abs(casinoNetProfit) * 0.1 : 0; // 손실의 10%
    
    // 합계 계산
    const totalBet = slotBet + casinoBet;
    const totalWin = slotWin + casinoWin;
    const totalRollingAmount = slotRollingAmount + casinoRollingAmount;
    const totalRollingTotal = slotRollingTotal + casinoRollingTotal;
    const totalNetProfit = slotNetProfit + casinoNetProfit;
    const totalLosing = slotLosing + casinoLosing;
    
    // 마지막 보유금과 롤링금
    const lastBalance = Math.floor(Math.random() * 10000000) + 500000;
    const lastRollingBalance = Math.floor(Math.random() * 5000000) + 100000;
    
    // 계층 정보 추가
    const hierarchyInfo = {
      level: member.level,
      parentId: member.parentId
    };
    
    return {
      id: index + 1,
      type: member.type,
      username: `user${index + 1}${index % 3 === 0 ? ' (닉네임' + (index + 1) + ')' : ''}`,
      
      // 계층 정보
      ...hierarchyInfo,
      
      // 입출금 관련
      deposit,
      withdrawal,
      depositWithdrawalDiff,
      
      // 슬롯 관련
      slotBet,
      slotWin,
      slotBetWinDiff,
      slotRollingPercent,
      slotRollingAmount,
      slotRollingTotal,
      slotNetProfit,
      slotLosing,
      
      // 카지노 관련
      casinoBet,
      casinoWin,
      casinoBetWinDiff,
      casinoRollingPercent,
      casinoRollingAmount,
      casinoRollingTotal,
      casinoNetProfit,
      casinoLosing,
      
      // 합계
      totalBet,
      totalWin,
      totalRollingAmount,
      totalRollingTotal,
      totalNetProfit,
      totalLosing,
      
      // 마지막 잔액
      lastBalance,
      lastRollingBalance
    };
  });
}; 