import React from 'react';
import { Chip } from '@mui/material';
import dayjs from 'dayjs';

/**
 * 결제 유형별 칩 스타일 정의
 */
const getPaymentTypeChipStyle = (type) => {
  switch (type) {
    case '입금':
      return { bgcolor: '#e3f2fd', color: '#0d47a1', border: '1px solid #bbdefb' }; // 파란색
    case '출금':
      return { bgcolor: '#fce4ec', color: '#c2185b', border: '1px solid #f8bbd0' }; // 분홍색
    case '베팅':
      return { bgcolor: '#e8f5e9', color: '#2e7d32', border: '1px solid #c8e6c9' }; // 녹색
    case '당첨':
      return { bgcolor: '#fff8e1', color: '#ff8f00', border: '1px solid #ffecb3' }; // 노란색
    default:
      return { bgcolor: '#f5f5f5', color: '#616161', border: '1px solid #e0e0e0' }; // 회색
  }
};

/**
 * 회원 유형별 칩 스타일 정의
 */
const getMemberTypeChipStyle = (type) => {
  switch (type) {
    case '본사':
      return { bgcolor: '#0D47A1', color: '#ffffff', border: '1px solid #0D47A1', level: 1 }; // 진한 파랑/흰색
    case '부본사':
      return { bgcolor: '#1565C0', color: '#ffffff', border: '1px solid #1565C0', level: 2 }; // 파랑/흰색
    case '총판':
      return { bgcolor: '#2196F3', color: '#ffffff', border: '1px solid #2196F3', level: 4 }; // 밝은 파랑/흰색
    case '매장':
      return { bgcolor: '#42A5F5', color: '#ffffff', border: '1px solid #42A5F5', level: 5 }; // 더 밝은 파랑/흰색
    case '회원1':
      return { bgcolor: '#E3F2FD', color: '#0D47A1', border: '1px solid #BBDEFB', level: 6 }; // 아주 연한 파랑/진한 파랑
    case '회원2':
      return { bgcolor: '#E8F5E9', color: '#1B5E20', border: '1px solid #C8E6C9', level: 7 }; // 연한 녹색/진한 녹색
    case '회원3':
      return { bgcolor: '#FFF3E0', color: '#E65100', border: '1px solid #FFE0B2', level: 8 }; // 연한 주황/진한 주황
    case '회원4':
      return { bgcolor: '#F3E5F5', color: '#4A148C', border: '1px solid #E1BEE7', level: 9 }; // 연한 보라/진한 보라
    case '회원5':
      return { bgcolor: '#E0F7FA', color: '#006064', border: '1px solid #B2EBF2', level: 10 }; // 연한 청록/진한 청록
    default:
      return { bgcolor: '#E0E0E0', color: '#424242', border: '1px solid #BDBDBD', level: 0 }; // 회색/진한 회색
  }
};

/**
 * 정산 테이블의 컬럼 정의 생성 함수
 * @param {Object} params 컬럼 정의에 필요한 파라미터
 * @returns {Array} 컬럼 정의 배열
 */
export const getColumnDefs = (params) => {
  const {
    visibleColumns,
    formatNumber,
    dateCellRenderer,
    indentMode = true // 들여쓰기 모드 (기본값: true)
  } = params;
  
  // 기본 컬럼 정의
  const basicCols = [
    { 
      field: 'checked', 
      headerName: '',
      checkboxSelection: true,
      headerCheckboxSelection: true,
      width: 60, 
      minWidth: 60,
      maxWidth: 60,
      cellClass: 'checkbox-cell',
      headerClass: 'checkbox-header',
      sortable: false,
      filter: false,
      resizable: false,
      suppressSizeToFit: true,
      suppressMovable: false,
      flex: 0,
      hide: !visibleColumns.checked,
      checkboxOnlyRowSelection: true
    },
    { 
      field: 'rowNum', 
      headerName: 'No.', 
      width: 60,
      minWidth: 60,
      maxWidth: 60,
      resizable: false,
      suppressSizeToFit: true,
      suppressMovable: false,
      flex: 0,
      hide: !visibleColumns.rowNum
    },
    { 
      field: 'transactionDatetime', 
      headerName: '일시', 
      width: 120,
      minWidth: 120,
      resizable: true,
      flex: 1,
      hide: !visibleColumns.transactionDatetime,
      cellRenderer: (params) => {
        if (!params.value) return '';
        const date = dayjs(params.value);
        return (
          <div style={{ 
            display: 'flex', 
            flexDirection: 'column',
            alignItems: 'center',
            width: '100%'
          }}>
            <div style={{ marginBottom: '4px' }}>
              {date.format('YYYY-MM-DD')}
            </div>
            <div>
              {date.format('HH:mm:ss')}
            </div>
          </div>
        );
      }
    },
    { 
      field: 'type', 
      headerName: '유형', 
      width: 100,
      minWidth: 100,
      resizable: true,
      flex: 0.8,
      hide: !visibleColumns.type,
      cellRenderer: (params) => {
        if (!params.value) return null;
        
        const style = getPaymentTypeChipStyle(params.value);
        
        return (
          <div style={{ 
            display: 'flex', 
            justifyContent: 'center', 
            alignItems: 'center', 
            width: '100%' 
          }}>
            <Chip 
              label={params.value}
              size="small"
              sx={{
                bgcolor: style.bgcolor,
                color: style.color,
                fontSize: '0.75rem',
                height: '24px',
                fontWeight: 500,
                '& .MuiChip-label': {
                  padding: '0 8px'
                },
                border: style.border
              }}
            />
          </div>
        );
      }
    },
    { 
      field: 'memberType', 
      headerName: '회원유형', 
      width: 120,
      minWidth: 120,
      resizable: true,
      flex: 1,
      hide: !visibleColumns.memberType,
      cellRenderer: (params) => {
        if (!params.value) return null;
        
        const style = getMemberTypeChipStyle(params.value);
        const level = style.level || 0;
        
        // 들여쓰기 모드일 때만 들여쓰기와 레벨 표시자를 적용
        const indent = indentMode ? Array(level).fill('\u00A0\u00A0').join('') : '';
        const levelIndicator = (indentMode && level > 0) ? '▷ ' : '';
        
        return (
          <div style={{ 
            display: 'flex', 
            justifyContent: indentMode ? 'flex-start' : 'center', 
            alignItems: 'center', 
            width: '100%' 
          }}>
            {indentMode && <span style={{ whiteSpace: 'pre' }}>{indent}</span>}
            <Chip 
              label={levelIndicator + params.value}
              size="small"
              sx={{
                bgcolor: style.bgcolor,
                color: style.color,
                fontSize: '0.75rem',
                height: '24px',
                fontWeight: 500,
                '& .MuiChip-label': {
                  padding: '0 8px'
                },
                border: style.border
              }}
            />
          </div>
        );
      }
    },
    { 
      field: 'username', 
      headerName: '아이디', 
      width: 120,
      minWidth: 120,
      resizable: true,
      flex: 1,
      hide: !visibleColumns.username
    },
    { 
      field: 'amount', 
      headerName: '금액', 
      width: 140,
      minWidth: 140,
      resizable: true,
      flex: 1.2,
      hide: !visibleColumns.amount,
      type: 'numericColumn',
      cellRenderer: (params) => {
        const value = params.value || 0;
        const type = params.data.type;
        let color = '#000000';
        
        if (type === '입금' || type === '당첨') {
          color = '#4caf50'; // 녹색
        } else if (type === '출금' || type === '베팅') {
          color = '#f44336'; // 빨간색
        }
        
        return (
          <span style={{ 
            color: color,
            fontWeight: 'bold'
          }}>
            {formatNumber(value)}
          </span>
        );
      }
    },
    { 
      field: 'previousBalance', 
      headerName: '이전보유금', 
      width: 140,
      minWidth: 140,
      resizable: true,
      flex: 1.2,
      hide: !visibleColumns.previousBalance,
      type: 'numericColumn',
      cellRenderer: (params) => formatNumber(params.value)
    },
    { 
      field: 'currentBalance', 
      headerName: '현재보유금', 
      width: 140,
      minWidth: 140,
      resizable: true,
      flex: 1.2,
      hide: !visibleColumns.currentBalance,
      type: 'numericColumn',
      cellRenderer: (params) => formatNumber(params.value)
    },
    { 
      field: 'game', 
      headerName: '게임종류', 
      width: 120,
      minWidth: 120,
      resizable: true,
      flex: 1,
      hide: !visibleColumns.game
    },
    { 
      field: 'betDetail', 
      headerName: '베팅내역', 
      width: 140,
      minWidth: 140,
      resizable: true,
      flex: 1.2,
      hide: !visibleColumns.betDetail
    },
    { 
      field: 'note', 
      headerName: '비고', 
      width: 140,
      minWidth: 140,
      resizable: true,
      flex: 1.2,
      hide: !visibleColumns.note
    },
    { 
      field: 'ip', 
      headerName: 'IP', 
      width: 130,
      minWidth: 130,
      resizable: true,
      flex: 1,
      hide: !visibleColumns.ip
    }
  ];

  // 요약 컬럼 (입금, 출금, 베팅, 당첨금, 수익) 정의
  const summaryCols = {
    headerName: '요약',
    headerClass: 'summary-group-header',
    marryChildren: true,
    openByDefault: true,
    children: [
      { 
        field: 'depositTotal', 
        headerName: '입금합계', 
        width: 140,
        minWidth: 140,
        resizable: true,
        type: 'numericColumn',
        cellRenderer: (params) => formatNumber(params.value),
        flex: 1,
        hide: !visibleColumns.depositTotal,
        cellStyle: { color: '#4caf50', fontWeight: 'bold' }
      },
      { 
        field: 'withdrawalTotal', 
        headerName: '출금합계', 
        width: 140,
        minWidth: 140,
        resizable: true,
        type: 'numericColumn',
        cellRenderer: (params) => formatNumber(params.value),
        flex: 1,
        hide: !visibleColumns.withdrawalTotal,
        cellStyle: { color: '#f44336', fontWeight: 'bold' }
      },
      { 
        field: 'bettingTotal', 
        headerName: '베팅합계', 
        width: 140,
        minWidth: 140,
        resizable: true,
        type: 'numericColumn',
        cellRenderer: (params) => formatNumber(params.value),
        flex: 1,
        hide: !visibleColumns.bettingTotal,
        cellStyle: { color: '#f44336', fontWeight: 'bold' }
      },
      { 
        field: 'winningTotal', 
        headerName: '당첨합계', 
        width: 140,
        minWidth: 140,
        resizable: true,
        type: 'numericColumn',
        cellRenderer: (params) => formatNumber(params.value),
        flex: 1,
        hide: !visibleColumns.winningTotal,
        cellStyle: { color: '#4caf50', fontWeight: 'bold' }
      },
      { 
        field: 'profitTotal', 
        headerName: '수익합계', 
        width: 140,
        minWidth: 140,
        resizable: true,
        type: 'numericColumn',
        cellRenderer: (params) => formatNumber(params.value),
        flex: 1,
        hide: !visibleColumns.profitTotal,
        cellStyle: (params) => ({
          color: params.value > 0 ? '#4caf50' : params.value < 0 ? '#f44336' : null,
          fontWeight: 'bold'
        })
      }
    ]
  };

  // 최종 컬럼 정의 설정
  const finalColumns = [];
  
  // 기본 컬럼들을 순서대로 추가 (IP 제외)
  const columnsBeforeSummary = basicCols.filter(col => 
    col.field !== 'ip'
  );
  columnsBeforeSummary.forEach(col => {
    finalColumns.push(col);
  });
  
  // 요약 그룹 추가
  finalColumns.push(summaryCols);
  
  // IP 추가
  const columnsAfterSummary = basicCols.filter(col => 
    col.field === 'ip'
  );
  columnsAfterSummary.forEach(col => {
    finalColumns.push(col);
  });
  
  return finalColumns;
};

/**
 * AG Grid 기본 컬럼 설정 가져오기
 * @returns {Object} 기본 컬럼 설정
 */
export const getDefaultColDef = () => {
  return {
    resizable: true,
    sortable: true,
    filter: true,
    flex: 1,
    minWidth: 100,
    wrapText: true,
    autoHeight: true,
    suppressAutoSize: false,
    cellStyle: { 
      textOverflow: 'initial', 
      whiteSpace: 'normal', 
      lineHeight: '20px',
      padding: '8px 10px',
      boxSizing: 'border-box'
    },
    headerClass: 'center-header',
    suppressMovable: false
  };
};