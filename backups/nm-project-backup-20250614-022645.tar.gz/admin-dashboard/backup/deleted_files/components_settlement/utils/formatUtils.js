import dayjs from 'dayjs';

/**
 * 숫자 형식화 함수
 * @param {number} value 형식화할 숫자
 * @returns {string} 형식화된 숫자 문자열
 */
export const formatNumber = (value) => {
  if (value === undefined || value === null) return '';
  // 소수점 이하 표시하지 않음
  return new Intl.NumberFormat('ko-KR', { maximumFractionDigits: 0 }).format(value);
};

/**
 * 날짜 형식화 함수
 * @param {string|Date} date 형식화할 날짜
 * @returns {string} 형식화된 날짜 문자열
 */
export const formatDate = (date) => {
  if (!date) return '';
  return dayjs(date).format('YYYY-MM-DD HH:mm');
};

/**
 * 거래 유형 스타일 계산
 * @param {string} type 거래 유형
 * @returns {Object} 스타일 객체
 */
export const getTransactionTypeStyle = (type) => {
  // 입금, 출금, 베팅, 당첨 등 거래 유형별 스타일
  if (type === '입금' || type === '당첨') {
    return { color: '#4caf50', fontWeight: 'bold' }; // 녹색
  } else if (type === '출금' || type === '베팅') {
    return { color: '#f44336', fontWeight: 'bold' }; // 빨간색
  }
  
  return { color: '#000000', fontWeight: 'normal' };
};

/**
 * 손익 스타일 계산
 * @param {number} value 손익 값
 * @returns {Object} 스타일 객체
 */
export const getProfitStyle = (value) => {
  return {
    color: value > 0 ? '#4caf50' : value < 0 ? '#f44336' : null,
    fontWeight: 'bold'
  };
};