/**
 * AG Grid 커스텀 스타일 정의
 */
export const agGridStyles = `
  .ag-theme-material .ag-header-group-cell.summary-group-header {
    background-color: #f5f7fa;
    font-weight: bold;
  }
  .ag-theme-material .ag-row-selected {
    background-color: rgba(63, 81, 181, 0.08);
  }
  /* 체크박스 컬럼 스타일링 */
  .ag-theme-material .checkbox-cell {
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    padding: 0 !important;
    margin: 0 !important;
  }
  .ag-theme-material .checkbox-header {
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    padding: 0 !important;
    margin: 0 !important;
  }
  /* 체크박스 셀 내부 요소 중앙 정렬 */
  .ag-theme-material .checkbox-cell .ag-cell-wrapper {
    width: 100% !important;
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    padding: 0 !important;
  }
  .ag-theme-material .checkbox-header .ag-header-cell-comp-wrapper {
    width: 100% !important;
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    padding: 0 !important;
  }
  /* 체크박스 셀 내부 요소 추가 스타일링 */
  .ag-theme-material .ag-cell-wrapper.ag-checkbox-selection {
    justify-content: center !important;
    align-items: center !important;
  }
  /* 체크박스 컴포넌트 자체 스타일링 */
  .ag-theme-material .ag-selection-checkbox {
    margin: 0 auto !important;
    display: flex !important;
    justify-content: center !important;
  }
  /* 체크박스 자체 스타일 조정 */
  .ag-theme-material .ag-checkbox-input-wrapper {
    width: 16px !important;
    height: 16px !important;
    margin: 0 auto !important;
    justify-self: center !important;
  }
  /* 체크박스 컨테이너 스타일 */
  .ag-theme-material .ag-checkbox-component {
    display: flex !important;
    justify-content: center !important;
    width: 100% !important;
  }
  /* 체크박스 헤더 텍스트 숨기기 */
  .ag-theme-material .checkbox-header .ag-header-cell-text {
    display: none !important;
  }
  /* 체크박스 관련 중복 요소 숨기기 */
  .ag-theme-material .checkbox-cell .ag-cell-wrapper > *:not(:first-child) {
    display: none !important;
  }
  .ag-theme-material .checkbox-header .ag-header-cell-comp-wrapper > *:not(:first-child) {
    display: none !important;
  }
  /* No. 컬럼 스타일링 */
  .ag-theme-material .ag-cell[col-id="rowNum"] {
    padding-left: 8px !important;
    text-align: left !important;
    justify-content: flex-start !important;
  }
  /* 드래그 중인 컬럼 스타일 */
  .ag-theme-material .ag-header-cell-moving {
    background-color: #e3f2fd !important;
    opacity: 0.9 !important;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2) !important;
    z-index: 50 !important;
  }
  /* 드래그 중인 컬럼의 고스트 스타일 */
  .ag-theme-material .ag-header-cell-ghost {
    background-color: #e3f2fd !important;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2) !important;
    z-index: 51 !important;
  }
  /* 드롭 영역 스타일 */
  .ag-theme-material .ag-header-drop-zone {
    background-color: rgba(63, 81, 181, 0.1) !important;
  }
  /* 드롭 영역 활성화 스타일 */
  .ag-theme-material .ag-header-drop-zone-active {
    background-color: rgba(63, 81, 181, 0.3) !important;
  }
  /* 세로 구분선 제거 */
  .ag-theme-material .ag-cell {
    border-right: none !important;
  }
  .ag-theme-material .ag-header-cell {
    border-right: none !important;
  }
  /* 셀 클릭 시 테두리 수정 */
  .ag-theme-material .ag-cell-focus, 
  .ag-theme-material .ag-cell-focus.ag-cell-range-selected, 
  .ag-theme-material .ag-cell-focus.ag-cell-range-single-cell {
    border: 1px solid #3f51b5 !important;
    background-color: transparent !important;
    outline: none !important;
    z-index: 1 !important;
    box-sizing: border-box !important;
    clip-path: inset(0px 0px 0px 0px) !important;
    overflow: visible !important;
    padding: 7px !important;
    transition: border 0.1s ease !important;
    animation: none !important;
  }
  /* 셀 선택 시 테두리가 다른 셀에 가려지지 않도록 설정 */
  .ag-theme-material .ag-ltr .ag-cell-focus:not(.ag-cell-range-selected):focus {
    z-index: 2 !important;
    background-color: transparent !important;
    animation: none !important;
  }
  /* 헤더와 내용 중앙정렬 */
  .ag-theme-material .ag-header-cell-label {
    justify-content: center !important;
    width: 100% !important;
    padding: 0 !important;
  }
  .ag-theme-material .ag-cell {
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    padding: 0 8px !important;
  }
  /* 모든 셀의 내용 중앙 정렬 */
  .ag-theme-material .ag-cell-wrapper {
    width: 100% !important;
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
  }
  /* No. 컬럼도 중앙 정렬로 통일 */
  .ag-theme-material .ag-cell[col-id="rowNum"] {
    padding: 0 8px !important;
    text-align: center !important;
    justify-content: center !important;
  }
  /* 숫자 컬럼도 중앙 정렬로 통일 */
  .ag-theme-material .ag-cell.ag-cell-number {
    justify-content: center !important;
  }
  /* 헤더 메뉴 아이콘 위치 조정 */
  .ag-theme-material .ag-header-cell-menu-button {
    position: absolute !important;
    right: 0 !important;
    top: 50% !important;
    transform: translateY(-50%) !important;
  }
  /* 헤더 텍스트 컨테이너 너비 조정 */
  .ag-theme-material .ag-header-cell-comp-wrapper {
    width: 100% !important;
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
  }
  /* 셀 내부 여백 통일 */
  .ag-theme-material .ag-cell-value {
    width: 100% !important;
    text-align: center !important;
  }
  /* 체크박스 컬럼 정렬 보완 */
  .ag-theme-material .ag-header-select-all {
    justify-content: center !important;
    padding: 0 !important;
  }
  /* 헤더 고정 관련 스타일 */
  .ag-theme-material .ag-header {
    position: sticky;
    top: 0;
    z-index: 1;
  }
  /* 스크롤 허용 관련 스타일 추가 */
  .ag-theme-material {
    overflow: auto !important;
  }
  .ag-theme-material .ag-body-viewport {
    overflow-y: auto !important;
    overflow-x: auto !important;
  }
  .ag-theme-material .ag-body-horizontal-scroll {
    display: block !important;
  }
  /* 페이지네이션 상단 배치 스타일 */
  .table-pagination-top {
    margin-bottom: 10px;
    display: flex;
    justify-content: flex-start;
  }
  /* 추가: 그리드 컨테이너 그림자 효과 */
  .ag-theme-material {
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08) !important;
    border-radius: 6px !important;
    border: 1px solid #eee !important;
    overflow: hidden !important;
  }
  .ag-theme-material .ag-header {
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05) !important;
  }
  .ag-theme-material .no-click-selection {
    pointer-events: none;
  }
  .ag-theme-material .click-target-only {
    pointer-events: all;
  }
  /* 클릭 방지 영역 내부 요소만 클릭 가능하도록 */
  .ag-theme-material .prevent-select-cell button,
  .ag-theme-material .prevent-select-cell select,
  .ag-theme-material .prevent-select-cell div.custom-click-element {
    pointer-events: all;
  }
  /* 체크박스 셀은 항상 클릭 가능하도록 */
  .ag-theme-material .ag-selection-checkbox {
    pointer-events: all !important;
  }
  
  /* 헤더 그룹 스타일 */
  .ag-theme-material .ag-header-group-cell {
    background-color: #f8f9fa;
    font-weight: 600;
  }
  .ag-theme-material .summary-group-header {
    background-color: #e8f4fd;
  }
  .ag-theme-material .summary-group-header .ag-header-group-cell-label {
    font-weight: 600;
    color: #0d47a1;
  }
`;