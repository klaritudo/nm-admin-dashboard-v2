import { useState, useCallback, useEffect } from 'react';
import dayjs from 'dayjs';

/**
 * 검색 및 필터링 기능을 관리하는 커스텀 훅
 * @param {Array} tableData 원본 테이블 데이터
 * @param {Function} setFilteredData 필터링된 데이터 설정 함수
 * @param {Function} setTotalItems 전체 아이템 수 설정 함수
 * @param {Function} setPage 페이지 설정 함수
 * @param {Object} gridRef AG Grid 참조
 * @returns {Object} 검색 및 필터링 관련 상태 및 함수
 */
const useFilterAndSearch = (tableData, setFilteredData, setTotalItems, setPage, gridRef) => {
  // 검색어
  const [searchText, setSearchText] = useState('');
  
  // 날짜 범위 필터
  const [dateRange, setDateRange] = useState({
    startDate: null,
    endDate: null
  });
  
  // 활성화된 필터
  const [activeFilters, setActiveFilters] = useState({
    memberType: 'all',       // 회원 유형별 필터
    transactionType: 'all',  // 거래 유형별 필터
    gameType: 'all'          // 게임 종류별 필터
  });
  
  // 검색어 변경 핸들러
  const handleSearchChange = useCallback((event) => {
    setSearchText(event.target.value);
  }, []);
  
  // 검색어 초기화 핸들러
  const handleClearSearch = useCallback(() => {
    setSearchText('');
  }, []);
  
  // 날짜 범위 필터 변경 핸들러
  const handleDateRangeChange = useCallback((newDateRange) => {
    setDateRange(newDateRange);
  }, []);
  
  // 기타 필터 변경 핸들러
  const handleFilterChange = useCallback((filterType, value) => {
    setActiveFilters(prev => ({
      ...prev,
      [filterType]: value
    }));
  }, []);
  
  // 데이터에 필터 적용
  const applyFiltersToData = useCallback(() => {
    if (!tableData) return [];

    let result = [...tableData];

    // 검색어 필터링
    if (searchText.trim()) {
      const searchLower = searchText.toLowerCase().trim();
      result = result.filter(item => {
        return (
          (item.username && item.username.toLowerCase().includes(searchLower)) ||
          (item.memberType && item.memberType.toLowerCase().includes(searchLower)) ||
          (item.note && item.note.toLowerCase().includes(searchLower)) ||
          (item.game && item.game.toLowerCase().includes(searchLower)) ||
          (item.betDetail && item.betDetail.toLowerCase().includes(searchLower))
        );
      });
    }

    // 날짜 범위 필터링
    if (dateRange.startDate && dateRange.endDate) {
      const startDate = dayjs(dateRange.startDate).startOf('day');
      const endDate = dayjs(dateRange.endDate).endOf('day');
      
      result = result.filter(item => {
        const itemDate = dayjs(item.transactionDatetime);
        return itemDate.isAfter(startDate) && itemDate.isBefore(endDate);
      });
    }

    // 회원 유형별 필터링
    if (activeFilters.memberType !== 'all') {
      result = result.filter(item => item.memberType === activeFilters.memberType);
    }

    // 거래 유형별 필터링
    if (activeFilters.transactionType !== 'all') {
      result = result.filter(item => item.type === activeFilters.transactionType);
    }

    // 게임 종류별 필터링
    if (activeFilters.gameType !== 'all') {
      result = result.filter(item => item.game === activeFilters.gameType);
    }

    // rowNum 재할당
    result = result.map((item, index) => ({
      ...item,
      originalRowNum: item.rowNum, // 원본 rowNum 보존
      rowNum: index + 1 // 새로운 rowNum 할당
    }));

    return result;
  }, [tableData, searchText, dateRange, activeFilters]);

  // 필터 변경 시 데이터 업데이트
  useEffect(() => {
    if (tableData) {
      const filtered = applyFiltersToData();
      setFilteredData(filtered);
      setTotalItems(filtered.length);
      setPage(0);
      
      // AG Grid가 초기화되었으면 직접 데이터 설정
      if (gridRef.current && gridRef.current.api) {
        gridRef.current.api.setRowData(filtered);
        gridRef.current.api.paginationGoToPage(0);
      }
    }
  }, [
    tableData,
    searchText,
    dateRange.startDate,
    dateRange.endDate,
    activeFilters.memberType,
    activeFilters.transactionType,
    activeFilters.gameType,
    applyFiltersToData,
    setFilteredData,
    setTotalItems,
    setPage,
    gridRef
  ]);

  return {
    searchText,
    setSearchText,
    dateRange,
    setDateRange,
    activeFilters,
    setActiveFilters,
    handleSearchChange,
    handleClearSearch,
    handleDateRangeChange,
    handleFilterChange,
    applyFiltersToData
  };
};

export default useFilterAndSearch;