import { useState, useCallback } from 'react';
import { getDefaultColDef } from '../utils/columnConfig';

/**
 * 컬럼 관리 (표시 옵션, 정렬 등) 관련 기능을 제공하는 훅
 * @param {Object} gridApi AG Grid API
 * @param {Object} columnApi AG Grid Column API
 * @returns {Object} 컬럼 관리 관련 상태 및 핸들러
 */
const useColumnManagement = (gridApi, columnApi) => {
  // 컬럼 표시 상태
  const [visibleColumns, setVisibleColumns] = useState({
    checked: true,
    rowNum: true,
    transactionDatetime: true,
    type: true,
    memberType: true,
    username: true,
    amount: true,
    previousBalance: true,
    currentBalance: true,
    game: true,
    betDetail: true,
    note: false,
    ip: false,
    depositTotal: true,
    withdrawalTotal: true,
    bettingTotal: true,
    winningTotal: true,
    profitTotal: true
  });

  // 정렬 설정
  const [sortConfig, setSortConfig] = useState({
    key: 'transactionDatetime',
    direction: 'desc'
  });

  // 기본 컬럼 정의
  const defaultColDef = getDefaultColDef();

  // 표시 옵션 메뉴 관련 상태
  const [displayOptionsAnchorEl, setDisplayOptionsAnchorEl] = useState(null);

  // 표시 옵션 메뉴 열기
  const handleDisplayOptionsClick = useCallback((event) => {
    setDisplayOptionsAnchorEl(event.currentTarget);
  }, []);

  // 표시 옵션 메뉴 닫기
  const handleDisplayOptionsClose = useCallback(() => {
    setDisplayOptionsAnchorEl(null);
  }, []);

  // 컬럼 표시 상태 변경
  const handleVisibleColumnsChange = useCallback((columnId, isVisible) => {
    // 컬럼 가시성 업데이트
    setVisibleColumns(prev => ({
      ...prev,
      [columnId]: isVisible
    }));

    // AG Grid 컬럼 가시성 직접 업데이트
    if (columnApi) {
      const column = columnApi.getColumn(columnId);
      if (column) {
        column.setVisible(isVisible);
      }
    }
  }, [columnApi]);

  // 레이아웃 초기화
  const handleResetLayout = useCallback(() => {
    // 기본 컬럼 가시성으로 리셋
    const defaultVisibility = {
      checked: true,
      rowNum: true,
      transactionDatetime: true,
      type: true,
      memberType: true,
      username: true,
      amount: true,
      previousBalance: true,
      currentBalance: true,
      game: true,
      betDetail: true,
      note: false,
      ip: false,
      depositTotal: true,
      withdrawalTotal: true,
      bettingTotal: true,
      winningTotal: true,
      profitTotal: true
    };

    // 상태 업데이트
    setVisibleColumns(defaultVisibility);

    // AG Grid 컬럼 가시성 직접 업데이트
    if (columnApi) {
      Object.keys(defaultVisibility).forEach(columnId => {
        const column = columnApi.getColumn(columnId);
        if (column) {
          column.setVisible(defaultVisibility[columnId]);
        }
      });
    }

    // 기본 정렬 설정으로 리셋
    const defaultSortConfig = {
      key: 'transactionDatetime',
      direction: 'desc'
    };
    setSortConfig(defaultSortConfig);

    // AG Grid 정렬 설정 직접 업데이트
    if (gridApi) {
      try {
        if (typeof gridApi.applyColumnState === 'function') {
          gridApi.applyColumnState({
            state: [
              {
                colId: defaultSortConfig.key,
                sort: defaultSortConfig.direction
              }
            ],
            defaultState: { sort: null }
          });
        } else if (typeof gridApi.setSortModel === 'function') {
          const sortModel = [{
            colId: defaultSortConfig.key,
            sort: defaultSortConfig.direction
          }];
          gridApi.setSortModel(sortModel);
        }
      } catch (error) {
        console.error('정렬 설정 적용 중 오류 발생:', error);
      }
    }

    // 컬럼 크기 조정
    if (gridApi) {
      setTimeout(() => {
        gridApi.sizeColumnsToFit();
      }, 100);
    }
  }, [gridApi, columnApi]);

  return {
    visibleColumns,
    setVisibleColumns,
    sortConfig,
    setSortConfig,
    defaultColDef,
    displayOptionsAnchorEl,
    handleDisplayOptionsClick,
    handleDisplayOptionsClose,
    handleVisibleColumnsChange,
    handleResetLayout
  };
};

export default useColumnManagement;