import { useRef, useCallback, useEffect } from 'react';

/**
 * 테이블 크기 조정 기능을 제공하는 훅
 * @param {number} tableHeight 현재 테이블 높이
 * @param {Function} setTableHeight 테이블 높이 설정 함수
 * @returns {Object} 테이블 크기 조정 관련 상태 및 함수
 */
const useTableResize = (tableHeight, setTableHeight) => {
  const resizerRef = useRef(null);
  const isResizingRef = useRef(false);
  const startYRef = useRef(0);
  const startHeightRef = useRef(0);

  // 마우스 다운 이벤트 핸들러
  const handleMouseDown = useCallback((e) => {
    isResizingRef.current = true;
    startYRef.current = e.clientY;
    startHeightRef.current = tableHeight;
    
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    
    // 드래그 중 텍스트 선택 방지
    document.body.style.userSelect = 'none';
    
    // 커서 스타일 변경
    document.body.style.cursor = 'row-resize';
    
    // AG Grid 컨테이너에 리사이징 클래스 추가
    const gridContainer = document.querySelector('.ag-theme-material');
    if (gridContainer) {
      gridContainer.classList.add('resizing');
    }
  }, [tableHeight]);

  // 마우스 이동 이벤트 핸들러
  const handleMouseMove = useCallback((e) => {
    if (!isResizingRef.current) return;
    
    const deltaY = e.clientY - startYRef.current;
    let newHeight = Math.max(300, startHeightRef.current + deltaY);
    
    // 최대 높이 제한 (화면 높이의 80%)
    const maxHeight = window.innerHeight * 0.8;
    newHeight = Math.min(newHeight, maxHeight);
    
    // 테이블 높이 설정
    setTableHeight(newHeight);
    
    // AG Grid 테이블 높이 직접 설정
    const gridContainer = document.querySelector('.ag-theme-material');
    if (gridContainer) {
      gridContainer.style.height = `${newHeight}px`;
    }
  }, [setTableHeight]);

  // 마우스 업 이벤트 핸들러
  const handleMouseUp = useCallback(() => {
    isResizingRef.current = false;
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('mouseup', handleMouseUp);
    
    // 드래그 중 텍스트 선택 방지 해제
    document.body.style.userSelect = '';
    
    // 커서 스타일 복원
    document.body.style.cursor = '';
    
    // AG Grid 컨테이너에 리사이징 클래스 제거
    const gridContainer = document.querySelector('.ag-theme-material');
    if (gridContainer) {
      gridContainer.classList.remove('resizing');
    }
  }, [handleMouseMove]);

  // 컴포넌트 마운트/언마운트 시 이벤트 리스너 정리
  useEffect(() => {
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      document.body.style.userSelect = '';
      document.body.style.cursor = '';
    };
  }, [handleMouseMove, handleMouseUp]);

  return {
    resizerRef,
    handleMouseDown
  };
};

export default useTableResize;