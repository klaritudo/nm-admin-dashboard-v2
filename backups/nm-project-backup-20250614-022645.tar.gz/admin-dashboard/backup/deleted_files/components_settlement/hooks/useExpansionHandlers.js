import { useState, useCallback, useEffect } from 'react';

/**
 * 행 확장/축소 관련 핸들러를 제공하는 커스텀 훅
 * TodaySettlementPage와 TypeCellRenderer에 분산된 로직을 통합
 * 
 * @param {Object} options - 옵션 객체
 * @param {boolean} options.initialExpandAll - 초기 모두 펼치기 상태
 * @param {Function} options.convertToHierarchicalData - 평면 배열을 계층적 구조로 변환하는 함수
 * @param {Function} options.flattenHierarchicalData - 계층 구조를 평탄화하는 함수
 * @returns {Object} 확장/축소 관련 상태 및 핸들러
 */
const useExpansionHandlers = (options = {}) => {
  const {
    initialExpandAll = true,
    convertToHierarchicalData,
    flattenHierarchicalData
  } = options;

  // 확장/축소 상태 관리
  const [expandAll, setExpandAll] = useState(initialExpandAll);
  const [hierarchicalData, setHierarchicalData] = useState([]);
  const [flattenedData, setFlattenedData] = useState([]);

  // 계층 데이터가 변경되면 평탄화된 데이터 업데이트
  useEffect(() => {
    if (flattenHierarchicalData && hierarchicalData.length > 0) {
      updateFlattenedData(hierarchicalData);
    }
  }, [hierarchicalData, flattenHierarchicalData]);
  
  // expandAll 상태 변경 시 모든 노드의 확장 상태 업데이트
  useEffect(() => {
    updateAllNodesExpansion(expandAll);
  }, [expandAll]);

  /**
   * 평탄화된 데이터 업데이트 함수
   * @param {Array} hierarchical - 계층적 구조 데이터
   */
  const updateFlattenedData = useCallback((hierarchical) => {
    if (!flattenHierarchicalData) return;
    
    const flattened = flattenHierarchicalData(hierarchical);
    setFlattenedData(flattened);
  }, [flattenHierarchicalData]);

  /**
   * 모든 노드의 확장 상태 업데이트
   * @param {boolean} expanded - 확장 상태
   */
  const updateAllNodesExpansion = useCallback((expanded) => {
    const updateNodes = (nodes) => {
      if (!nodes) return [];
      
      return nodes.map(node => ({
        ...node,
        expanded,
        children: updateNodes(node.children)
      }));
    };
    
    setHierarchicalData(prev => updateNodes(prev));
  }, []);

  /**
   * 노드 확장/축소 토글 이벤트 핸들러
   * @param {Object} event - 이벤트 객체
   */
  const handleToggleExpansion = useCallback((event) => {
    const { nodeId, expanded } = event.detail;
    
    // 노드 ID를 찾아 확장 상태 업데이트
    const updateNodeExpanded = (nodes) => {
      if (!nodes) return [];
      
      return nodes.map(node => {
        if (node.id === nodeId) {
          // 현재 노드 업데이트
          
          // 동일한 상태로 설정하지 않기
          if (node.expanded === expanded) {
            return node; // 중요: 변경이 없으면 동일한 참조 반환
          }
          
          // 새로운 객체 생성하여 확장 상태 변경
          return { ...node, expanded };
        }
        
        if (node.children && node.children.length > 0) {
          // 자식 노드 재귀적으로 업데이트
          const updatedChildren = updateNodeExpanded(node.children);
          
          // 자식에 변경이 있는 경우에만 새 객체 생성
          if (updatedChildren !== node.children) {
            return { ...node, children: updatedChildren };
          }
          
          // 변경이 없으면 동일한 참조 반환
          return node;
        }
        
        return node;
      });
    };
    
    // 상태 업데이트를 더 간단하게 처리
    setHierarchicalData(prev => {
      const updated = updateNodeExpanded(prev);
      return updated;
    });
  }, []);

  /**
   * 데이터 로드 및 초기화 함수
   * @param {Array} mockData - 목업 데이터
   */
  const initializeData = useCallback((mockData) => {
    if (!convertToHierarchicalData || !mockData) return;
    
    // 계층적 구조로 변환
    const hierarchical = convertToHierarchicalData(mockData, expandAll);
    setHierarchicalData(hierarchical);
    
    // 평탄화된 데이터 생성
    updateFlattenedData(hierarchical);
  }, [convertToHierarchicalData, expandAll, updateFlattenedData]);

  /**
   * 확장/축소 토글 핸들러
   */
  const handleExpandAllToggle = useCallback(() => {
    setExpandAll(prev => !prev);
  }, []);

  // 이벤트 리스너 등록 및 제거
  useEffect(() => {
    // 이벤트 리스너 등록
    window.addEventListener('settlement-table:toggle-expansion', handleToggleExpansion);
    
    // 컴포넌트 언마운트 시 이벤트 리스너 제거
    return () => {
      window.removeEventListener('settlement-table:toggle-expansion', handleToggleExpansion);
    };
  }, [handleToggleExpansion]);

  return {
    expandAll,
    hierarchicalData,
    flattenedData,
    setExpandAll,
    setHierarchicalData,
    setFlattenedData,
    updateFlattenedData,
    updateAllNodesExpansion,
    handleToggleExpansion,
    initializeData,
    handleExpandAllToggle
  };
};

export default useExpansionHandlers;
