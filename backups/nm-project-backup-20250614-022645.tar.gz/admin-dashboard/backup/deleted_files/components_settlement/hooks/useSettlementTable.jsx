import { useState, useCallback, useEffect, useRef } from 'react';
import dayjs from 'dayjs';

/**
 * 정산 테이블 데이터 및 페이지네이션 관리 훅
 * 테이블 데이터 로드, 페이지네이션, 행 선택 기능 등을 관리
 */
const useSettlementTable = () => {
  // 상태 관리
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [tableData, setTableData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [page, setPage] = useState(0);
  const [pageSize, setPageSize] = useState(25);
  const [totalItems, setTotalItems] = useState(0);
  const [tableHeight, setTableHeight] = useState(500);
  const [rowData, setRowData] = useState([]);
  
  const gridRef = useRef(null);
  const [gridApi, setGridApi] = useState(null);
  const [columnApi, setColumnApi] = useState(null);
  
  // 요약 데이터
  const [summaryData, setSummaryData] = useState({
    totalDeposit: 0,
    totalWithdrawal: 0,
    totalBetting: 0,
    totalWinning: 0,
    netProfit: 0
  });

  // 목업 데이터 생성
  const getMockData = useCallback(() => {
    // 정산 내역 데이터 생성
    const transactionTypes = ['입금', '출금', '베팅', '당첨'];
    const gameTypes = ['슬롯', '룰렛', '바카라', '블랙잭', '포커'];
    const memberTypes = ['본사', '부본사', '총판', '매장', '회원1', '회원2', '회원3', '회원4', '회원5'];
    
    // 오늘 날짜 기준으로 데이터 생성
    const today = dayjs();
    let startTime = today.startOf('day');
    
    // 회원별 요약 데이터를 저장할 객체
    const memberSummary = {};
    
    // 트랜잭션 데이터 생성
    const transactions = Array.from({ length: 200 }).map((_, i) => {
      // 모의 거래 시간 (오늘 자정부터 지금까지의 무작위 시간)
      const minutes = Math.floor(Math.random() * 60 * 24); // 하루 최대 분
      const transactionTime = startTime.add(minutes, 'minute');
      
      // 거래 유형 선택
      const type = transactionTypes[Math.floor(Math.random() * transactionTypes.length)];
      
      // 회원 ID 생성 (1~50 사이의 회원 ID 사용)
      const memberId = Math.floor(Math.random() * 50) + 1;
      const username = `user${memberId}`;
      
      // 회원 유형 선택
      const memberType = memberTypes[Math.floor(Math.random() * memberTypes.length)];
      
      // 금액 생성 (거래 유형에 따라 금액 범위 조정)
      let amount;
      switch (type) {
        case '입금':
          amount = Math.floor(Math.random() * 1000000) + 100000; // 10만원 ~ 110만원
          break;
        case '출금':
          amount = Math.floor(Math.random() * 900000) + 100000; // 10만원 ~ 100만원
          break;
        case '베팅':
          amount = Math.floor(Math.random() * 500000) + 10000; // 1만원 ~ 51만원
          break;
        case '당첨':
          amount = Math.floor(Math.random() * 800000) + 5000; // 5천원 ~ 80만5천원
          break;
        default:
          amount = Math.floor(Math.random() * 500000) + 10000;
      }
      
      // 이전 잔액 (임의 생성)
      const previousBalance = Math.floor(Math.random() * 5000000) + 500000;
      
      // 현재 잔액 계산 (거래 유형에 따라 다르게 계산)
      let currentBalance;
      if (type === '입금' || type === '당첨') {
        currentBalance = previousBalance + amount;
      } else {
        currentBalance = previousBalance - amount;
      }
      
      // 게임 종류 (베팅이나 당첨 거래일 경우만 설정)
      const game = (type === '베팅' || type === '당첨') ? 
        gameTypes[Math.floor(Math.random() * gameTypes.length)] : '';
      
      // 베팅 내역 (베팅 거래일 경우만 설정)
      const betDetail = type === '베팅' ? 
        `${game} - ${Math.random() > 0.5 ? '승' : '패'}` : '';
      
      // IP 주소 생성
      const ip = `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
      
      // 회원별 요약 데이터 업데이트
      if (!memberSummary[username]) {
        memberSummary[username] = {
          depositTotal: 0,
          withdrawalTotal: 0,
          bettingTotal: 0,
          winningTotal: 0,
          profitTotal: 0
        };
      }
      
      // 거래 유형에 따라 요약 데이터 업데이트
      switch (type) {
        case '입금':
          memberSummary[username].depositTotal += amount;
          break;
        case '출금':
          memberSummary[username].withdrawalTotal += amount;
          break;
        case '베팅':
          memberSummary[username].bettingTotal += amount;
          break;
        case '당첨':
          memberSummary[username].winningTotal += amount;
          break;
      }
      
      // 수익 업데이트
      memberSummary[username].profitTotal = (
        memberSummary[username].winningTotal - 
        memberSummary[username].bettingTotal + 
        memberSummary[username].depositTotal - 
        memberSummary[username].withdrawalTotal
      );
      
      return {
        id: i + 1,
        rowNum: i + 1,
        transactionDatetime: transactionTime.format('YYYY-MM-DD HH:mm:ss'),
        type,
        memberType,
        username,
        amount,
        previousBalance,
        currentBalance,
        game,
        betDetail,
        note: '',
        ip,
        checked: false,
        depositTotal: memberSummary[username].depositTotal,
        withdrawalTotal: memberSummary[username].withdrawalTotal,
        bettingTotal: memberSummary[username].bettingTotal,
        winningTotal: memberSummary[username].winningTotal,
        profitTotal: memberSummary[username].profitTotal
      };
    });
    
    // 시간 순으로 정렬 (최신순)
    transactions.sort((a, b) => {
      return dayjs(b.transactionDatetime).valueOf() - dayjs(a.transactionDatetime).valueOf();
    });
    
    // rowNum 재설정
    transactions.forEach((transaction, index) => {
      transaction.rowNum = index + 1;
    });
    
    // 전체 요약 데이터 계산
    let totalDeposit = 0;
    let totalWithdrawal = 0;
    let totalBetting = 0;
    let totalWinning = 0;
    
    Object.values(memberSummary).forEach(summary => {
      totalDeposit += summary.depositTotal;
      totalWithdrawal += summary.withdrawalTotal;
      totalBetting += summary.bettingTotal;
      totalWinning += summary.winningTotal;
    });
    
    const netProfit = totalWinning - totalBetting + totalDeposit - totalWithdrawal;
    
    // 요약 데이터 설정
    setSummaryData({
      totalDeposit,
      totalWithdrawal,
      totalBetting,
      totalWinning,
      netProfit
    });
    
    return transactions;
  }, []);

  // 데이터 로드
  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      // API 호출 대신 목업 데이터 사용
      const mockData = getMockData();
      setTableData(mockData);
      setTotalItems(mockData.length);
      
      // 필터링된 데이터 초기화 (rowNum 재할당)
      const initialFilteredData = mockData.map((item, index) => ({
        ...item,
        originalRowNum: item.rowNum, // 원본 rowNum 보존
        rowNum: index + 1 // 새로운 rowNum 할당
      }));
      setFilteredData(initialFilteredData);
      
      // AG Grid가 초기화되었으면 직접 데이터 설정
      if (gridRef.current && gridRef.current.api) {
        gridRef.current.api.setRowData(initialFilteredData);
      }
    } catch (err) {
      console.error('Error loading settlement data:', err);
      setError('데이터를 불러오는 중 오류가 발생했습니다.');
    } finally {
      setLoading(false);
    }
  }, [getMockData]);

  // 페이징된 데이터 가져오기
  const getPagedData = useCallback((data, sortConfig = { key: 'rowNum', direction: 'asc' }) => {
    if (!data || data.length === 0) return [];
    
    // 정렬 적용
    let sortedData = [...data];
    if (sortConfig.key) {
      sortedData.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    
    const start = page * pageSize;
    const end = start + pageSize;
    return sortedData.slice(start, end);
  }, [page, pageSize]);

  // 페이지 변경 핸들러
  const handleChangePage = useCallback((event, newPage) => {
    // Material UI 페이지네이션과 AG Grid 동기화
    if (gridRef.current && gridRef.current.api) {
      const currentPage = gridRef.current.api.paginationGetCurrentPage();
      if (currentPage !== newPage) {
        gridRef.current.api.paginationGoToPage(newPage);
      }
    }
    setPage(newPage);
  }, []);
  
  // AG Grid 페이지네이션 변경 핸들러
  const handleGridPaginationChanged = useCallback((params) => {
    if (params && params.api) {
      const currentPage = params.api.paginationGetCurrentPage();
      if (currentPage !== page) {
        setPage(currentPage);
      }
    }
  }, [page]);
  
  // 페이지당 행 수 변경 핸들러
  const handleChangeRowsPerPage = useCallback((event) => {
    const newRowsPerPage = parseInt(event.target.value, 10);
    
    // AG Grid 페이지 크기 설정
    if (gridApi) {
      gridApi.paginationSetPageSize(newRowsPerPage);
    }
    
    // 로컬 상태 업데이트
    setPageSize(newRowsPerPage);
    
    // 첫 페이지로 이동 (필요한 경우에만)
    if (page !== 0) {
      setPage(0);
      if (gridApi) {
        gridApi.paginationGoToPage(0);
      }
    }
    
    // 테이블 높이 조정
    const rowHeight = 48;
    const headerHeight = 48;
    const buffer = 20;
    const calculatedHeight = (rowHeight * Math.min(newRowsPerPage, 25)) + headerHeight + buffer;
    const minHeight = 400;
    const maxHeight = window.innerHeight * 0.7;
    const newTableHeight = Math.max(minHeight, Math.min(calculatedHeight, maxHeight));
    setTableHeight(newTableHeight);
    
    // 컬럼 크기 재조정
    setTimeout(() => {
      if (gridRef.current && gridRef.current.api) {
        gridRef.current.api.sizeColumnsToFit();
      }
    }, 100);
  }, [gridApi, gridRef, page]);

  // 데이터 새로고침
  const refreshData = useCallback(() => {
    loadData();
  }, [loadData]);

  // 형식화 함수
  const formatNumber = (value) => {
    if (value === undefined || value === null) return '';
    return new Intl.NumberFormat('ko-KR').format(value);
  };

  const formatDate = (date) => {
    if (!date) return '';
    return dayjs(date).format('YYYY-MM-DD HH:mm');
  };

  // 행 선택 가능 여부 결정
  const isRowSelectable = useCallback((params) => {
    // 모든 행에 대해 체크박스 표시
    return true;
  }, []);

  // 행 클래스 결정
  const getRowClass = useCallback((params) => {
    return '';
  }, []);

  // Grid Ready 핸들러
  const onGridReady = (params) => {
    setGridApi(params.api);
    setColumnApi(params.columnApi);
    
    // 기본 설정 적용
    params.api.sizeColumnsToFit();
    
    // 명시적으로 초기 페이지 크기 설정
    if (pageSize && params.api) {
      params.api.paginationSetPageSize(pageSize);
    }
    
    // 페이지네이션 변경 이벤트 리스너 등록
    params.api.addEventListener('paginationChanged', handleGridPaginationChanged);
  };

  // useEffect로 컴포넌트 마운트 시 데이터 로드
  useEffect(() => {
    loadData();
    
    // 컴포넌트 언마운트 시 이벤트 리스너 제거
    return () => {
      if (gridApi) {
        gridApi.removeEventListener('paginationChanged', handleGridPaginationChanged);
      }
    };
  }, [loadData, gridApi, handleGridPaginationChanged]);

  return {
    loading,
    error,
    tableData,
    setTableData,
    filteredData,
    setFilteredData,
    page,
    setPage,
    pageSize,
    setPageSize,
    totalItems,
    setTotalItems,
    tableHeight,
    setTableHeight,
    rowData,
    setRowData,
    gridRef,
    gridApi,
    setGridApi,
    columnApi,
    setColumnApi,
    refreshData,
    getMockData,
    getPagedData,
    handleChangePage,
    handleGridPaginationChanged,
    handleChangeRowsPerPage,
    formatNumber,
    formatDate,
    isRowSelectable,
    onGridReady,
    getRowClass,
    summaryData
  };
};

export default useSettlementTable;