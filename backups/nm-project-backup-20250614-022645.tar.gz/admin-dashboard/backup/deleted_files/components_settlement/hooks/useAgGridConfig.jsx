import React, { useState, useCallback, useRef, useEffect } from 'react';
import MemberDetailDialog from '../../member/MemberDetailDialog';

/**
 * AG Grid 설정 및 이벤트 핸들러를 관리하는 커스텀 훅
 * @param {Object} gridRef AG Grid 참조
 * @returns {Object} AG Grid 관련 상태 및 핸들러
 */
const useAgGridConfig = (gridRef, pageSize = 25) => {
  const [gridApi, setGridApi] = useState(null);
  const [columnApi, setColumnApi] = useState(null);
  
  // 회원 상세 정보 관련 상태 추가
  const [memberDetailOpen, setMemberDetailOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState(null);
  
  // 행 ID 가져오기 (고유 식별자를 위해 사용)
  const getRowId = useCallback((params) => {
    // 항상 문자열 ID 반환하여 일관성 유지
    return String(params.data.id);
  }, []);
  
  // 행 선택 가능 여부 결정
  const isRowSelectable = useCallback((params) => {
    // 모든 행 선택 가능
    return true;
  }, []);
  
  // 회원 상세 정보 다이얼로그 닫기 핸들러
  const handleMemberDetailClose = useCallback(() => {
    setMemberDetailOpen(false);
  }, []);

  // 회원 상세 정보 저장 핸들러
  const handleMemberDetailSave = useCallback((updatedMember) => {
    // 실제 구현에서는 API 호출 등의 로직이 필요
    console.log('회원 정보 업데이트:', updatedMember);
    setMemberDetailOpen(false);
  }, []);
  
  // 행 선택 변경 핸들러
  const handleSelectionChanged = useCallback(() => {
    if (gridRef.current && gridRef.current.api) {
      const selectedRows = gridRef.current.api.getSelectedRows();
      // 선택된 행 처리
    }
  }, [gridRef]);
  
  // 행 선택 변경 핸들러
  const handleRowSelected = useCallback((event) => {
    if (event.node && event.node.isSelected() !== undefined) {
      const selectedRows = gridApi?.getSelectedRows() || [];
      // 선택된 행 처리
    }
  }, [gridApi]);
  
  // 행 클릭 이벤트 핸들러 - 회원 상세 정보 다이얼로그 열기
  const onRowClicked = useCallback((params) => {
    // 사용자 ID 또는 username 필드가 있는 경우에만 다이얼로그 열기
    if (params.data && (params.data.userId || params.data.username || params.data.id)) {
      // 실제 API에서는 회원 ID로 상세 정보 조회 필요
      const memberData = {
        id: params.data.userId || params.data.id || Date.now(),
        username: params.data.username || params.data.id || '사용자ID',
        nickname: params.data.nickname || '닉네임없음',
        balance: params.data.balance || 0,
        // 기타 필요한 회원 정보 필드
        levelName: params.data.levelName || '회원',
        status: params.data.status || '정상',
        createdAt: params.data.createdAt || new Date().toISOString()
      };
      
      setSelectedMember(memberData);
      setMemberDetailOpen(true);
    }
  }, []);
  
  // Grid Ready 이벤트 핸들러
  const onGridReady = useCallback((params) => {
    setGridApi(params.api);
    setColumnApi(params.columnApi);
    
    // 전역에서 gridApi 및 columnApi에 접근할 수 있도록 설정
    window.settlementGridApi = params.api;
    window.settlementColumnApi = params.columnApi;

    // 페이지네이션 설정
    if (params.api) {
      params.api.paginationSetPageSize(pageSize);
    }

    // 초기 컬럼 크기 설정
    const columns = params.columnApi.getColumns();
    columns.forEach(col => {
      const colDef = col.getColDef();
      if (!colDef.width) {
        colDef.minWidth = 100;
        colDef.width = 120;
      }
    });
    
    // 저장된 컬럼 순서 및 상태 복원
    try {
      // 1. 컬럼 순서 복원 시도
      const savedColumnOrder = localStorage.getItem('settlement-column-order');
      if (savedColumnOrder) {
        const columnOrder = JSON.parse(savedColumnOrder);
        
        // 유효한 컬럼 ID만 필터링
        const validColumnOrder = columnOrder.filter(colId => 
          params.columnApi.getColumn(colId)
        );
        
        if (validColumnOrder.length > 0) {
          try {
            // 방법 1: applyColumnState 사용
            params.columnApi.applyColumnState({
              state: validColumnOrder.map(colId => ({
                colId,
                sort: null,
                sortIndex: null
              })),
              applyOrder: true,
              defaultState: { hide: false }
            });
            console.log('컬럼 순서 복원 완료 (applyColumnState)');
          } catch (error) {
            console.warn('applyColumnState 실패, 대체 방법 시도:', error);
            
            // 방법 2: moveColumns 사용
            try {
              if (typeof params.columnApi.moveColumns === 'function') {
                params.columnApi.moveColumns(validColumnOrder, 0);
                console.log('컬럼 순서 복원 완료 (moveColumns)');
              } else if (typeof params.columnApi.moveColumn === 'function') {
                // 방법 3: moveColumn 사용
                validColumnOrder.forEach((colId, index) => {
                  params.columnApi.moveColumn(colId, index);
                });
                console.log('컬럼 순서 복원 완료 (moveColumn)');
              }
            } catch (fallbackError) {
              console.error('컬럼 순서 복원 대체 방법 실패:', fallbackError);
            }
          }
        }
      }
      
      // 2. 컬럼 상태 복원 시도 (너비, 정렬 등)
      const savedColumnState = localStorage.getItem('settlement-column-state');
      if (savedColumnState) {
        const columnState = JSON.parse(savedColumnState);
        
        // 유효한 컬럼 상태만 적용
        const validState = columnState.filter(colState => {
          return colState && colState.colId && params.columnApi.getColumn(colState.colId);
        });
        
        if (validState.length > 0) {
          params.columnApi.applyColumnState({
            state: validState,
            applyOrder: false // 순서는 이미 적용했으므로 false
          });
          console.log('저장된 컬럼 상태 복원 완료');
        }
      }
    } catch (err) {
      console.warn('컬럼 상태 복원 중 오류:', err);
    }
    
    // 컬럼 크기 자동 조정
    setTimeout(() => {
      params.api.sizeColumnsToFit();
    }, 100);
  }, [pageSize]);

  // 컬럼 이동 완료 이벤트 핸들러
  const onColumnMoved = useCallback((params) => {
    // 컬럼 이동 처리 (필요한 경우 구현)
  }, []);
  
  // 그리드 데이터 첫 렌더링 시 이벤트 핸들러
  const onFirstDataRendered = useCallback((params) => {
    if (!gridRef.current || !gridRef.current.api) return;
    
    // 컬럼 스타일 직접 적용
    const applyColumnStyles = () => {
      // 그룹 헤더 및 일반 헤더 스타일 적용
      const headerElements = document.querySelectorAll('.ag-header-cell, .ag-header-group-cell');
      if (headerElements.length > 0) {
        headerElements.forEach(el => {
          // 기본 스타일 적용
          el.style.overflow = 'visible';
          el.style.position = 'relative';
          
          // 그룹 헤더면 배경색과 z-index 적용
          if (el.classList.contains('ag-header-group-cell')) {
            el.style.zIndex = '3';
            
            // 그룹 종류에 따른 배경색 적용
            if (el.classList.contains('deposit-group')) {
              el.style.backgroundColor = 'rgba(54, 153, 255, 0.1)';
            } else if (el.classList.contains('slot-group')) {
              el.style.backgroundColor = 'rgba(11, 183, 131, 0.1)';
            } else if (el.classList.contains('casino-group')) {
              el.style.backgroundColor = 'rgba(137, 80, 252, 0.1)';
            } else if (el.classList.contains('total-group')) {
              el.style.backgroundColor = 'rgba(246, 78, 96, 0.1)';
            }
          } else {
            el.style.zIndex = '2';
          }
          
          // 헤더 라벨 스타일 적용
          const label = el.querySelector('.ag-header-cell-label, .ag-header-group-cell-label');
          if (label) {
            label.style.display = 'flex';
            label.style.alignItems = 'center';
            label.style.justifyContent = 'center';
            label.style.height = '100%';
            label.style.padding = '0 8px';
            
            // 텍스트 스타일 적용
            const text = label.querySelector('span');
            if (text) {
              text.style.overflow = 'visible';
              text.style.textOverflow = 'clip';
              text.style.whiteSpace = 'normal';
            }
          }
        });
      }
      
      // 셀 스타일 직접 적용
      const cellElements = document.querySelectorAll('.ag-cell');
      if (cellElements.length > 0) {
        cellElements.forEach(el => {
          // 모든 셀에 기본 스타일 적용
          el.style.overflow = 'visible';
          el.style.zIndex = '1';
          
          // 유형 컬럼인 경우(HTML이 들어있는 셀) 스타일 추가
          if (el.getAttribute('col-id') === 'type') {
            el.style.display = 'flex';
            el.style.alignItems = 'center';
            el.style.justifyContent = 'center';
          }
          
          // 숫자 데이터인 경우(금액 셀) 스타일 추가
          const isNumericCol = el.getAttribute('col-id') && (
            el.getAttribute('col-id').includes('amount') || 
            el.getAttribute('col-id').includes('total') || 
            el.getAttribute('col-id').includes('win') || 
            el.getAttribute('col-id').includes('bet') ||
            el.getAttribute('col-id').includes('balance')
          );
          
          if (isNumericCol) {
            el.style.textAlign = 'right';
            el.style.fontFamily = 'monospace, sans-serif';
            el.style.letterSpacing = '-0.5px';
          }
        });
      }
    };
    
    // 컬럼 사이즈를 여러 번 맞추기 (안정성 개선)
    const sizeColumnsWithRetry = (attempt = 0, maxAttempts = 5) => {
      try {
        if (attempt >= maxAttempts) return;
        
        // 그리드가 화면에 보이는지 확인
        const gridEl = gridRef.current.el;
        if (!gridEl || gridEl.offsetWidth <= 0) {
          console.warn(`AG Grid: Tried to call sizeColumnsToFit() but the grid width is zero or invalid. Retrying... (${attempt + 1}/${maxAttempts})`);
          setTimeout(() => sizeColumnsWithRetry(attempt + 1, maxAttempts), 200);
          return;
        }
        
        // 컬럼 사이즈 조정
        params.api.sizeColumnsToFit();
        console.log(`Successfully sized columns to fit. (Attempt: ${attempt + 1})`);
        
        // 스타일 직접 적용
        applyColumnStyles();
      } catch (err) {
        console.error('Error sizing columns:', err);
        setTimeout(() => sizeColumnsWithRetry(attempt + 1, maxAttempts), 200);
      }
    };
    
    // 첫 번째 시도는 즉시, 그 다음은 지연 시간을 둠
    sizeColumnsWithRetry(0);
    setTimeout(() => sizeColumnsWithRetry(1), 300);
    setTimeout(() => sizeColumnsWithRetry(2), 600);
    setTimeout(() => sizeColumnsWithRetry(3), 1000);
    
    // 그룹 열기
    if (params.columnApi && params.columnApi.getColumnGroupState) {
      const groupState = params.columnApi.getColumnGroupState();
      if (groupState.length > 0) {
        const openGroups = groupState.map(group => ({
          ...group,
          open: true
        }));
        params.columnApi.setColumnGroupState(openGroups);
      }
    }
    
    // 테이블 컨테이너 스타일 추가
    const container = document.querySelector('.ag-theme-material');
    if (container) {
      container.style.overflow = 'visible';
    }
    
    // 추가 스타일 태그 삽입
    const styleElement = document.createElement('style');
    styleElement.innerHTML = `
      .ag-header-viewport {
        overflow: visible !important;
      }
      .ag-floating-top {
        position: relative !important;
        z-index: 4 !important;
      }
      .ag-body-viewport {
        z-index: 1 !important;
      }
    `;
    document.head.appendChild(styleElement);
    
    // 스크롤 이벤트 리스너 추가
    const bodyViewport = document.querySelector('.ag-body-viewport');
    if (bodyViewport) {
      bodyViewport.addEventListener('scroll', () => {
        applyColumnStyles();
      });
    }
    
    // 윈도우 리사이즈 이벤트 리스너 추가
    window.addEventListener('resize', () => {
      setTimeout(() => {
        params.api.sizeColumnsToFit();
        applyColumnStyles();
      }, 100);
    });
  }, [gridRef]);
  
  // 행 클래스 지정
  const getRowClass = useCallback((params) => {
    return params.data.checked ? 'row-selected' : '';
  }, []);

  // AG Grid 기본 설정
  const defaultColDef = {
    sortable: true,
    filter: true,
    resizable: true,
    minWidth: 100,
    flex: 1
  };

  const gridOptions = {
    defaultColDef,
    rowSelection: 'multiple',
    rowMultiSelectWithClick: false,
    suppressRowClickSelection: true,
    headerHeight: 48,
    rowHeight: 48,
    pagination: true,
    paginationPageSize: pageSize,
    animateRows: true,
    enableCellTextSelection: true,
    suppressColumnVirtualisation: true,
    suppressCellSelection: false,
    enableCellChangeFlash: true,
    suppressExcelMode: true,
    alwaysShowVerticalScroll: true,
    alwaysShowHorizontalScroll: false,
    maintainColumnOrder: true,
    suppressColumnMoveAnimation: true,
    suppressDragLeaveHidesColumns: true,
    colResizeDefault: 'precise',
    suppressCellVerticalBorders: true,
    suppressHeaderVerticalBorders: true,
    suppressFieldDotNotation: true,
    tooltipShowDelay: 0,
    suppressHeaderFloatingAtScrollTime: false,
    suppressFloatingHeader: false,
    floatingFiltersHeight: 0,
    pivotHeaderHeight: 48,
    pivotGroupHeaderHeight: 48,
    suppressPaginationPanel: false,
    rowStyle: { borderBottom: '1px solid #E0E0E0' },
    domLayout: 'normal',
    paginationAutoPageSize: false
  };

  return {
    gridApi,
    columnApi,
    getRowId,
    isRowSelectable,
    handleSelectionChanged,
    handleRowSelected,
    onRowClicked,
    onGridReady,
    onColumnMoved,
    onFirstDataRendered,
    getRowClass,
    gridOptions,
    setGridApi,
    setColumnApi,
    // 회원 상세 정보 관련 상태 및 핸들러 추가
    memberDetailOpen,
    selectedMember,
    handleMemberDetailClose,
    handleMemberDetailSave,
    // MemberDetailDialog 컴포넌트 렌더링 함수
    renderMemberDetailDialog: () => (
      <MemberDetailDialog
        open={memberDetailOpen}
        onClose={handleMemberDetailClose}
        member={selectedMember}
        onSave={handleMemberDetailSave}
      />
    )
  };
};

export default useAgGridConfig;
