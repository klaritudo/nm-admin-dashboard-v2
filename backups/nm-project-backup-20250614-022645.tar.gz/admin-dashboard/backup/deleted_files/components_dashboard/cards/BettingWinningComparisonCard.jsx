import React from 'react';
import { Box, Card, CardContent, Typography, CardHeader, Grid, Divider, Chip } from '@mui/material';
import { TrendingUp as TrendingUpIcon, TrendingDown as TrendingDownIcon } from '@mui/icons-material';

// 데모 데이터
const data = {
  current: {
    베팅금: 100000000,
    당첨금: 91000000,
    rate: 9.0
  },
  previous: {
    베팅금: 93000000,
    당첨금: 84000000,
    rate: 9.7
  }
};

/**
 * 베팅금 및 당첨금 비교 카드 컴포넌트
 * 
 * @returns {JSX.Element} 베팅금 및 당첨금 비교 카드
 */
const BettingWinningComparisonCard = () => {
  // 증감률 계산
  const calcChangeRate = (current, previous) => {
    if (!previous) return 0;
    return ((current - previous) / previous * 100).toFixed(1);
  };
  
  // 베팅금 증감률
  const bettingChangeRate = calcChangeRate(data.current.베팅금, data.previous.베팅금);
  
  // 당첨금 증감률
  const winningChangeRate = calcChangeRate(data.current.당첨금, data.previous.당첨금);
  
  // 숫자 포매팅 함수
  const formatCurrency = (value) => {
    return value.toLocaleString() + '원';
  };
  
  return (
    <Card 
      variant="outlined" 
      sx={{ 
        borderRadius: '12px', 
        boxShadow: '0 2px 10px rgba(0, 0, 0, 0.04)', 
        height: '100%',
        border: '1px solid #eff2f5',
        transition: 'all 0.3s ease',
        '&:hover': {
          boxShadow: '0 5px 15px rgba(0, 0, 0, 0.08)',
          transform: 'translateY(-2px)',
        }
      }}
    >
      <CardHeader
        title="베팅금 및 당첨금"
        titleTypographyProps={{ 
          variant: 'subtitle1', 
          fontWeight: 600,
          fontSize: '15px',
          color: '#181c32'
        }}
        sx={{ 
          backgroundColor: 'rgba(0, 158, 247, 0.03)', 
          borderBottom: '1px solid rgba(0, 0, 0, 0.05)',
          py: 2
        }}
      />
      <CardContent sx={{ p: 3 }}>
        <Grid container spacing={3}>
          {/* 당월 */}
          <Grid item xs={6}>
            <Typography 
              variant="subtitle2" 
              color="text.secondary" 
              gutterBottom 
              align="center"
              sx={{ 
                fontSize: '14px',
                fontWeight: 600,
                color: '#5e6278',
                mb: 2
              }}
            >
              당월
            </Typography>
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                mb: 2,
                p: 2,
                borderRadius: '8px',
                backgroundColor: 'rgba(0, 158, 247, 0.04)',
              }}
            >
              <Typography 
                variant="body2" 
                sx={{ 
                  color: '#5e6278',
                  fontSize: '13px',
                  mb: 1
                }}
              >
                베팅금
              </Typography>
              <Typography 
                variant="h6" 
                sx={{ 
                  fontWeight: 700, 
                  color: '#009ef7',
                  fontSize: '18px'
                }}
              >
                {formatCurrency(data.current.베팅금)}
              </Typography>
              <Chip
                icon={parseFloat(bettingChangeRate) >= 0 ? <TrendingUpIcon fontSize="small" /> : <TrendingDownIcon fontSize="small" />}
                label={`${bettingChangeRate}%`}
                color={parseFloat(bettingChangeRate) >= 0 ? 'success' : 'error'}
                size="small"
                sx={{ 
                  mt: 1, 
                  height: 24,
                  fontSize: '11px',
                  fontWeight: 600,
                  '& .MuiChip-label': {
                    px: 1
                  }
                }}
              />
            </Box>
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                p: 2,
                borderRadius: '8px',
                backgroundColor: 'rgba(80, 205, 137, 0.04)',
              }}
            >
              <Typography 
                variant="body2" 
                sx={{ 
                  color: '#5e6278',
                  fontSize: '13px',
                  mb: 1
                }}
              >
                당첨금
              </Typography>
              <Typography 
                variant="h6" 
                sx={{ 
                  fontWeight: 700, 
                  color: '#50cd89',
                  fontSize: '18px'
                }}
              >
                {formatCurrency(data.current.당첨금)}
              </Typography>
              <Chip
                icon={parseFloat(winningChangeRate) >= 0 ? <TrendingUpIcon fontSize="small" /> : <TrendingDownIcon fontSize="small" />}
                label={`${winningChangeRate}%`}
                color={parseFloat(winningChangeRate) >= 0 ? 'success' : 'error'}
                size="small"
                sx={{ 
                  mt: 1, 
                  height: 24,
                  fontSize: '11px',
                  fontWeight: 600,
                  '& .MuiChip-label': {
                    px: 1
                  }
                }}
              />
            </Box>
          </Grid>
          
          {/* 전월 */}
          <Grid item xs={6}>
            <Typography 
              variant="subtitle2" 
              color="text.secondary" 
              gutterBottom 
              align="center"
              sx={{ 
                fontSize: '14px',
                fontWeight: 600,
                color: '#5e6278',
                mb: 2
              }}
            >
              전월
            </Typography>
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                mb: 2,
                p: 2,
                borderRadius: '8px',
                backgroundColor: 'rgba(0, 158, 247, 0.04)',
                opacity: 0.7,
              }}
            >
              <Typography 
                variant="body2" 
                sx={{ 
                  color: '#5e6278',
                  fontSize: '13px',
                  mb: 1
                }}
              >
                베팅금
              </Typography>
              <Typography 
                variant="h6" 
                sx={{ 
                  fontWeight: 700, 
                  color: '#009ef7',
                  fontSize: '18px'
                }}
              >
                {formatCurrency(data.previous.베팅금)}
              </Typography>
            </Box>
            <Box
              sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                p: 2,
                borderRadius: '8px',
                backgroundColor: 'rgba(80, 205, 137, 0.04)',
                opacity: 0.7,
              }}
            >
              <Typography 
                variant="body2" 
                sx={{ 
                  color: '#5e6278',
                  fontSize: '13px',
                  mb: 1
                }}
              >
                당첨금
              </Typography>
              <Typography 
                variant="h6" 
                sx={{ 
                  fontWeight: 700, 
                  color: '#50cd89',
                  fontSize: '18px'
                }}
              >
                {formatCurrency(data.previous.당첨금)}
              </Typography>
            </Box>
          </Grid>
          
          {/* 수익률 */}
          <Grid item xs={12}>
            <Divider sx={{ my: 2 }} />
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                p: 2,
                borderRadius: '8px',
                backgroundColor: 'rgba(241, 65, 108, 0.04)',
              }}
            >
              <Box>
                <Typography 
                  variant="body2" 
                  sx={{ 
                    color: '#5e6278',
                    fontSize: '13px'
                  }}
                >
                  당월 수익률
                </Typography>
                <Typography 
                  variant="h6" 
                  sx={{ 
                    fontWeight: 700, 
                    color: '#f1416c',
                    fontSize: '18px'
                  }}
                >
                  {data.current.rate}%
                </Typography>
              </Box>
              <Box>
                <Typography 
                  variant="body2" 
                  sx={{ 
                    color: '#5e6278',
                    fontSize: '13px',
                    textAlign: 'right'
                  }}
                >
                  전월 수익률
                </Typography>
                <Typography 
                  variant="h6" 
                  sx={{ 
                    fontWeight: 700, 
                    color: '#f1416c',
                    fontSize: '18px',
                    opacity: 0.7
                  }}
                >
                  {data.previous.rate}%
                </Typography>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </CardContent>
    </Card>
  );
};

export default BettingWinningComparisonCard; 