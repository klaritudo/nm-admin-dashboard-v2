import React from 'react';
import {
  MenuItem,
  Menu,
  Typography,
  Box,
  Divider,
  Tabs,
  Tab,
  Grid,
  Checkbox,
  FormControlLabel,
  Button
} from '@mui/material';
import { RestartAlt as ResetIcon } from '@mui/icons-material';

const DisplayOptionsMenu = ({ 
  displayOptionsAnchor, 
  displayOptionsOpen, 
  handleDisplayOptionsClose, 
  tabValue, 
  handleTabChange, 
  columns, 
  hiddenColumns, 
  handleToggleAllColumns, 
  handleColumnVisibilityChange, 
  handleGroupColumnsToggle, 
  handleResetColumns 
}) => {
  return (
    <Menu
      anchorEl={displayOptionsAnchor}
      open={displayOptionsOpen}
      onClose={handleDisplayOptionsClose}
      PaperProps={{
        sx: { 
          width: '400px',
          maxWidth: '400px',
          maxHeight: '80vh', 
          zIndex: 1400
        }
      }}
      sx={{ zIndex: 1400 }}
      MenuListProps={{
        sx: { width: '100%' }
      }}
      anchorOrigin={{
        vertical: 'bottom',
        horizontal: 'right',
      }}
      transformOrigin={{
        vertical: 'top',
        horizontal: 'right',
      }}
    >
      <MenuItem sx={{ display: 'block', p: 0 }}>
        <Box sx={{ p: 2 }}>
          <Typography variant="subtitle1" sx={{ mb: 2, fontWeight: 600 }}>
            표시 옵션
          </Typography>
          
          <Divider sx={{ mb: 2 }} />
          
          <Tabs
            value={tabValue}
            onChange={handleTabChange}
            indicatorColor="primary"
            textColor="primary"
            variant="fullWidth"
            sx={{ minHeight: 40, mb: 2 }}
          >
            <Tab label="기본 컬럼" sx={{ minHeight: 40, py: 0 }} />
            <Tab label="개인 정보" sx={{ minHeight: 40, py: 0 }} />
            <Tab label="연락처 정보" sx={{ minHeight: 40, py: 0 }} />
          </Tabs>
          
          <Box sx={{ mb: 2, minHeight: '200px' }}>
            {/* 기본 컬럼 탭 */}
            {tabValue === 0 && (
              <Grid container spacing={1}>
                <Grid item xs={12}>
                  <FormControlLabel
                    control={
                      <Checkbox 
                        checked={hiddenColumns.length === 0} 
                        onChange={(e) => handleToggleAllColumns(e.target.checked)}
                        size="small"
                      />
                    }
                    label="모든 컬럼 표시"
                  />
                </Grid>
                
                {/* 일반 컬럼 */}
                {columns.filter(col => col.type !== 'group').map(column => (
                  <Grid item xs={4} key={column.id}>
                    <FormControlLabel
                      control={
                        <Checkbox 
                          checked={!hiddenColumns.includes(column.id)} 
                          onChange={(e) => handleColumnVisibilityChange(column.id, e.target.checked)}
                          size="small"
                        />
                      }
                      label={column.name}
                    />
                  </Grid>
                ))}
              </Grid>
            )}
            
            {/* 개인 정보 탭 */}
            {tabValue === 1 && (
              <Grid container spacing={1}>
                <Grid item xs={12} sx={{ mb: 1 }}>
                  <FormControlLabel
                    control={
                      <Checkbox 
                        checked={!hiddenColumns.includes('personalInfo') && 
                          columns.find(col => col.id === 'personalInfo')?.children.every(child => 
                            !hiddenColumns.includes(child.id)
                          )}
                        indeterminate={!hiddenColumns.includes('personalInfo') && 
                          columns.find(col => col.id === 'personalInfo')?.children.some(child => 
                            hiddenColumns.includes(child.id)
                          )}
                        onChange={(e) => handleGroupColumnsToggle('personalInfo', e.target.checked)}
                        size="small"
                      />
                    }
                    label="개인 정보 그룹 표시"
                  />
                </Grid>
                
                <Grid item xs={12}>
                  <Divider sx={{ mb: 1 }} />
                </Grid>
                
                {columns.find(col => col.id === 'personalInfo')?.children.map(subCol => (
                  <Grid item xs={4} key={subCol.id}>
                    <FormControlLabel
                      control={
                        <Checkbox 
                          checked={!hiddenColumns.includes(subCol.id)} 
                          onChange={(e) => {
                            handleColumnVisibilityChange(subCol.id, e.target.checked);
                            // 하위 컬럼이 모두 체크되면 그룹도 체크, 하나라도 체크 해제되면 그룹 체크 해제
                            const personalInfoGroup = columns.find(col => col.id === 'personalInfo');
                            if (personalInfoGroup) {
                              const allChildrenChecked = e.target.checked && 
                                personalInfoGroup.children.every(child => 
                                  child.id === subCol.id || !hiddenColumns.includes(child.id)
                                );
                              if (allChildrenChecked && hiddenColumns.includes('personalInfo')) {
                                handleColumnVisibilityChange('personalInfo', true);
                              } else if (!e.target.checked && !hiddenColumns.includes('personalInfo')) {
                                handleColumnVisibilityChange('personalInfo', false);
                              }
                            }
                          }}
                          size="small"
                        />
                      }
                      label={subCol.name}
                    />
                  </Grid>
                ))}
              </Grid>
            )}
            
            {/* 연락처 정보 탭 */}
            {tabValue === 2 && (
              <Grid container spacing={1}>
                <Grid item xs={12} sx={{ mb: 1 }}>
                  <FormControlLabel
                    control={
                      <Checkbox 
                        checked={!hiddenColumns.includes('contactInfo') && 
                          columns.find(col => col.id === 'contactInfo')?.children.every(child => 
                            !hiddenColumns.includes(child.id)
                          )}
                        indeterminate={!hiddenColumns.includes('contactInfo') && 
                          columns.find(col => col.id === 'contactInfo')?.children.some(child => 
                            hiddenColumns.includes(child.id)
                          )}
                        onChange={(e) => handleGroupColumnsToggle('contactInfo', e.target.checked)}
                        size="small"
                      />
                    }
                    label="연락처 정보 그룹 표시"
                  />
                </Grid>
                
                <Grid item xs={12}>
                  <Divider sx={{ mb: 1 }} />
                </Grid>
                
                {columns.find(col => col.id === 'contactInfo')?.children.map(subCol => (
                  <Grid item xs={4} key={subCol.id}>
                    <FormControlLabel
                      control={
                        <Checkbox 
                          checked={!hiddenColumns.includes(subCol.id)} 
                          onChange={(e) => {
                            handleColumnVisibilityChange(subCol.id, e.target.checked);
                            // 하위 컬럼이 모두 체크되면 그룹도 체크, 하나라도 체크 해제되면 그룹 체크 해제
                            const contactInfoGroup = columns.find(col => col.id === 'contactInfo');
                            if (contactInfoGroup) {
                              const allChildrenChecked = e.target.checked && 
                                contactInfoGroup.children.every(child => 
                                  child.id === subCol.id || !hiddenColumns.includes(child.id)
                                );
                              if (allChildrenChecked && hiddenColumns.includes('contactInfo')) {
                                handleColumnVisibilityChange('contactInfo', true);
                              } else if (!e.target.checked && !hiddenColumns.includes('contactInfo')) {
                                handleColumnVisibilityChange('contactInfo', false);
                              }
                            }
                          }}
                          size="small"
                        />
                      }
                      label={subCol.name}
                    />
                  </Grid>
                ))}
              </Grid>
            )}
          </Box>
          
          <Divider sx={{ my: 2 }} />
          
          <Box sx={{ display: 'flex', justifyContent: 'flex-start', alignItems: 'center' }}>
            <Button
              variant="outlined"
              sx={{ 
                textTransform: 'none',
                borderRadius: '4px',
                color: '#3699FF',
                borderColor: 'rgba(54, 153, 255, 0.5)',
                '&:hover': {
                  borderColor: '#3699FF',
                  backgroundColor: 'rgba(54, 153, 255, 0.08)'
                }
              }}
              startIcon={<ResetIcon />}
              onClick={handleResetColumns}
            >
              레이아웃 초기화
            </Button>
          </Box>
        </Box>
      </MenuItem>
    </Menu>
  );
};

export default DisplayOptionsMenu; 