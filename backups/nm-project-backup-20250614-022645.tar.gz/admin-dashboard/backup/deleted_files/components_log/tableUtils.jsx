import React from 'react';
import { Box, Chip, Typography } from '@mui/material';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';

// 초기 컬럼 정의
export const initialColumns = [
  { id: 'id', name: 'No', width: 80, visible: true },
  { id: 'name', name: '아이디(닉네임)', width: 150, visible: true },
  { id: 'date', name: '날짜', width: 120, visible: true },
  { id: 'type', name: '로그 유형', width: 150, visible: true },
  { id: 'action', name: '액션', width: 120, visible: true },
  { id: 'ip', name: 'IP', width: 120, visible: true },
  { id: 'status', name: '상태', width: 100, visible: true },
  { id: 'details', name: '상세 정보', width: 150, visible: true }
];

// 샘플 데이터 생성 함수
export const generateSampleData = (count = 100) => {
  const logTypes = [
    { id: 1, name: '로그인', parent: null },
    { id: 2, name: '회원가입', parent: null },
    { id: 3, name: '충전', parent: null },
    { id: 4, name: '출금', parent: null },
    { id: 5, name: '게임 플레이', parent: null },
    { id: 6, name: '관리자 로그인', parent: 1 },
    { id: 7, name: '회원 로그인', parent: 1 },
    { id: 8, name: '이메일 가입', parent: 2 },
    { id: 9, name: '소셜 가입', parent: 2 },
    { id: 10, name: '계좌 충전', parent: 3 },
    { id: 11, name: '카드 충전', parent: 3 },
    { id: 12, name: '계좌 출금', parent: 4 },
    { id: 13, name: '슬롯 게임', parent: 5 },
    { id: 14, name: '카지노 게임', parent: 5 },
    { id: 15, name: '스포츠 베팅', parent: 5 }
  ];

  const statuses = ['성공', '실패', '대기중', '처리중', '취소'];
  const actions = ['조회', '생성', '수정', '삭제', '승인', '거부', '요청'];
  const usernames = [
    { id: 'user1', name: '홍길동' },
    { id: 'user2', name: '김철수' },
    { id: 'user3', name: '이영희' },
    { id: 'user4', name: '박민수' },
    { id: 'user5', name: '최지수' },
    { id: 'admin1', name: '관리자1' },
    { id: 'admin2', name: '관리자2' }
  ];

  return Array.from({ length: count }, (_, i) => {
    const user = usernames[Math.floor(Math.random() * usernames.length)];
    const typeIndex = Math.floor(Math.random() * logTypes.length);
    const logType = logTypes[typeIndex];
    
    // 부모 타입이 있는 경우 부모 타입도 찾기
    const parentType = logType.parent ? logTypes.find(t => t.id === logType.parent) : null;

    return {
      id: i + 1,
      name: `${user.id} (${user.name})`,
      date: new Date(Date.now() - Math.floor(Math.random() * 30 * 24 * 60 * 60 * 1000)).toISOString().split('T')[0],
      type: { item: logType, parent: parentType },
      action: actions[Math.floor(Math.random() * actions.length)],
      ip: `192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
      status: statuses[Math.floor(Math.random() * statuses.length)],
      details: `로그 ID: ${Math.floor(Math.random() * 1000000)}`
    };
  });
};

// 상태에 따른 스타일 반환 함수
export const getStatusStyle = (status) => {
  switch (status) {
    case '성공':
      return {
        bgcolor: '#e8fff3',
        color: '#50cd89',
        borderColor: '#50cd89'
      };
    case '실패':
      return {
        bgcolor: '#fff5f8',
        color: '#f1416c',
        borderColor: '#f1416c'
      };
    case '대기중':
      return {
        bgcolor: '#f8f5ff',
        color: '#7239ea',
        borderColor: '#7239ea'
      };
    case '처리중':
      return {
        bgcolor: '#fef5e4',
        color: '#ffc700',
        borderColor: '#ffc700'
      };
    case '취소':
      return {
        bgcolor: '#f1faff',
        color: '#009ef7',
        borderColor: '#009ef7'
      };
    default:
      return {
        bgcolor: '#eef3f7',
        color: '#5e6278',
        borderColor: '#5e6278'
      };
  }
};

// 타입 렌더링 함수
export const renderType = (typeData) => {
  if (!typeData) return '없음';

  // 부모-자식 관계 표시
  if (typeData.parent && typeData.item) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Chip
            label={typeData.parent.name}
            size="small"
            sx={{
              fontSize: '0.75rem',
              backgroundColor: '#f1f1f3',
              color: '#3F4254'
            }}
          />
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', ml: 2 }}>
          <ArrowForwardIosIcon fontSize="small" sx={{ fontSize: 12, mr: 0.5, color: '#3F4254', opacity: 0.5 }} />
          <Chip
            label={typeData.item.name}
            size="small"
            sx={{
              fontSize: '0.75rem',
              backgroundColor: '#eef3f7',
              color: '#5e6278'
            }}
          />
        </Box>
      </Box>
    );
  }

  // 아이템만 있는 경우
  return (
    <Chip
      label={typeData.item?.name || '없음'}
      size="small"
      sx={{
        fontSize: '0.75rem',
        backgroundColor: '#eef3f7',
        color: '#5e6278'
      }}
    />
  );
};

// 파일 다운로드 유틸리티
export const downloadCSV = (data, columns, fileName = 'log-data') => {
  // 표시 가능한 컬럼만 필터링
  const visibleColumns = columns.filter(col => col.visible);
  
  // CSV 헤더 생성
  let csvContent = visibleColumns.map(col => `"${col.name}"`).join(',') + '\n';
  
  // CSV 데이터 행 생성
  data.forEach(row => {
    const rowData = visibleColumns.map(col => {
      let value = row[col.id];
      
      // 특별한 형식 처리
      if (col.id === 'type' && typeof value === 'object') {
        if (value.parent && value.item) {
          value = `${value.parent.name} > ${value.item.name}`;
        } else if (value.item) {
          value = value.item.name;
        } else {
          value = '없음';
        }
      }
      
      // null 또는 undefined 처리
      if (value === null || value === undefined) {
        return '""';
      }
      
      // 문자열로 변환 및 특수 문자 처리
      const stringValue = String(value);
      if (stringValue.includes(',') || stringValue.includes('"')) {
        return `"${stringValue.replace(/"/g, '""')}"`;
      }
      return `"${stringValue}"`;
    });
    csvContent += rowData.join(',') + '\n';
  });
  
  // BOM(Byte Order Mark) 추가하여 한글 깨짐 방지
  const BOM = '\uFEFF';
  const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
  
  // 다운로드 링크 생성 및 클릭
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${fileName}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}; 