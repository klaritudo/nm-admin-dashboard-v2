import React from 'react';
import {
  Typography,
  TextField,
  InputAdornment,
  IconButton,
  FormControl,
  Select,
  MenuItem,
  Tooltip
} from '@mui/material';
import {
  Search as SearchIcon,
  Clear as ClearIcon,
  FileDownload as ExcelIcon,
  Print as PrintIcon
} from '@mui/icons-material';

const TableHeader = ({
  totalItems,
  rowsPerPage,
  handleRowsPerPageChange,
  page,
  handlePageChange,
  getPageNumbers,
  totalPages,
  searchQuery,
  handleSearchChange,
  handleClearSearch
}) => {
  return (
    <div 
      style={{ 
        height: '60px', 
        backgroundColor: '#f3f6fa',
        display: 'flex',
        alignItems: 'center',
        paddingLeft: '24px',
        paddingRight: '24px',
        justifyContent: 'space-between',
        borderBottom: '1px solid rgba(224, 224, 224, 1)',
        color: 'rgba(0, 0, 0, 0.87)',
        borderTopLeftRadius: '4px',
        borderTopRightRadius: '4px'
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        <div style={{ fontSize: '18px', fontWeight: 500 }}>테이블 타이틀</div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          {/* 검색 필드 추가 */}
          <TextField
            placeholder="검색어를 입력하세요"
            size="small"
            value={searchQuery}
            onChange={handleSearchChange}
            sx={{ 
              ml: 3, 
              width: '280px',
              backgroundColor: '#fff',
              borderRadius: '6px',
              '& .MuiOutlinedInput-root': {
                borderRadius: '6px'
              }
            }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon fontSize="small" color="action" />
                </InputAdornment>
              ),
              endAdornment: searchQuery && (
                <InputAdornment position="end">
                  <IconButton 
                    size="small" 
                    onClick={handleClearSearch}
                    sx={{ padding: '2px' }}
                  >
                    <ClearIcon fontSize="small" />
                  </IconButton>
                </InputAdornment>
              )
            }}
          />
        </div>
      </div>
      <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
        <div style={{ color: 'rgba(0, 0, 0, 0.6)' }}>총 항목: {totalItems}개</div>
        <div style={{ borderLeft: '1px solid #ddd', height: '24px', margin: '0 8px' }}></div>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <Typography variant="body2" sx={{ marginRight: 1, color: 'rgba(0, 0, 0, 0.6)' }}>
            페이지당 행 수:
          </Typography>
          <FormControl size="small" variant="outlined" sx={{ minWidth: 70 }}>
            <Select
              value={rowsPerPage}
              size="small"
              onChange={handleRowsPerPageChange}
              MenuProps={{
                PaperProps: {
                  sx: { maxHeight: 200, borderRadius: '8px' }
                }
              }}
              sx={{ borderRadius: '8px' }}
            >
              {[10, 25, 50, 100].map(pageSize => (
                <MenuItem key={pageSize} value={pageSize}>
                  {pageSize}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          
          <div style={{ marginLeft: '16px', display: 'flex', alignItems: 'center' }}>
            <IconButton
              size="small"
              disabled={page === 0}
              onClick={() => handlePageChange(0)}
              color="primary"
              sx={{ borderRadius: '6px' }}
            >
              <span style={{ fontSize: '14px' }}>{"<<"}</span>
            </IconButton>
            <IconButton
              size="small"
              disabled={page === 0}
              onClick={() => handlePageChange(page - 1)}
              color="primary"
              sx={{ borderRadius: '6px' }}
            >
              <span style={{ fontSize: '14px' }}>{"<"}</span>
            </IconButton>
            
            {getPageNumbers().map(pageNum => (
              <IconButton
                key={pageNum}
                size="small"
                style={{
                  backgroundColor: page === pageNum ? 'rgba(25, 118, 210, 0.12)' : 'transparent',
                  color: page === pageNum ? '#1976d2' : 'rgba(0, 0, 0, 0.6)',
                  margin: '0 2px',
                  minWidth: '30px',
                  fontWeight: page === pageNum ? 500 : 400,
                  borderRadius: '6px'
                }}
                onClick={() => handlePageChange(pageNum)}
              >
                <span style={{ fontSize: '14px' }}>{pageNum + 1}</span>
              </IconButton>
            ))}
            
            <IconButton
              size="small"
              disabled={page >= totalPages - 1}
              onClick={() => handlePageChange(page + 1)}
              color="primary"
              sx={{ borderRadius: '6px' }}
            >
              <span style={{ fontSize: '14px' }}>{">"}</span>
            </IconButton>
            <IconButton
              size="small"
              disabled={page >= totalPages - 1}
              onClick={() => handlePageChange(totalPages - 1)}
              color="primary"
              sx={{ borderRadius: '6px' }}
            >
              <span style={{ fontSize: '14px' }}>{">>"}</span>
            </IconButton>
            
            <Tooltip title="다운로드">
              <span>
                <IconButton color="primary" size="small" sx={{ ml: 2 }}>
                  <ExcelIcon />
                </IconButton>
              </span>
            </Tooltip>
            <Tooltip title="프린트">
              <span>
                <IconButton color="primary" size="small">
                  <PrintIcon />
                </IconButton>
              </span>
            </Tooltip>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TableHeader; 