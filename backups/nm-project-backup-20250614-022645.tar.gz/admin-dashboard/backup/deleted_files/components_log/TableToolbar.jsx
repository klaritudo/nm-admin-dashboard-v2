import React from 'react';
import {
  Typography,
  Button,
  Box
} from '@mui/material';
import {
  CalendarMonth as CalendarIcon,
  Tune as TuneIcon,
  Refresh as RefreshIcon
} from '@mui/icons-material';

const TableToolbar = ({ 
  handleDateRangeClick, 
  handleDisplayOptionsClick, 
  handleResetTable 
}) => {
  return (
    <div className="table-toolbar" style={{ 
      padding: '16px 24px', 
      borderBottom: '1px solid rgba(224, 224, 224, 1)',
      backgroundColor: '#fff'
    }}>
      <Typography 
        variant="h6" 
        className="table-title" 
        sx={{ 
          fontSize: '20px',
          fontWeight: 600,
          color: 'rgba(0, 0, 0, 0.87)'
        }}
      >
        사용자 로그 테이블
      </Typography>
      <div className="table-actions">
        <Button
          variant="outlined"
          size="small"
          color="primary"
          startIcon={<CalendarIcon />}
          onClick={handleDateRangeClick}
          sx={{
            borderRadius: '6px',
            textTransform: 'none',
            fontSize: '13px',
            borderColor: 'rgba(25, 118, 210, 0.5)',
            '&:hover': {
              borderColor: '#1976d2'
            }
          }}
        >
          기간 설정
        </Button>
        <Button
          variant="outlined"
          size="small"
          color="primary"
          startIcon={<TuneIcon />}
          onClick={handleDisplayOptionsClick}
          sx={{
            borderRadius: '6px',
            textTransform: 'none',
            fontSize: '13px',
            ml: 1,
            borderColor: 'rgba(25, 118, 210, 0.5)',
            '&:hover': {
              borderColor: '#1976d2'
            }
          }}
        >
          표시옵션
        </Button>
        <Button
          variant="outlined"
          size="small"
          color="primary"
          startIcon={<RefreshIcon />}
          onClick={handleResetTable}
          sx={{
            borderRadius: '6px',
            textTransform: 'none',
            fontSize: '13px',
            ml: 1,
            borderColor: 'rgba(25, 118, 210, 0.5)',
            '&:hover': {
              borderColor: '#1976d2'
            }
          }}
        >
          새로고침
        </Button>
      </div>
    </div>
  );
};

export default TableToolbar; 