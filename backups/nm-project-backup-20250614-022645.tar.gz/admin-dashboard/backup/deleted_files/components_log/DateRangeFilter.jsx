import React from 'react';
import {
  Menu,
  MenuItem,
  Box,
  Typography,
  Divider,
  Grid,
  TextField,
  Button
} from '@mui/material';

const DateRangeFilter = ({
  dateRangeAnchorEl,
  dateRangeOpen,
  handleDateRangeClose,
  startDate,
  setStartDate,
  endDate,
  setEndDate,
  startTime,
  setStartTime,
  endTime,
  setEndTime,
  handleApplyDateFilter,
  handleResetDateFilter,
  handleTodayFilter,
  handleLast24HoursFilter
}) => {
  return (
    <Menu
      anchorEl={dateRangeAnchorEl}
      open={dateRangeOpen}
      onClose={handleDateRangeClose}
      PaperProps={{
        sx: { 
          width: '360px',
          maxHeight: '80vh', 
          zIndex: 1400
        }
      }}
      sx={{ zIndex: 1400 }}
      anchorOrigin={{
        vertical: 'bottom',
        horizontal: 'left',
      }}
      transformOrigin={{
        vertical: 'top',
        horizontal: 'left',
      }}
    >
      <MenuItem sx={{ display: 'block', p: 0 }}>
        <Box sx={{ p: 2 }}>
          <Typography variant="subtitle1" sx={{ mb: 2, fontWeight: 600 }}>
            기간 필터
          </Typography>
          
          <Divider sx={{ mb: 2 }} />
          
          <Grid container spacing={2} sx={{ mb: 2 }}>
            <Grid item xs={7}>
              <TextField
                label="시작 날짜"
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                InputLabelProps={{
                  shrink: true,
                }}
                fullWidth
                size="small"
              />
            </Grid>
            <Grid item xs={5}>
              <TextField
                label="시작 시간"
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                InputLabelProps={{
                  shrink: true,
                }}
                fullWidth
                size="small"
              />
            </Grid>
            <Grid item xs={7}>
              <TextField
                label="종료 날짜"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                InputLabelProps={{
                  shrink: true,
                }}
                fullWidth
                size="small"
              />
            </Grid>
            <Grid item xs={5}>
              <TextField
                label="종료 시간"
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                InputLabelProps={{
                  shrink: true,
                }}
                fullWidth
                size="small"
              />
            </Grid>
          </Grid>
          
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 2 }}>
            <Button
              variant="outlined"
              size="small"
              onClick={handleResetDateFilter}
              sx={{ 
                textTransform: 'none',
                borderRadius: '4px'
              }}
            >
              초기화
            </Button>
            
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button
                variant="outlined"
                size="small"
                onClick={handleTodayFilter}
                sx={{ 
                  textTransform: 'none',
                  borderRadius: '4px',
                  minWidth: '60px'
                }}
              >
                당일
              </Button>
              <Button
                variant="outlined"
                size="small"
                onClick={handleLast24HoursFilter}
                sx={{ 
                  textTransform: 'none',
                  borderRadius: '4px',
                  minWidth: '60px'
                }}
              >
                24H
              </Button>
              <Button
                variant="contained"
                size="small"
                onClick={handleApplyDateFilter}
                sx={{ 
                  textTransform: 'none',
                  borderRadius: '4px'
                }}
              >
                적용
              </Button>
            </Box>
          </Box>
        </Box>
      </MenuItem>
    </Menu>
  );
};

export default DateRangeFilter; 