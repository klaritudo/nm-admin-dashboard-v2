import React from 'react';
import { DragIndicator as DragIcon } from '@mui/icons-material';

const TableContent = ({
  displayedData,
  filteredColumns,
  columns,
  headerRefs,
  handleDragStart,
  handleDragEnd,
  handleDragOver,
  handleDragLeave,
  handleDrop,
  getDragStyle,
  getStatusStyle,
  renderType
}) => {
  // 그룹 헤더 스타일
  const groupHeaderStyle = {
    backgroundColor: '#f5f5f5', 
    color: 'rgba(0, 0, 0, 0.7)',
    fontWeight: 'bold',
    cursor: 'grab',
    textAlign: 'center'
  };
  
  // 일반 헤더 스타일
  const regularHeaderStyle = {
    backgroundColor: '#f5f5f5',
    cursor: 'grab',
    textAlign: 'center',
    fontWeight: '600',
    color: 'rgba(0, 0, 0, 0.7)'
  };
  
  // 서브 헤더 스타일
  const subHeaderStyle = {
    backgroundColor: '#f5f5f5',
    cursor: 'grab',
    textAlign: 'center',
    fontWeight: '600',
    color: 'rgba(0, 0, 0, 0.7)'
  };

  return (
    <div style={{ position: 'relative', height: 'calc(25 * 43px)', overflow: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'separate', borderSpacing: 0 }}>
        <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
          <tr style={{ backgroundColor: '#f5f5f5' }}>
            {filteredColumns.map((column, colIndex) => {
              if (column.type === 'group') {
                // 그룹 헤더 렌더링
                return (
                  <th 
                    key={column.id}
                    ref={el => headerRefs.current[column.id] = el}
                    data-column-id={column.id}
                    style={{
                      ...groupHeaderStyle,
                      ...getDragStyle(column.id),
                      padding: '14px 16px', 
                      textAlign: 'center', 
                      borderBottom: '1px solid rgba(224, 224, 224, 1)',
                      position: 'relative',
                      boxShadow: '0 2px 2px -2px rgba(0,0,0,0.1)',
                      borderTopLeftRadius: colIndex === 0 ? '8px' : '0',
                      borderTopRightRadius: colIndex === columns.length - 1 ? '8px' : '0'
                    }}
                    colSpan={column.children.length}
                    draggable
                    onDragStart={(e) => handleDragStart(e, column, true, false)}
                    onDragEnd={handleDragEnd}
                    onDragOver={(e) => handleDragOver(e, column, true, false)}
                    onDragLeave={handleDragLeave}
                    onDrop={(e) => handleDrop(e, column, true, false)}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <DragIcon fontSize="small" style={{ marginRight: '4px', color: 'rgba(117, 117, 117, 0.7)' }} />
                      {column.name}
                    </div>
                  </th>
                );
              } else {
                // 일반 헤더 렌더링
                return (
                  <th 
                    key={column.id}
                    ref={el => headerRefs.current[column.id] = el}
                    data-column-id={column.id}
                    style={{
                      ...regularHeaderStyle,
                      ...getDragStyle(column.id),
                      padding: '14px 16px', 
                      textAlign: 'center', 
                      borderBottom: '1px solid rgba(224, 224, 224, 1)',
                      position: 'relative',
                      width: column.width ? `${column.width}px` : 'auto',
                      boxShadow: '0 2px 2px -2px rgba(0,0,0,0.1)',
                      borderTopLeftRadius: colIndex === 0 ? '8px' : '0',
                      borderTopRightRadius: colIndex === columns.length - 1 ? '8px' : '0'
                    }}
                    rowSpan={2}
                    draggable
                    onDragStart={(e) => handleDragStart(e, column, false, false)}
                    onDragEnd={handleDragEnd}
                    onDragOver={(e) => handleDragOver(e, column, false, false)}
                    onDragLeave={handleDragLeave}
                    onDrop={(e) => handleDrop(e, column, false, false)}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <DragIcon fontSize="small" style={{ marginRight: '4px', color: 'rgba(117, 117, 117, 0.7)' }} />
                      {column.name}
                    </div>
                  </th>
                );
              }
            })}
          </tr>
          <tr style={{ backgroundColor: '#f5f5f5' }}>
            {filteredColumns.filter(col => col.type === 'group').map(group => (
              // 각 그룹의 서브 컬럼 렌더링
              group.children.map(subCol => (
                <th 
                  key={subCol.id}
                  ref={el => headerRefs.current[subCol.id] = el}
                  data-column-id={subCol.id}
                  data-parent-id={subCol.parentId}
                  style={{
                    ...subHeaderStyle,
                    ...getDragStyle(subCol.id),
                    padding: '14px 16px', 
                    textAlign: 'center', 
                    borderBottom: '1px solid rgba(224, 224, 224, 1)',
                    position: 'relative',
                    width: subCol.width ? `${subCol.width}px` : 'auto',
                    boxShadow: '0 2px 2px -2px rgba(0,0,0,0.1)'
                  }}
                  draggable
                  onDragStart={(e) => handleDragStart(e, subCol, false, true)}
                  onDragEnd={handleDragEnd}
                  onDragOver={(e) => handleDragOver(e, subCol, false, true)}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, subCol, false, true)}
                >
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <DragIcon fontSize="small" style={{ marginRight: '4px', color: 'rgba(117, 117, 117, 0.7)' }} />
                    {subCol.name}
                  </div>
                </th>
              ))
            ))}
          </tr>
        </thead>
        <tbody>
          {displayedData.map((row, rowIndex) => (
            <tr 
              key={row.id} 
              style={{ 
                borderBottom: '1px solid rgba(224, 224, 224, 0.5)',
                transition: 'background-color 0.2s ease',
              }}
              className="table-row-hover"
            >
              {filteredColumns.map((column, colIndex) => {
                if (column.type === 'group') {
                  // 그룹 컬럼의 각 하위 컬럼 셀 렌더링
                  return column.children.map((subCol, subColIndex) => {
                    const isFirstCell = colIndex === 0 && subColIndex === 0;
                    const isLastCell = colIndex === columns.length - 1 && 
                                     subColIndex === column.children.length - 1;
                    const isLastRow = rowIndex === displayedData.length - 1;
                    
                    return (
                      <td 
                        key={subCol.id} 
                        style={{ 
                          padding: '12px 16px', 
                          textAlign: 'center',
                          color: 'rgba(0, 0, 0, 0.7)',
                          fontSize: '14px',
                          ...(isLastRow && isFirstCell ? { borderBottomLeftRadius: '8px' } : {}),
                          ...(isLastRow && isLastCell ? { borderBottomRightRadius: '8px' } : {})
                        }}
                      >
                        {subCol.id === 'status' ? (
                          <span style={{
                            ...getStatusStyle(row[subCol.id]),
                            padding: '6px 12px',
                            borderRadius: '16px',
                            display: 'inline-block',
                            fontSize: '13px',
                            fontWeight: 500
                          }}>{row[subCol.id]}</span>
                        ) : (
                          row[subCol.id]
                        )}
                      </td>
                    );
                  });
                } else {
                  // 일반 컬럼 셀 렌더링
                  const isFirstCell = colIndex === 0;
                  const isLastCell = colIndex === columns.length - 1;
                  const isLastRow = rowIndex === displayedData.length - 1;
                  
                  return (
                    <td 
                      key={column.id} 
                      style={{ 
                        padding: '12px 16px', 
                        textAlign: 'center',
                        color: 'rgba(0, 0, 0, 0.7)',
                        fontSize: '14px',
                        ...(isLastRow && isFirstCell ? { borderBottomLeftRadius: '8px' } : {}),
                        ...(isLastRow && isLastCell ? { borderBottomRightRadius: '8px' } : {})
                      }}
                    >
                      {column.id === 'status' ? (
                        <span style={{
                          ...getStatusStyle(row[column.id]),
                          padding: '6px 12px',
                          borderRadius: '16px',
                          display: 'inline-block',
                          fontSize: '13px',
                          fontWeight: 500
                        }}>{row[column.id]}</span>
                      ) : column.id === 'type' ? (
                        renderType(row[column.id])
                      ) : (
                        row[column.id]
                      )}
                    </td>
                  );
                }
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TableContent; 