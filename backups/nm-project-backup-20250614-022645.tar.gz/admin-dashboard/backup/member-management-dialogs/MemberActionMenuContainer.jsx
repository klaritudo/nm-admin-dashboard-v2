import React from 'react';
import MemberActionMenu from '../MessageActionMenu';
import PropTypes from 'prop-types';

const MemberActionMenuContainer = ({
  actionMenuAnchorEl,
  handleActionMenuClose,
  handleViewMemberInfo,
  handleChangeMemberStatus,
  getMemberById,
  updateMemberStatus
}) => {
  return (
    <MemberActionMenu
      anchorEl={actionMenuAnchorEl}
      open={Boolean(actionMenuAnchorEl)}
      onClose={handleActionMenuClose}
      onViewInfo={() => handleViewMemberInfo(getMemberById)}
      onChangeStatus={(status) => handleChangeMemberStatus(status, updateMemberStatus)}
    />
  );
};

MemberActionMenuContainer.propTypes = {
  actionMenuAnchorEl: PropTypes.object,
  handleActionMenuClose: PropTypes.func.isRequired,
  handleViewMemberInfo: PropTypes.func.isRequired,
  handleChangeMemberStatus: PropTypes.func.isRequired,
  getMemberById: PropTypes.func.isRequired,
  updateMemberStatus: PropTypes.func.isRequired
};

export default MemberActionMenuContainer; 