import React from 'react';
import ApiChangeDialog from '../ApiChangeDialog';
import PropTypes from 'prop-types';

const ApiChangeDialogContainer = ({
  apiChangeDialog,
  cancelApiChange,
  confirmApiChange,
  refreshGridCell,
  updateMemberData
}) => {
  return (
    <ApiChangeDialog
      open={apiChangeDialog.open}
      onClose={() => cancelApiChange(refreshGridCell)}
      oldValue={apiChangeDialog.oldValue}
      newValue={apiChangeDialog.newValue}
      onConfirm={() => confirmApiChange(
        updateMemberData,
        updateMemberData,
        updateMemberData
      )}
    />
  );
};

ApiChangeDialogContainer.propTypes = {
  apiChangeDialog: PropTypes.shape({
    open: PropTypes.bool.isRequired,
    oldValue: PropTypes.string,
    newValue: PropTypes.string
  }).isRequired,
  cancelApiChange: PropTypes.func.isRequired,
  confirmApiChange: PropTypes.func.isRequired,
  refreshGridCell: PropTypes.func.isRequired,
  updateMemberData: PropTypes.func.isRequired
};

export default ApiChangeDialogContainer; 