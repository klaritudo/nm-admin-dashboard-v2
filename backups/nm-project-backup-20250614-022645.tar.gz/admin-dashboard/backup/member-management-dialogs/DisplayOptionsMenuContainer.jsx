import React from 'react';
import { DisplayOptionsMenu } from '../../../ui';
import PropTypes from 'prop-types';

const DisplayOptionsMenuContainer = ({
  displayOptionsAnchorEl,
  handleDisplayOptionsClose,
  visibleColumns,
  handleVisibleColumnsChange,
  handleResetLayout
}) => {
  return (
    <DisplayOptionsMenu
      anchorEl={displayOptionsAnchorEl}
      open={Boolean(displayOptionsAnchorEl)}
      onClose={handleDisplayOptionsClose}
      visibleColumns={visibleColumns}
      onVisibleColumnsChange={handleVisibleColumnsChange}
      onResetLayout={handleResetLayout}
    />
  );
};

DisplayOptionsMenuContainer.propTypes = {
  displayOptionsAnchorEl: PropTypes.object,
  handleDisplayOptionsClose: PropTypes.func.isRequired,
  visibleColumns: PropTypes.object.isRequired,
  handleVisibleColumnsChange: PropTypes.func.isRequired,
  handleResetLayout: PropTypes.func.isRequired
};

export default DisplayOptionsMenuContainer; 