import React from 'react';
import PaymentDialog from '../../../message-management/dialogs/PaymentDialog';
import PropTypes from 'prop-types';

const PaymentDialogContainer = ({
  paymentDialogOpen,
  handleClosePaymentDialog,
  selectedMemberForPayment,
  paymentAction,
  handlePaymentConfirm,
  formatCurrency
}) => {
  return (
    <PaymentDialog 
      open={paymentDialogOpen}
      onClose={handleClosePaymentDialog}
      member={selectedMemberForPayment}
      action={paymentAction}
      onConfirm={handlePaymentConfirm}
      formatCurrency={formatCurrency}
    />
  );
};

PaymentDialogContainer.propTypes = {
  paymentDialogOpen: PropTypes.bool.isRequired,
  handleClosePaymentDialog: PropTypes.func.isRequired,
  selectedMemberForPayment: PropTypes.object,
  paymentAction: PropTypes.string,
  handlePaymentConfirm: PropTypes.func.isRequired,
  formatCurrency: PropTypes.func.isRequired
};

export default PaymentDialogContainer; 