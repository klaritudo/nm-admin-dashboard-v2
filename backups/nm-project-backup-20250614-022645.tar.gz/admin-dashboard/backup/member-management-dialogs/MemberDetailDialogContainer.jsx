import React from 'react';
import MemberDetailDialog from '../../../member/MemberDetailDialog.jsx';
import PropTypes from 'prop-types';

const MemberDetailDialogContainer = ({
  memberDetailOpen,
  handleCloseMemberDetail,
  selectedMember,
  handleSaveMemberDetail
}) => {
  return (
    <MemberDetailDialog
      open={memberDetailOpen}
      onClose={handleCloseMemberDetail}
      member={selectedMember}
      onSave={handleSaveMemberDetail}
    />
  );
};

MemberDetailDialogContainer.propTypes = {
  memberDetailOpen: PropTypes.bool.isRequired,
  handleCloseMemberDetail: PropTypes.func.isRequired,
  selectedMember: PropTypes.object,
  handleSaveMemberDetail: PropTypes.func.isRequired
};

export default MemberDetailDialogContainer; 