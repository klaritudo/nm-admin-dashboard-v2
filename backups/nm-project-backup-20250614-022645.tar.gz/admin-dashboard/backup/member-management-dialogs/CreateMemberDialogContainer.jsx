import React from 'react';
import CreateMemberDialog from '../../../member/CreateMemberDialog.jsx';
import PropTypes from 'prop-types';

const CreateMemberDialogContainer = ({
  openCreateModal,
  handleCloseCreateModal,
  handleCreateMember
}) => {
  return (
    <CreateMemberDialog
      open={openCreateModal}
      onClose={handleCloseCreateModal}
      onCreateMember={handleCreateMember}
    />
  );
};

CreateMemberDialogContainer.propTypes = {
  openCreateModal: PropTypes.bool.isRequired,
  handleCloseCreateModal: PropTypes.func.isRequired,
  handleCreateMember: PropTypes.func.isRequired
};

export default CreateMemberDialogContainer; 