NM 프로젝트 백업 정보
- nm-backup.tar.gz: 주요 컴포넌트 파일 백업
- nm-git-backup.tar.gz: Git 저장소 백업
백업 날짜: Mon Mar 31 03:13:34 KST 2025
