// 중복 임포트 제거 - 상단 임포트 영역에서 selectColumnOrder 제거(이미 아래에 있는 임포트 사용)
// 변경 전
import { selectColumnOrder } from '@/features/members/membersSlice';
// 변경 후
// (이미 나중에 임포트되므로 제거)

// onColumnMoved 이름 중복 해결
// 변경 전
onColumnMoved,
// 변경 후
onColumnMoved: originalOnColumnMoved,